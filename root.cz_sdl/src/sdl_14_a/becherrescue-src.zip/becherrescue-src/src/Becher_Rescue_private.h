// THIS FILE WILL BE OVERWRITTEN BY DEV-C++!
// DO NOT EDIT!

#ifndef BECHER_RESCUE_PRIVATE_H
#define BECHER_RESCUE_PRIVATE_H

// VERSION DEFINITIONS
#define VER_STRING	"1.1.2.3850"
#define VER_MAJOR	1
#define VER_MINOR	1
#define VER_RELEASE	2
#define VER_BUILD	3850
#define COMPANY_NAME	"Zimtech"
#define FILE_VERSION	"1.1"
#define FILE_DESCRIPTION	"Becher Rescue"
#define INTERNAL_NAME	"Becher Rescue"
#define LEGAL_COPYRIGHT	"Copyright � Zimtech 2003"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"Becher Rescue.exe"
#define PRODUCT_NAME	"Becher Rescue"
#define PRODUCT_VERSION	"1.1"

#endif //BECHER_RESCUE_PRIVATE_H
