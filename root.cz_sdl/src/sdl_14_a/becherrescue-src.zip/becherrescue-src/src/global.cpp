#include "global.h"
#include <stdlib.h>

char *ConfigFilePath = NULL;
SDL_Surface *Screen = NULL;
int DesktopFrequency = 0;
bool Is60HzProblem = false;
bool AreModelsLoaded = false;
float Delay = 0;
GLuint Textures[TEXTURES_NUM];
ACTOR Player1, Player2;
Vertex LookAt;
StructMap *Map = NULL;
float Map_XLimit = 0.0f;
int LastPicture = 0;
SDL_Joystick *Joystick = NULL;
bool ShowFPS = false;
bool ShowQuitMessage = false;
float QuitMessage_Duration = 0.0f;
bool Paused = false;
int Difficulty = 1;
#ifdef USE_SDL_MIXER
	Mix_Chunk *Sounds[SOUNDS_NUM] = {0};
#endif
float TotalPlay = 0.0f;

#ifdef WIN32
	BOOL ScreenSaverEnabled = TRUE;
#endif

Model Hero_Body;
Model Hero_Head;
Model Hero_Hand_Left;
Model Hero_Hand_Right;
Model Hero_Sword;
Model Hero_Potion;

Model Raider1_Body;
Model Raider1_Head;
Model Raider1_Hand_Left;
Model Raider1_Hand_Right;
Model Raider1_Club;

Model Raider2_Body;
Model Raider2_Head;
Model Raider2_Hand_Left;
Model Raider2_Hand_Right;
Model Raider2_Axe;
Model Raider2_Helmet;

Model Knight_Body;
Model Knight_Head;
Model Knight_Hand_Left;
Model Knight_Hand_Right;
Model Knight_Sword;
Model Knight_Helmet;
Model Knight_Shield;

