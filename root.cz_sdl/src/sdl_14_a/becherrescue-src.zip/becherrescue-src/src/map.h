#ifndef MAP_H
#define MAP_H

#include "models.h"

#define MAX_MODELS_IN_FIELD		6

enum
{
	FIELD_CLASS_NORMAL = 0,
	FIELD_CLASS_TRANSPARENT,
	FIELD_CLASS_GRASS
};

struct FieldModel
{
	Model *Models[MAX_MODELS_IN_FIELD];
	GLuint Textures[MAX_MODELS_IN_FIELD];
	int Class[MAX_MODELS_IN_FIELD];
	bool IsWater;
	int Width, Length;
	float *Heights;
};

struct Field
{
	float Height;				// the height of this field [meters]
	FieldModel *Model;			// points to a 3D model for this field
};

struct StructMap
{
	int Width;					// the map width
	int Length;					// the map length
	Field *Fields;				// the map fields
};

// load the map from the file
bool LoadMap(const char *PathName, StructMap **Map);

// release the map from the memory
void ReleaseMap(StructMap **Map);

// get the height at the specified point
float GetMapHeight(const StructMap *Map, const float X, const float Y);

// get the highest height in the specified rectangle
float GetMapRectHeight(const StructMap *Map, const float X, const float Y, const float Radius);

// render the map
void RenderMap(StructMap *Map, const int FieldClass);

#endif

