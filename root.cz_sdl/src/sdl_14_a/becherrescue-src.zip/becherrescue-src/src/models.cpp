#include "models.h"
#include <stdio.h>
#include <string.h>
#include "consts.h"

bool LoadModel(const char *PathName, Model *model)
{
	FILE *file = fopen(PathName, "rb");		// open the file ("b" for binary else it ends at the first Ctrl-Z character!!!)
	if (!file)								// error check
		return false;

	// check the file type
	char header[17];
	if (fread(header, sizeof(char), 16, file) < 16)
	{
		fclose(file);
		return false;
	}

	header[16] = '\0';						// breakpoint
	if (strcmp(header, "Zimtech 3D Model"))
	{
		fclose(file);
		return false;
	}

	// check file version
	int i;
	if (!fread(&i, sizeof(i), 1, file))
	{
		fclose(file);
		return false;
	}
	if (i != 1)			// major version
	{
		fclose(file);
		return false;
	}
	if (!fread(&i, sizeof(i), 1, file))
	{
		fclose(file);
		return false;
	}
	if (i)				// minor version
	{
		fclose(file);
		return false;
	}

	// check flags
	if (!fread(&i, sizeof(i), 1, file))
	{
		fclose(file);
		return false;
	}
	if (i)				// flags
	{
		fclose(file);
		return false;
	}

	// load number of vertexes
	if (!fread(&model->NumVertices, sizeof(model->NumVertices), 1, file))
	{
		fclose(file);
		return false;
	}

	if (model->NumVertices > MAX_MODEL_VERTEX_COUNT)
	{
		fclose(file);
		return false;
	}

	// load number of Faces
	if (!fread(&model->NumFaces, sizeof(model->NumFaces), 1, file))
	{
		fclose(file);
		return false;
	}

	if (model->NumFaces > MAX_MODEL_FACE_COUNT)
	{
		fclose(file);
		return false;
	}

	// load face indexes and texture coordinates
	model->Faces = new Face[model->NumFaces];		// = (Face *)malloc(sizeof(Face) * model->NumFaces);
	for (i = 0; i < model->NumFaces; i++)
	{
		fread(&model->Faces[i].A.I, sizeof(model->Faces->A.I), 1, file);
		fread(&model->Faces[i].A.U, sizeof(model->Faces->A.U), 1, file);
		fread(&model->Faces[i].A.V, sizeof(model->Faces->A.V), 1, file);
		fread(&model->Faces[i].B.I, sizeof(model->Faces->B.I), 1, file);
		fread(&model->Faces[i].B.U, sizeof(model->Faces->B.U), 1, file);
		fread(&model->Faces[i].B.V, sizeof(model->Faces->B.V), 1, file);
		fread(&model->Faces[i].C.I, sizeof(model->Faces->C.I), 1, file);
		fread(&model->Faces[i].C.U, sizeof(model->Faces->C.U), 1, file);
		if (!fread(&model->Faces[i].C.V, sizeof(model->Faces->C.V), 1, file))
		{
			delete[] model->Faces;					// free(model->Faces);
			fclose(file);
			return false;
		}
 	}

	// load number of Animations
	if (!fread(&model->NumAnimations, sizeof(model->NumAnimations), 1, file))
	{
		delete[] model->Faces;
		fclose(file);
		return false;
	}

	// load Animations
	model->Animations = new Animation[model->NumAnimations];
	for (i = 0; i < model->NumAnimations; i++)
	{
		// load duration of frames in this animation
		if (!fread(&model->Animations[i].FrameDuration, sizeof(model->Animations->FrameDuration), 1, file))
		{
			for (int k = 0; k < i; k++)
			{
				for (int h = 0; h < model->Animations[k].NumFrames; h++)
				{
					delete[] model->Animations[k].Frames[h].Vertices;
					delete[] model->Animations[k].Frames[h].FcNormals;
				}
				if (model->Animations[k].Frames)
					delete[] model->Animations[k].Frames;
			}
			delete[] model->Animations;
			delete[] model->Faces;
			fclose(file);
			return false;
		}

		// load number of Frames
		if (!fread(&model->Animations[i].NumFrames, sizeof(model->Animations->NumFrames), 1, file))
		{
			for (int k = 0; k < i; k++)
			{
				for (int h = 0; h < model->Animations[k].NumFrames; h++)
				{
					delete[] model->Animations[k].Frames[h].Vertices;
					delete[] model->Animations[k].Frames[h].FcNormals;
				}
				if (model->Animations[k].Frames)
					delete[] model->Animations[k].Frames;
			}
			delete[] model->Animations;
			delete[] model->Faces;
			fclose(file);
			return false;
		}

		// load frames of the animation
		if (model->Animations[i].NumFrames)
			model->Animations[i].Frames = new Frame[model->Animations[i].NumFrames];
		else
			model->Animations[i].Frames = NULL;
		for (int j = 0; j < model->Animations[i].NumFrames; j++)
		{
			// load vertices of this frame
			model->Animations[i].Frames[j].Vertices = new Vertex[model->NumVertices];
			for (int k = 0; k < model->NumVertices; k++)
			{
				fread(&model->Animations[i].Frames[j].Vertices[k].X, sizeof(model->Animations->Frames->Vertices->X), 1, file);
				fread(&model->Animations[i].Frames[j].Vertices[k].Y, sizeof(model->Animations->Frames->Vertices->Y), 1, file);
				if (!fread(&model->Animations[i].Frames[j].Vertices[k].Z, sizeof(model->Animations->Frames->Vertices->Z), 1, file))
				{
					delete[] model->Animations[i].Frames[j].Vertices;
					for (int h = 0; h < j; h++)
					{
						delete[] model->Animations[i].Frames[h].Vertices;
						delete[] model->Animations[i].Frames[h].FcNormals;
					}
					delete[] model->Animations[i].Frames;
					for (int ch = 0; ch < i; ch++)
					{
						for (int h = 0; h < model->Animations[ch].NumFrames; h++)
						{
							delete[] model->Animations[ch].Frames[h].Vertices;
							delete[] model->Animations[ch].Frames[h].FcNormals;
						}
						if (model->Animations[ch].Frames)
							delete[] model->Animations[ch].Frames;
					}
					delete[] model->Animations;
					delete[] model->Faces;
					fclose(file);
					return false;
				}
			}

			// load face normals of this frame
			model->Animations[i].Frames[j].FcNormals = new FaceNormals[model->NumFaces];
			char c;
			for (int k = 0; k < model->NumFaces; k++)
			{
				fread(&c, sizeof(c), 1, file);
				model->Animations[i].Frames[j].FcNormals[k].A.X = c / 120.0f;
				fread(&c, sizeof(c), 1, file);
				model->Animations[i].Frames[j].FcNormals[k].A.Y = c / 120.0f;
				fread(&c, sizeof(c), 1, file);
				model->Animations[i].Frames[j].FcNormals[k].A.Z = c / 120.0f;
				fread(&c, sizeof(c), 1, file);
				model->Animations[i].Frames[j].FcNormals[k].B.X = c / 120.0f;
				fread(&c, sizeof(c), 1, file);
				model->Animations[i].Frames[j].FcNormals[k].B.Y = c / 120.0f;
				fread(&c, sizeof(c), 1, file);
				model->Animations[i].Frames[j].FcNormals[k].B.Z = c / 120.0f;
				fread(&c, sizeof(c), 1, file);
				model->Animations[i].Frames[j].FcNormals[k].C.X = c / 120.0f;
				fread(&c, sizeof(c), 1, file);
				model->Animations[i].Frames[j].FcNormals[k].C.Y = c / 120.0f;
				if (!fread(&c, sizeof(c), 1, file))
				{
					for (int h = 0; h <= j; h++)
					{
						delete[] model->Animations[i].Frames[h].Vertices;
						delete[] model->Animations[i].Frames[h].FcNormals;
					}
					delete[] model->Animations[i].Frames;
					for (int ch = 0; ch < i; ch++)
					{
						for (int h = 0; h < model->Animations[ch].NumFrames; h++)
						{
							delete[] model->Animations[ch].Frames[h].Vertices;
							delete[] model->Animations[ch].Frames[h].FcNormals;
						}
						if (model->Animations[ch].Frames)
							delete[] model->Animations[ch].Frames;
					}
					delete[] model->Animations;
					delete[] model->Faces;
					fclose(file);
					return false;
				}
				model->Animations[i].Frames[j].FcNormals[k].C.Z = c / 120.0f;
			}
		}
	}

	fclose(file);
	return true;
}

void ReleaseModel(Model *model)
{
	int i, j;
	for (i = 0; i < model->NumAnimations; i++)
	{
		for (j = 0; j < model->Animations[i].NumFrames; j++)
		{
			delete[] model->Animations[i].Frames[j].Vertices;
			delete[] model->Animations[i].Frames[j].FcNormals;
		}
		if (model->Animations[i].Frames)
			delete[] model->Animations[i].Frames;
	}
	delete[] model->Animations;
	delete[] model->Faces;
}

void RenderModelAnimation(const Model model, const GLuint Texture, const int Animation, const float Past)
{
	if (!model.NumVertices)
		return;

	float diff = Past / model.Animations[Animation].FrameDuration;
	int prevframe = (int)diff, nextframe = prevframe + 1;
	if (nextframe == model.Animations[Animation].NumFrames)
		nextframe = 0;
	diff = diff - prevframe;
	float oneminusdiff = 1.0f - diff;

	// compute linear interpolation of vertices between two frames
	Vertex vertices[MAX_MODEL_VERTEX_COUNT];
	{
		Vertex *end = &vertices[model.NumVertices];
		Vertex *prev = model.Animations[Animation].Frames[prevframe].Vertices;
		Vertex *next = model.Animations[Animation].Frames[nextframe].Vertices;
		for (Vertex *result = vertices; result < end; prev++, next++, result++)
		{
			result->X = oneminusdiff * prev->X + diff * next->X;
			result->Y = oneminusdiff * prev->Y + diff * next->Y;
			result->Z = oneminusdiff * prev->Z + diff * next->Z;
		}
	}

	// compute linear interpolation of face normals between two frames
	FaceNormals fcnormals[MAX_MODEL_FACE_COUNT];
	{
		FaceNormals *end = &fcnormals[model.NumFaces];
		FaceNormals *prev = model.Animations[Animation].Frames[prevframe].FcNormals;
		FaceNormals *next = model.Animations[Animation].Frames[nextframe].FcNormals;
		for (FaceNormals *result = fcnormals; result < end; prev++, next++, result++)
		{
			result->A.X = oneminusdiff * prev->A.X + diff * next->A.X;
			result->A.Y = oneminusdiff * prev->A.Y + diff * next->A.Y;
			result->A.Z = oneminusdiff * prev->A.Z + diff * next->A.Z;

			result->B.X = oneminusdiff * prev->B.X + diff * next->B.X;
			result->B.Y = oneminusdiff * prev->B.Y + diff * next->B.Y;
			result->B.Z = oneminusdiff * prev->B.Z + diff * next->B.Z;

			result->C.X = oneminusdiff * prev->C.X + diff * next->C.X;
			result->C.Y = oneminusdiff * prev->C.Y + diff * next->C.Y;
			result->C.Z = oneminusdiff * prev->C.Z + diff * next->C.Z;
		}
	}

	glBindTexture(GL_TEXTURE_2D, Texture);

	// render it
	glBegin(GL_TRIANGLES);

	Face *end = &model.Faces[model.NumFaces];
	FaceNormals *normals = fcnormals;		// because I can't do "fcnormals++" (it's a static array)
	for (Face *now = model.Faces; now < end; now++, normals++)
	{
		glTexCoord2f(now->A.U, now->A.V);
		glNormal3f(normals->A.X, normals->A.Z, normals->A.Y);		// OpenGL has swapped y- and z-axis
		glVertex3f(vertices[now->A.I].X, vertices[now->A.I].Z, vertices[now->A.I].Y);

		glTexCoord2f(now->B.U, now->B.V);
		glNormal3f(normals->B.X, normals->B.Z, normals->B.Y);
		glVertex3f(vertices[now->B.I].X, vertices[now->B.I].Z, vertices[now->B.I].Y);

		glTexCoord2f(now->C.U, now->C.V);
		glNormal3f(normals->C.X, normals->C.Z, normals->C.Y);
		glVertex3f(vertices[now->C.I].X, vertices[now->C.I].Z, vertices[now->C.I].Y);
	}

	glEnd();
}

void RenderModelFrame(const Model model, const GLuint Texture, const int Animation, const int Frame)
{
	if (!model.NumVertices)
		return;

	glBindTexture(GL_TEXTURE_2D, Texture);

	// render it
	glBegin(GL_TRIANGLES);

	Face *end = &model.Faces[model.NumFaces];
	Vertex *vertices = model.Animations[Animation].Frames[Frame].Vertices;
	FaceNormals *normals = model.Animations[Animation].Frames[Frame].FcNormals;
	for (Face *now = model.Faces; now < end; now++, normals++)
	{
		glTexCoord2f(now->A.U, now->A.V);
		glNormal3f(normals->A.X, normals->A.Z, normals->A.Y);		// OpenGL has swapped y- and z-axis
		glVertex3f(vertices[now->A.I].X, vertices[now->A.I].Z, vertices[now->A.I].Y);

		glTexCoord2f(now->B.U, now->B.V);
		glNormal3f(normals->B.X, normals->B.Z, normals->B.Y);
		glVertex3f(vertices[now->B.I].X, vertices[now->B.I].Z, vertices[now->B.I].Y);

		glTexCoord2f(now->C.U, now->C.V);
		glNormal3f(normals->C.X, normals->C.Z, normals->C.Y);
		glVertex3f(vertices[now->C.I].X, vertices[now->C.I].Z, vertices[now->C.I].Y);
	}

	glEnd();
}

void NormalizeModelTime(float *Time, const Model model, const int Animation)
{
	// compute the second time limit of the animation (the firts is zero)
	float limit = model.Animations[Animation].NumFrames * model.Animations[Animation].FrameDuration;

	// adjust the time if it is over the limit time (time length of the animation)
	while (*Time >= limit)
		*Time -= limit;

	// adjust the time if it is before zero
	while (*Time < 0.0f)
		*Time += limit;
}
