#include "actor.h"
#include "global.h"
#include <GL/gl.h>
#include "consts.h"
#include "keys.h"
#include <stdlib.h>
#include <SDL/SDL.h>		// for SDL_GetTicks()
#ifdef USE_SDL_MIXER
	#include <SDL/SDL_mixer.h>
#endif
#include <math.h>
#include "scene.h"
#include "settings.h"
#include "sounds.h"
#include "game.h"

#define CHANGE_ACTION(Actor, NewAction) {Actor->PrevAction = Actor->Action; Actor->Action = NewAction;}

static void Enemy_SelectTarget(ACTOR *Actor)
{
	if (Actors[PLAYER1].Used && Actors[PLAYER1].Health > 0 && !Actors[PLAYER1].Immortal)
		if (Actors[PLAYER2].Used && Actors[PLAYER2].Health > 0 && !Actors[PLAYER2].Immortal)
			if (rand() % 2)
				Actor->Target = &Actors[PLAYER1];
			else
				Actor->Target = &Actors[PLAYER2];
		else
			Actor->Target = &Actors[PLAYER1];
	else
		if (Actors[PLAYER2].Used && Actors[PLAYER2].Health > 0 && !Actors[PLAYER2].Immortal)
			Actor->Target = &Actors[PLAYER2];
		else
			Actor->Target = NULL;
}

void UpdateActor(ACTOR *Actor)
{
	bool IsPlayer = Actor == &Actors[PLAYER1] || Actor == &Actors[PLAYER2];		// is it one of players?

	int offset = Actor == &Actors[PLAYER2] ? PLAYER2_DOWN_KEY : 0;		// if it is Player 2, scan his keys instead of Player 1's keys

	Actor->Duration += Delay;		// update the duration of the actual action
	if (Actor->Immortal)
		Actor->Immortal_Duration += Delay;

	Actor->PrevAltitude = Actor->Position.Z;

	if (Actor->Health > 0)
		if (Actor->Position.X - Actor->Radius < LookAt.X - 4.0f)			// for all
			Actor->Position.X = LookAt.X - 4.0f + Actor->Radius;
		else
			if (Actor->Class == CLASS_HERO && Actor->Position.X + Actor->Radius > LookAt.X + 4.0f)	// for heroes only
				Actor->Position.X = LookAt.X + 4.0f - Actor->Radius;

	if (Actor->Health < 1 && Actor->Action != ACTION_FALL)
		CHANGE_ACTION(Actor, ACTION_FALL)

	// fix a problem
	{
		float alt = GetSceneRectHeight(Actor, Actor->Position.X, Actor->Position.Y, Actor->Radius);
		if (Actor->Health > 0 && Actor->Position.Z < alt - 0.001 && alt < Actor->Position.Z + Actor->Height)
			Actor->Position.Z = alt;
	}

	if (Actor->Immortal && Actor->Immortal_Duration > 3.0f)
		Actor->Immortal = false;

	// is he out of the ground?
	if (Actor->Action != ACTION_JUMP && Actor->Action != ACTION_ATTACK_IN_AIR && Actor->Action != ACTION_ATTACK_AFTER_RUN)
	{
		float f = GetSceneRectHeight(Actor, Actor->Position.X, Actor->Position.Y, Actor->Radius);
		if (Actor->Position.Z > f)
			if (Actor->Position.Z - Actor->FallSpeed * Delay < f)
				Actor->Position.Z = f;
			else
				Actor->Position.Z -= Actor->FallSpeed * Delay;
		else	// is he on somebody?
			if (Actor->Position.Z > GetMapRectHeight(Map, Actor->Position.X, Actor->Position.Y, Actor->Radius))
			{
				// compute dx and dy (changes in these axis)
				float dx = 0.0f, dy = 0.0f;
				if (Actor->Direction >= DIRECTION_SE && Actor->Direction <= DIRECTION_NE)
					dx += Delay * Actor->FallSpeed;
				if (Actor->Direction >= DIRECTION_NW && Actor->Direction <= DIRECTION_SW)
					dx -= Delay * Actor->FallSpeed;
				if (Actor->Direction <= DIRECTION_SE || Actor->Direction == DIRECTION_SW)
					dy += Delay * Actor->FallSpeed;
				if (Actor->Direction >= DIRECTION_NE && Actor->Direction <= DIRECTION_NW)
					dy -= Delay * Actor->FallSpeed;

				// update Actor->Position
				if ((GetSceneRectHeight(Actor, Actor->Position.X + dx, Actor->Position.Y + dy, Actor->Radius) - Actor->Position.Z) < 0.001f)
				{
					Actor->Position.X += dx;
					Actor->Position.Y += dy;
				}
				else if ((GetSceneRectHeight(Actor, Actor->Position.X + dx, Actor->Position.Y, Actor->Radius) - Actor->Position.Z) < 0.001f)
					Actor->Position.X += dx;
				else if ((GetSceneRectHeight(Actor, Actor->Position.X, Actor->Position.Y + dy, Actor->Radius) - Actor->Position.Z) < 0.001f)
					Actor->Position.Y += dy;
			}
	}

	// process directional key events
	if (IsPlayer)		// is it one of players?
	{
		if (Actor->Action == ACTION_STAY || Actor->Action == ACTION_WALK || Actor->Action == ACTION_RUN
				|| Actor->Action == ACTION_JUMP || Actor->Action ==  ACTION_ATTACK_IN_AIR)
			if (Keys[PLAYER1_DOWN_KEY + offset] || Keys[PLAYER1_RDOWN_KEY + offset] || Keys[PLAYER1_RIGHT_KEY + offset] ||
				Keys[PLAYER1_RUP_KEY + offset] || Keys[PLAYER1_UP_KEY + offset] || Keys[PLAYER1_LUP_KEY + offset] ||
				Keys[PLAYER1_LEFT_KEY + offset] || Keys[PLAYER1_LDOWN_KEY + offset])
			{
				// update Actor->Direction
				if (Keys[PLAYER1_RDOWN_KEY + offset] || (Keys[PLAYER1_DOWN_KEY + offset] && Keys[PLAYER1_RIGHT_KEY + offset]))
					Actor->Direction = DIRECTION_SE;
				else if (Keys[PLAYER1_RUP_KEY + offset] || (Keys[PLAYER1_UP_KEY + offset] && Keys[PLAYER1_RIGHT_KEY + offset]))
					Actor->Direction = DIRECTION_NE;
				else if (Keys[PLAYER1_LUP_KEY + offset] || (Keys[PLAYER1_UP_KEY + offset] && Keys[PLAYER1_LEFT_KEY + offset]))
					Actor->Direction = DIRECTION_NW;
				else if (Keys[PLAYER1_LDOWN_KEY + offset] || (Keys[PLAYER1_DOWN_KEY + offset] && Keys[PLAYER1_LEFT_KEY + offset]))
					Actor->Direction = DIRECTION_SW;
				else if (Keys[PLAYER1_DOWN_KEY + offset])
					Actor->Direction = DIRECTION_SOUTH;
				else if (Keys[PLAYER1_RIGHT_KEY + offset])
					Actor->Direction = DIRECTION_EAST;
				else if (Keys[PLAYER1_UP_KEY + offset])
					Actor->Direction = DIRECTION_NORTH;
				else if (Keys[PLAYER1_LEFT_KEY + offset])
					Actor->Direction = DIRECTION_WEST;

				// if he were staying decide whether he is walking or running now
				if (Actor->Action == ACTION_STAY)
				{
					if (SDL_GetTicks() - KeysPressTimePrev[Actor->Direction + offset] < DOUBLE_PRESS_DELAY)
						CHANGE_ACTION(Actor, ACTION_RUN)
					else
						CHANGE_ACTION(Actor, ACTION_WALK)
					Actor->Duration = Delay;
				}

				// compute dx and dy (changes in these axis)
				float dx = 0.0f, dy = 0.0f;
				if (Keys[PLAYER1_RIGHT_KEY + offset] || Keys[PLAYER1_RUP_KEY + offset] || Keys[PLAYER1_RDOWN_KEY + offset])
					dx += Delay;
				if (Keys[PLAYER1_LEFT_KEY + offset] || Keys[PLAYER1_LUP_KEY + offset] || Keys[PLAYER1_LDOWN_KEY + offset])
					dx -= Delay;
				if (Keys[PLAYER1_DOWN_KEY + offset] || Keys[PLAYER1_LDOWN_KEY + offset] || Keys[PLAYER1_RDOWN_KEY + offset])
					dy += Delay;
				if (Keys[PLAYER1_UP_KEY + offset] || Keys[PLAYER1_LUP_KEY + offset] || Keys[PLAYER1_RUP_KEY + offset])
					dy -= Delay;
				dx *= Actor->Action == ACTION_RUN ? Actor->RunSpeed : Actor->WalkSpeed;
				dy *= Actor->Action == ACTION_RUN ? Actor->RunSpeed : Actor->WalkSpeed;

				// update Actor->Position
				if ((GetSceneRectHeight(Actor, Actor->Position.X + dx, Actor->Position.Y + dy, Actor->Radius) - Actor->Position.Z) < 0.001f)
				{
					Actor->Position.X += dx;
					Actor->Position.Y += dy;
				}
				else
					if (dx && (GetSceneRectHeight(Actor, Actor->Position.X + dx, Actor->Position.Y, Actor->Radius) - Actor->Position.Z) < 0.001f)
						Actor->Position.X += dx;
					else
 						if (dy && (GetSceneRectHeight(Actor, Actor->Position.X, Actor->Position.Y + dy, Actor->Radius) - Actor->Position.Z) < 0.001f)
							Actor->Position.Y += dy;
 						else
							if (Actor->Action == ACTION_RUN)
								CHANGE_ACTION(Actor, ACTION_WALK)
			}
			else
				if (Actor->Action == ACTION_WALK || Actor->Action == ACTION_RUN)
				{
					CHANGE_ACTION(Actor, ACTION_STAY)
					Actor->Duration = Delay;
				}
	}
	else	// it is an enemy
	{	// enemy's AI:
		if (Actor->Target && Actor->Target->Used)
		{
			if (Actor->Position.X - Actor->Target->Position.X < 10.0f)
			{
				float target_dx = Actor->Target->Position.X - Actor->Position.X, target_dy = Actor->Target->Position.Y - Actor->Position.Y;

				bool is_on_hero = false;
				{
					float f1 = Actor->Target->Position.Z + Actor->Target->Height, f2 = Actor->Position.Z;
					if (f1 - 0.0001f < f2 && f1 + 0.0001f > f2)
						is_on_hero = true;
				}

				// go from the hero's head
				if (is_on_hero && Actor->Action == ACTION_STAY && Actor->Duration > 0.6f)
				{
					Actor->Direction = rand() % 8;
					Actor->Duration = 0.0f;
				}

				// update Actor->Direction
				if ((Actor->Action == ACTION_STAY || Actor->Action == ACTION_WALK || Actor->Action == ACTION_RUN || Actor->Action == ACTION_JUMP) && !is_on_hero)
				{
					if (target_dy > 0.3f && target_dx > 0.3f)
						Actor->Direction = DIRECTION_SE;
					else if (target_dy < -0.3f && target_dx > 0.3f)
						Actor->Direction = DIRECTION_NE;
					else if (target_dy < -0.3f && target_dx < -0.3f)
						Actor->Direction = DIRECTION_NW;
					else if (target_dy > 0.3f && target_dx < -0.3f)
						Actor->Direction = DIRECTION_SW;
					else if (target_dy > 0.3f)
						Actor->Direction = DIRECTION_SOUTH;
					else if (target_dx > 0.3f)
						Actor->Direction = DIRECTION_EAST;
					else if (target_dy < -0.3f)
						Actor->Direction = DIRECTION_NORTH;
					else if (target_dx < -0.3f)
						Actor->Direction = DIRECTION_WEST;
				}

				// do some attack
				{
					float hit_range = Actor->HitShift + Actor->HitRadius + 0.3f;
					if (fabs(target_dx) < hit_range && fabs(target_dy) < hit_range && !is_on_hero
							&& (Actor->Action == ACTION_STAY || Actor->Action == ACTION_WALK)
							&& ((Actor->PrevAction == ACTION_BLOCK && (Actor->Class == CLASS_KNIGHT || !(rand() % 4)))
							|| Actor->PrevAction == ACTION_RISE || Actor->Duration > 0.5f))
						if (Actor->Target->Action != ACTION_FALL && Actor->Target->Health > 0)
						{
							if (Actor->Class != CLASS_KNIGHT && rand() % 2)
								CHANGE_ACTION(Actor, ACTION_ATTACK2)
							else
								CHANGE_ACTION(Actor, ACTION_ATTACK1)
							Actor->Duration = Delay;
						#ifdef USE_SDL_MIXER
							PlaySfx(Sounds[Actor->Class == CLASS_KNIGHT ? KNIGHT_ATTACK_SOUND : HERO_ATTACK1_SOUND + rand() % 2], Actor->Position);
						#endif
						}
						else
						{
							CHANGE_ACTION(Actor, ACTION_STAY)
							Actor->Duration = Delay;
						}
				}

				// do ACTION_ATTACK_AFTER_RUN
				{
					float dist_x = fabs(target_dx);
					if (Actor->Action == ACTION_RUN && dist_x < 4.0f && dist_x > 3.6f && !(rand() % 10))
					{
						CHANGE_ACTION(Actor, ACTION_ATTACK_AFTER_RUN)
						Actor->JumpPower = JUMP_POWER_AFTER_WALK / 2.0f;
						Actor->Duration = Delay;
					}
 				}

				// if he is staying, walk or run to the target
				if (Actor->Target->Action != ACTION_FALL && Actor->Target->Action != ACTION_RISE && Actor->Target->Health > 0 && !is_on_hero)
					if (Actor->Action == ACTION_STAY)
					{
						if (Actor->Class != CLASS_KNIGHT && !(rand() % 10))
							CHANGE_ACTION(Actor, ACTION_RUN)
						else
							CHANGE_ACTION(Actor, ACTION_WALK)
						Actor->Duration = Delay;
					}
					else
						if (Actor->Action == ACTION_WALK && Actor->Class != CLASS_KNIGHT)
						{
							float f = Actor->Duration;
							while (f > 3.0f)
								f -= 3.0f;
							if (f < 0.1f && ((fabs(target_dx) > 5.0f && rand() < RAND_MAX / 3) || rand() < RAND_MAX / 20))
								CHANGE_ACTION(Actor, ACTION_RUN)
						}
						else
							if (Actor->Action == ACTION_RUN)
							{
								float f = Actor->Duration;
								while (f > 2.0f)
									f -= 2.0f;
								if (f < 0.1f && ((fabs(target_dx) < 2.0f && rand() < RAND_MAX / 2) || rand() < RAND_MAX / 10))
									CHANGE_ACTION(Actor, ACTION_WALK)
							}

				// implementation of walking and running
				if ((Actor->Action == ACTION_WALK || Actor->Action == ACTION_RUN || Actor->Action == ACTION_JUMP) && !is_on_hero)
				{
					float dx = 0.0f, dy = 0.0f;

					// compute dx and dy (changes in these axis)
					if (target_dx > 0.3f)
						dx = Delay;
					else
						if (target_dx < -0.3f)
							dx = -Delay;

					if (target_dy > 0.3f)
						dy = Delay;
					else
						if (target_dy < -0.3f)
							dy = -Delay;
					dx *= Actor->Action == ACTION_RUN ? Actor->RunSpeed : Actor->WalkSpeed;
					dy *= Actor->Action == ACTION_RUN ? Actor->RunSpeed : Actor->WalkSpeed;

					// update Actor->Position
					if ((GetSceneRectHeight(Actor, Actor->Position.X + dx, Actor->Position.Y + dy, Actor->Radius) - Actor->Position.Z) < 0.001f)
					{
						Actor->Position.X += dx;
						Actor->Position.Y += dy;
					}
					else
						if (dx && (GetSceneRectHeight(Actor, Actor->Position.X + dx, Actor->Position.Y, Actor->Radius) - Actor->Position.Z) < 0.001f)
							Actor->Position.X += dx;
						else
							if (dy && (GetSceneRectHeight(Actor, Actor->Position.X, Actor->Position.Y + dy, Actor->Radius) - Actor->Position.Z) < 0.001f)
								Actor->Position.Y += dy;
							else
							{
								float f = Actor->Position.Z - GetSceneRectHeight(Actor, Actor->Position.X, Actor->Position.Y, Actor->Radius);
								if (Actor->Class != CLASS_KNIGHT && f < 0.001f && f >= 0.0f
									&& Actor->Target->Position.Z - Actor->Position.Z > 0.1f && Actor->Target->Action != ACTION_JUMP
									&& Actor->Duration < 0.1f && !(rand() % 2))
								{
									if (Actor->Action == ACTION_WALK)
									{
										CHANGE_ACTION(Actor, ACTION_JUMP)
										Actor->Duration = Delay;
										if (rand() < RAND_MAX / 5)
											Actor->JumpPower = JUMP_POWER_AFTER_RUN;
										else
											Actor->JumpPower = JUMP_POWER_AFTER_WALK;
									#ifdef USE_SDL_MIXER
										PlaySfx(Sounds[JUMP_SOUND], Actor->Position);
									#endif
									}
									else
										if (Actor->Action == ACTION_RUN)
										{
											CHANGE_ACTION(Actor, ACTION_JUMP)
											Actor->JumpPower = JUMP_POWER_AFTER_RUN;
											Actor->Duration = Delay;
										#ifdef USE_SDL_MIXER
											PlaySfx(Sounds[JUMP_SOUND], Actor->Position);
										#endif
										}
								}
								else
									if (Actor->Action == ACTION_RUN)
			 							CHANGE_ACTION(Actor, ACTION_WALK)
							}
				}

				if (Actor->Target->Health < 1 || Actor->Target->Action == ACTION_FALL)
					Enemy_SelectTarget(Actor);
			}
		}
		else
		{
			Enemy_SelectTarget(Actor);		// select a target

			if (!Actor->Target && Actor->Action != ACTION_STAY && Actor->Health > 0)
			{
				CHANGE_ACTION(Actor, ACTION_STAY)
				Actor->Duration = 0.0f;
			}
		}
	}

	// correct the position and state
	if (Actor->Action == ACTION_JUMP || Actor->Action == ACTION_ATTACK_IN_AIR || Actor->Action == ACTION_ATTACK_AFTER_RUN)
	{
		Actor->Position.Z += Actor->JumpPower * Delay;

		// is he on the ground now?
		if (Actor->JumpPower < 0.0f)
		{
			float altitude = GetSceneRectHeight(Actor, Actor->Position.X, Actor->Position.Y, Actor->Radius);
			if (Actor->Position.Z <= altitude)
			{
				Actor->Position.Z = altitude;
				if (Actor->Action == ACTION_ATTACK_IN_AIR)
					CHANGE_ACTION(Actor, ACTION_ATTACK2)
				else if (Actor->Action == ACTION_JUMP)
				{
					CHANGE_ACTION(Actor, ACTION_STAY)
					Actor->Duration = (Actor->Position.Z - altitude) / Actor->JumpPower;	// compute the time he is on the ground yet

				}
			}
			else
				Actor->JumpPower -= JUMP_POWER_DECREASE * Delay;
		}
		else
			Actor->JumpPower -= JUMP_POWER_DECREASE * Delay;

		if (Actor->Action == ACTION_ATTACK_AFTER_RUN)
		{
			double d = Actor->Direction * 0.785398163397;		// 0.785398163397 = PI / 4 = 180 / 4 = 45
			float dx = sin(d) * JUMP_ATTACK_SPEED * Delay, dy = cos(d) * JUMP_ATTACK_SPEED * Delay;

			// update Actor->Position
			if ((GetSceneRectHeight(Actor, Actor->Position.X + dx, Actor->Position.Y + dy, Actor->Radius) - Actor->Position.Z) < 0.001f)
			{
				Actor->Position.X += dx;
				Actor->Position.Y += dy;
			}
			else
			{
			#ifdef USE_SDL_MIXER
				if (HitActorsInBox(Actor, Actor->Position.X + sin(Actor->Direction * 0.785398163397) * Actor->HitShift,
						Actor->Position.Y + cos(Actor->Direction * 0.785398163397) * Actor->HitShift,
						Actor->Position.Z + Actor->HitHeight, Actor->HitRadius, 214 * Actor->Damage / 100))	// 0.785398163397 = PI / 4 = 180 / 4 = 45
					PlaySfx(Sounds[HIT4_SOUND], Actor->Position);
             #else
				HitActorsInBox(Actor, Actor->Position.X + sin(Actor->Direction * 0.785398163397) * Actor->HitShift,
					Actor->Position.Y + cos(Actor->Direction * 0.785398163397) * Actor->HitShift,
					Actor->Position.Z + Actor->HitHeight, Actor->HitRadius, 214 * Actor->Damage / 100);	// 0.785398163397 = PI / 4 = 180 / 4 = 45
			#endif

				CHANGE_ACTION(Actor, ACTION_STAY)
				Actor->Duration = Delay;
			}
		}
	}
	else if (Actor->Action == ACTION_FALL)
	{
		if (Actor->Health < 1 && Actor->Duration > 7.0f)
		{
			if (IsPlayer)
				if (Actor->Credits--)
				{
					CHANGE_ACTION(Actor, ACTION_STAY)
					Actor->Duration = 0.0f;
					Actor->Health = MAX_HEALTH_HERO;
					Actor->Immortal = true;
					Actor->Immortal_Duration = 0.0f;
				}
				else
				{
					Actor->Used = false;
					GLfloat light_diffuse[4] = {1.0f * LightIntensity, 1.0f * LightIntensity, 0.0f, 1.0f};
					if (Actor == &Actors[PLAYER1])
					{
						glDisable(GL_LIGHT2);
						glLightfv(GL_LIGHT3, GL_DIFFUSE, light_diffuse);
					}
					else
					{
						glDisable(GL_LIGHT3);
						glLightfv(GL_LIGHT2, GL_DIFFUSE, light_diffuse);
					}
				}
			else
				Actor->Used = false;
			return;
		}

		double d = Actor->Direction * 0.785398163397;		// 0.785398163397 = PI / 4 = 180 / 4 = 45
		float dx = sin(d) * Actor->FallSpeed * Delay, dy = cos(d) * Actor->FallSpeed * Delay;
		float animlenght = (Actor->WeaponModel->Animations[ACTION_FALL].NumFrames - 1) * Actor->WeaponModel->Animations[ACTION_FALL].FrameDuration;

		if (Actor->Duration < animlenght + 0.20f)
		{
			if (Actor->Duration > animlenght)
			{
				dx /= 2.0f;
				dy /= 2.0f;
			}

			// update Actor->Position
			if ((GetSceneRectHeight(Actor, Actor->Position.X - dx, Actor->Position.Y - dy, Actor->Radius) - Actor->Position.Z) < 0.001f)
			{
				Actor->Position.X -= dx;
				Actor->Position.Y -= dy;
			}
		}
	}

	if (IsPlayer)
	{
		if (Keys[PLAYER1_FIRE_KEY + offset] == 1)		// is fire key first pressed?
		{
			if (Actor->Action == ACTION_STAY || Actor->Action == ACTION_WALK)
			{
				int rnd = rand() % 3;
				if (!rnd)
					CHANGE_ACTION(Actor, ACTION_ATTACK1)
				else
					if (rnd == 1)
						CHANGE_ACTION(Actor, ACTION_ATTACK2)
					else
						CHANGE_ACTION(Actor, ACTION_ATTACK3)
				Actor->Duration = Delay;
			#ifdef USE_SDL_MIXER

				PlaySfx(Sounds[HERO_ATTACK1_SOUND + rand() % 2], Actor->Position);
			#endif
			}
			else if (Actor->Action == ACTION_RUN)
			{
				CHANGE_ACTION(Actor, ACTION_ATTACK_AFTER_RUN)
				Actor->JumpPower = JUMP_POWER_AFTER_WALK / 2.0f;
				Actor->Duration = Delay;
			}
			else if (Actor->Action == ACTION_JUMP
				&& Actor->Duration >= (Actor->BodyModel->Animations[ACTION_JUMP].NumFrames - 1) * Actor->BodyModel->Animations[ACTION_JUMP].FrameDuration)
			{
				CHANGE_ACTION(Actor, ACTION_ATTACK_IN_AIR)
				Actor->Duration = Delay;
			#ifdef USE_SDL_MIXER
				PlaySfx(Sounds[HERO_ATTACK1_SOUND + rand() % 2], Actor->Position);
			#endif
			}
		}
		else if (Keys[PLAYER1_JUMP_KEY + offset] == 1)
		{	// is he on the ground?
			float f = Actor->Position.Z - GetSceneRectHeight(Actor, Actor->Position.X, Actor->Position.Y, Actor->Radius);
			if (f < 0.001f && f >= 0.0f)
				if (Actor->Action == ACTION_STAY || Actor->Action == ACTION_WALK)
				{
					CHANGE_ACTION(Actor, ACTION_JUMP)
					Actor->JumpPower = JUMP_POWER_AFTER_WALK;
					Actor->Duration = Delay;
				#ifdef USE_SDL_MIXER
					PlaySfx(Sounds[JUMP_SOUND], Actor->Position);
				#endif
				}
				else if (Actor->Action == ACTION_RUN)
				{
					CHANGE_ACTION(Actor, ACTION_JUMP)
					Actor->JumpPower = JUMP_POWER_AFTER_RUN;
					Actor->Duration = Delay;
				#ifdef USE_SDL_MIXER
					PlaySfx(Sounds[JUMP_SOUND], Actor->Position);
				#endif
				}
		}
		else if (Keys[PLAYER1_MAGIC_KEY + offset] == 1)
			if ((Actor->Action == ACTION_STAY || Actor->Action == ACTION_WALK || Actor->Action == ACTION_BLOCK) && !Actor->Immortal)
				if (Actor->Bottles)
				{
					CHANGE_ACTION(Actor, ACTION_DRINK)
					Actor->Duration = Delay;
				}
	}

	// is he lying on a ground too long?
	if (Actor->Action == ACTION_FALL && Actor->Health > 0 && Actor->Duration >= Actor->LyingTime)
	{
		CHANGE_ACTION(Actor, ACTION_RISE)
		Actor->Duration -= Actor->LyingTime;
	}
	else	// does the actor flies too long?
		if (Actor->Action == ACTION_ATTACK_AFTER_RUN && Actor->Duration >= Actor->FlyingTime)
		{
			CHANGE_ACTION(Actor, ACTION_STAY)
			Actor->Duration -= Actor->FlyingTime;
		}
		else	// does he wait too long after a hit?
			if (Actor->Action == ACTION_BLOCK && Actor->Duration >= Actor->BlockingTime)
			{
				CHANGE_ACTION(Actor, ACTION_STAY)
				Actor->Duration -= Actor->BlockingTime;
			}
			else	// does he finished an attack in the air?
				if (Actor->Action == ACTION_ATTACK_IN_AIR
					&& Actor->Duration >= 1.25f * (Actor->WeaponModel->Animations[ACTION_ATTACK_IN_AIR].NumFrames - 1) * Actor->WeaponModel->Animations[ACTION_ATTACK_IN_AIR].FrameDuration)
				{
				#ifdef USE_SDL_MIXER
					if (HitActorsInBox(Actor, Actor->Position.X + sin(Actor->Direction * 0.785398163397) * Actor->HitShift,
							Actor->Position.Y + cos(Actor->Direction * 0.785398163397) * Actor->HitShift,
							Actor->Position.Z + Actor->HitHeight - 0.4f, Actor->HitRadius, 143 * Actor->Damage / 100))	// 0.785398163397 = PI / 4 = 180 / 4 = 45
						PlaySfx(Sounds[HIT1_SOUND + rand() % 3], Actor->Position);
	             #else
					HitActorsInBox(Actor, Actor->Position.X + sin(Actor->Direction * 0.785398163397) * Actor->HitShift,
						Actor->Position.Y + cos(Actor->Direction * 0.785398163397) * Actor->HitShift,
						Actor->Position.Z + Actor->HitHeight - 0.4f, Actor->HitRadius, 143 * Actor->Damage / 100);	// 0.785398163397 = PI / 4 = 180 / 4 = 45
				#endif

					CHANGE_ACTION(Actor, ACTION_JUMP)
					Actor->Duration = 5.0f;
				}
				else	// does he finished drinking?
					if (Actor->Action == ACTION_DRINK && Actor->Duration >= DRINKING_TIME)
					{
						Actor->Bottles--;

						// do damage to enemies
						ACTOR *end = &Actors[MAX_ACTORS];
						for (ACTOR *actor = &Actors[ENEMY0]; actor < end; actor++)
							if (actor->Used && actor->Position.X - Actor->Position.X < 10.0f)
								HitActor(actor, Actor, 30);

					#ifdef USE_SDL_MIXER
						PlaySfx(Sounds[MAGIC_SOUND], Actor->Position);
					#endif

						CHANGE_ACTION(Actor, ACTION_DRINK_EXPLOSION)
						Actor->Duration -= DRINKING_TIME;
					}
					else
						if (Actor->Action == ACTION_DRINK_EXPLOSION && Actor->Duration >= EXPLOSION_TIME)
						{
							CHANGE_ACTION(Actor, ACTION_STAY)
							Actor->Duration -= EXPLOSION_TIME;
						}

	// does he finished some attack?
	if ((Actor->Action == ACTION_ATTACK1 || Actor->Action == ACTION_ATTACK2 || Actor->Action == ACTION_ATTACK3)
		&& Actor->Duration >= 1.25f * (Actor->WeaponModel->Animations[Actor->Action].NumFrames - 1) * Actor->WeaponModel->Animations[Actor->Action].FrameDuration)
	{
	#ifdef USE_SDL_MIXER
		if (HitActorsInBox(Actor, Actor->Position.X + sin(Actor->Direction * 0.785398163397) * Actor->HitShift,
				Actor->Position.Y + cos(Actor->Direction * 0.785398163397) * Actor->HitShift,
				Actor->Position.Z + Actor->HitHeight, Actor->HitRadius, Actor->Damage))	// 0.785398163397 = PI / 4 = 180 / 4 = 45
			PlaySfx(Sounds[HIT1_SOUND + rand() % 3], Actor->Position);
	#else
		HitActorsInBox(Actor, Actor->Position.X + sin(Actor->Direction * 0.785398163397) * Actor->HitShift,
			Actor->Position.Y + cos(Actor->Direction * 0.785398163397) * Actor->HitShift,
			Actor->Position.Z + Actor->HitHeight, Actor->HitRadius, Actor->Damage);	// 0.785398163397 = PI / 4 = 180 / 4 = 45
	#endif

		CHANGE_ACTION(Actor, ACTION_STAY)
		Actor->Duration = 0.0f;
	}

	// does he finished the rising move?
	if (Actor->Action == ACTION_RISE && Actor->Duration >= (Actor->WeaponModel->Animations[Actor->Action].NumFrames - 1) * Actor->WeaponModel->Animations[Actor->Action].FrameDuration)
	{
		CHANGE_ACTION(Actor, ACTION_STAY)
		Actor->Duration -= (Actor->WeaponModel->Animations[Actor->Action].NumFrames - 1) * Actor->WeaponModel->Animations[Actor->Action].FrameDuration;
	}

#ifdef USE_SDL_MIXER
	if (Actor->PrevAltitude > 4.6f && Actor->Position.Z <= 4.6f && Stage != 1)
		PlaySfx(Sounds[FOOT_SPLASH_SOUND], Actor->Position);
#endif

	// correct Actor->Duration
	if (Actor->Action == ACTION_STAY || Actor->Action == ACTION_WALK ||
			Actor->Action == ACTION_RUN || Actor->Action == ACTION_RISE)
		NormalizeModelTime(&Actor->Duration, *Actor->WeaponModel, Actor->Action);
}

void HitActor(ACTOR *Actor, ACTOR *Attacker, const int Damage)
{
	if (Actor != &Actors[PLAYER1] && Actor != &Actors[PLAYER2])		// it is an enemy
		if (Attacker == &Actors[PLAYER1] || Attacker == &Actors[PLAYER2])
			Actor->Target = Attacker;								// select the new target

	if ((Attacker->Action != ACTION_DRINK || Actor->Health < 1)
			&& (Actor->Action == ACTION_FALL || Actor->Action == ACTION_RISE || Actor->Immortal
			|| Attacker->Immortal || Actor->Action == ACTION_DRINK || Actor->Action == ACTION_DRINK_EXPLOSION))
		return;

	if (Attacker->Action == ACTION_DRINK)
		if (Actor->Position.X > Attacker->Position.X)
			Actor->Direction = DIRECTION_WEST;
		else
			Actor->Direction = DIRECTION_EAST;
	else
		Actor->Direction = Attacker->Direction > DIRECTION_NE ? Attacker->Direction - DIRECTION_NORTH : Attacker->Direction + DIRECTION_NORTH;

	int damage = Damage + int(((float)rand() / (float)RAND_MAX / 2.5f - 0.2f) * Damage);	// damage = <-0.2, 0.2> * Damage
	Actor->Health -= damage;
	Attacker->TotalDamage += damage;

	if (Attacker->Class == CLASS_KNIGHT || Attacker->Action == ACTION_ATTACK_IN_AIR
		|| Attacker->Action == ACTION_ATTACK_AFTER_RUN || Attacker->Action == ACTION_DRINK)
	{
		Actor->Duration = 0.0f;
		CHANGE_ACTION(Actor, Actor->Class == CLASS_KNIGHT ? (Attacker->Action == ACTION_ATTACK_IN_AIR || Attacker->Action == ACTION_DRINK || rand() % 2 ? ACTION_FALL : ACTION_BLOCK) : ACTION_FALL)
	#ifdef USE_SDL_MIXER
		if (Actor->Action == ACTION_FALL)
			PlaySfx(Sounds[FALL_SOUND], Actor->Position);
	#endif
	}
	else
		if (Actor->Action != ACTION_BLOCK)
		{
			Actor->Duration = 0.0f;
			if (Actor->Health < 1 || !(rand() % Actor->Class == CLASS_HERO ? 8 : 5))
			{
				CHANGE_ACTION(Actor, ACTION_FALL)
			#ifdef USE_SDL_MIXER
				PlaySfx(Sounds[FALL_SOUND], Actor->Position);
			#endif
			}
			else
				CHANGE_ACTION(Actor, ACTION_BLOCK)
		}
}

void RenderActor(ACTOR *Actor)
{
	int action = Actor->Action;
	float duration = Actor->Duration;
	if (action == ACTION_DRINK_EXPLOSION)
	{
		action = ACTION_DRINK;
		duration += DRINKING_TIME;
	}
	float framedur = Actor->BodyModel->Animations[action].FrameDuration;
	bool transparency = false;

	glPushMatrix();		// push the current matrix stack (not to modify next objects)

	// translate the Actor to his position
	glTranslatef(Actor->Position.X, Actor->Position.Z + 0.02f, Actor->Position.Y);

	// rotate him to the right direction
	glRotatef(Actor->Direction * 45.0f, 0.0f, 1.0f, 0.0f);

	if (Actor->Health < 1 && Actor->Duration > 3.0f)	// he is dead and lies too long on the ground
	{
		glTranslatef(0.0f, -0.25f * (Actor->Duration - 3.0f), 0.0f);	// move down

		transparency = true;

		if (HighDetails)
		{
			glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);		// blending function for transparency based on alfa-value
			glEnable(GL_BLEND);

			if (Actor->BodyTexture == &Textures[RAIDER1_BODY_TEXTURE3])		// it is a ghost
			{
				GLfloat diffuse[4] = {0.8f, 0.8f, 0.8f, 0.5f - (Actor->Duration - 3.0f) * 0.435f};
				glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
			}
			else
			{
				GLfloat diffuse[4] = {0.8f, 0.8f, 0.8f, 1.0f - (Actor->Duration - 3.0f) * 0.87f};
				glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
			}
		}
		else
		{
			float f = 0.8f - (Actor->Duration - 3.0f) * 0.696f;
			GLfloat diffuse[4] = {f, f, f, 1.0f};
			glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
		}
	}
	else
		if (Actor->Immortal)
		{
			transparency = true;

			if (HighDetails)
			{
				glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);		// blending function for transparency based on alfa-value
				glEnable(GL_BLEND);

				GLfloat diffuse[4] = {0.8f, 0.8f, 0.8f, 0.33f};
				glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
			}
			else
			{
				GLfloat diffuse[4] = {0.33f, 0.33f, 0.33f, 1.0f};
				glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
			}
		}
		else

			if (Actor->BodyTexture == &Textures[RAIDER1_BODY_TEXTURE3] && HighDetails)		// it is a ghost
			{
				transparency = true;

				glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);		// blending function for transparency based on alfa-value
				glEnable(GL_BLEND);

				GLfloat diffuse[4] = {0.8f, 0.8f, 0.8f, 0.5f};
				glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
			}

	// knight and super-knight are bigger
	if (Actor->Class == CLASS_KNIGHT)
		if (Actor->BodyTexture == &Textures[KNIGHT_BODY_TEXTURE2])	// is it the bigger variant of the knight?
			glScalef(1.4f, 1.4f, 1.4f);
		else
			glScalef(1.2f, 1.2f, 1.2f);

	// render the body
	if ((Actor->Class == CLASS_KNIGHT && action == ACTION_ATTACK1) || action == ACTION_STAY || action == ACTION_BLOCK || action == ACTION_ATTACK_IN_AIR || action == ACTION_DRINK)
		RenderModelFrame(*Actor->BodyModel, *Actor->BodyTexture, action, 0);
	else
		if ((action == ACTION_FALL || action == ACTION_ATTACK_AFTER_RUN || action == ACTION_JUMP
				|| action == ACTION_ATTACK1 || action == ACTION_ATTACK2 || action == ACTION_ATTACK3)
				&& duration >= (Actor->BodyModel->Animations[action].NumFrames - 1) * framedur)
			RenderModelFrame(*Actor->BodyModel, *Actor->BodyTexture, action,
				Actor->BodyModel->Animations[action].NumFrames - 1);
		else
			RenderModelAnimation(*Actor->BodyModel, *Actor->BodyTexture, action, duration);

	// render the head
	if ((Actor->Class == CLASS_KNIGHT && action == ACTION_ATTACK1) || ((Actor->Class == CLASS_RAIDER1 || Actor->Class == CLASS_RAIDER2) && action == ACTION_WALK)
			|| action == ACTION_BLOCK || action == ACTION_JUMP || action == ACTION_ATTACK_IN_AIR)
		RenderModelFrame(*Actor->HeadModel, *Actor->HeadTexture, action, 0);
	else
		if ((action == ACTION_FALL || action == ACTION_ATTACK_AFTER_RUN || action == ACTION_DRINK
				|| action == ACTION_ATTACK1 || action == ACTION_ATTACK2 || action == ACTION_ATTACK3)
				&& duration >= (Actor->HeadModel->Animations[action].NumFrames - 1) * framedur)
			RenderModelFrame(*Actor->HeadModel, *Actor->HeadTexture, action,
				Actor->HeadModel->Animations[action].NumFrames - 1);
		else
			RenderModelAnimation(*Actor->HeadModel, *Actor->HeadTexture, action, duration);

	// render the left hand
	if (action == ACTION_BLOCK || action == ACTION_JUMP || action == ACTION_DRINK)
		RenderModelFrame(*Actor->HandLeftModel, *Actor->HandTexture, action, 0);
	else
		if ((action == ACTION_FALL || action == ACTION_ATTACK_AFTER_RUN
				|| action == ACTION_ATTACK1 || action == ACTION_ATTACK2 || action == ACTION_ATTACK3 || action == ACTION_ATTACK_IN_AIR)
				&& duration >= (Actor->HandLeftModel->Animations[action].NumFrames - 1) * framedur)
			RenderModelFrame(*Actor->HandLeftModel, *Actor->HandTexture, action,
				Actor->HandLeftModel->Animations[action].NumFrames - 1);
		else
			RenderModelAnimation(*Actor->HandLeftModel, *Actor->HandTexture, action, duration);

	// render the right hand
	if (action == ACTION_BLOCK || action == ACTION_JUMP)
		RenderModelFrame(*Actor->HandRightModel, *Actor->HandTexture, action, 0);
	else
		if ((action == ACTION_FALL || action == ACTION_ATTACK_AFTER_RUN || action == ACTION_DRINK
				|| action == ACTION_ATTACK1 || action == ACTION_ATTACK2 || action == ACTION_ATTACK3 || action == ACTION_ATTACK_IN_AIR)
				&& duration >= (Actor->HandRightModel->Animations[action].NumFrames - 1) * framedur)
			RenderModelFrame(*Actor->HandRightModel, *Actor->HandTexture, action,
				Actor->HandRightModel->Animations[action].NumFrames - 1);
		else
			RenderModelAnimation(*Actor->HandRightModel, *Actor->HandTexture, action, duration);

	// render the weapon
	if (action == ACTION_BLOCK || action == ACTION_JUMP || action == ACTION_DRINK)
		RenderModelFrame(*Actor->WeaponModel, *Actor->WeaponTexture, action, 0);
	else
		if ((action == ACTION_FALL || action == ACTION_ATTACK_AFTER_RUN
				|| action == ACTION_ATTACK1 || action == ACTION_ATTACK2 || action == ACTION_ATTACK3 || action == ACTION_ATTACK_IN_AIR)
				&& duration >= (Actor->WeaponModel->Animations[action].NumFrames - 1) * framedur)
			RenderModelFrame(*Actor->WeaponModel, *Actor->WeaponTexture, action,
				Actor->WeaponModel->Animations[action].NumFrames - 1);
		else
			RenderModelAnimation(*Actor->WeaponModel, *Actor->WeaponTexture, action, duration);

	// render the helmet
	if (Actor->HelmetModel)		// the actor has a helmet
		if ((Actor->Class == CLASS_KNIGHT && action == ACTION_ATTACK1) || (Actor->Class != CLASS_KNIGHT && action == ACTION_WALK) || action == ACTION_BLOCK || action == ACTION_JUMP)
			RenderModelFrame(*Actor->HelmetModel, *Actor->HelmetTexture, action, 0);
		else
			if ((action == ACTION_FALL || action == ACTION_ATTACK_AFTER_RUN
					|| action == ACTION_ATTACK1 || action == ACTION_ATTACK2 || action == ACTION_ATTACK3)
					&& duration >= (Actor->HelmetModel->Animations[action].NumFrames - 1) * framedur)
				RenderModelFrame(*Actor->HelmetModel, *Actor->HelmetTexture, action,
					Actor->HelmetModel->Animations[action].NumFrames - 1);
			else
				RenderModelAnimation(*Actor->HelmetModel, *Actor->HelmetTexture, action, duration);

	// render the shield
	if (Actor->ShieldModel)		// the actor has a shield
		if (action == ACTION_BLOCK)
			RenderModelFrame(*Actor->ShieldModel, *Actor->ShieldTexture, action, 0);
		else
			if ((action == ACTION_FALL || action == ACTION_ATTACK1 || action == ACTION_ATTACK2 || action == ACTION_ATTACK3)
					&& duration >= (Actor->ShieldModel->Animations[action].NumFrames - 1) * framedur)
				RenderModelFrame(*Actor->ShieldModel, *Actor->ShieldTexture, action,
					Actor->ShieldModel->Animations[action].NumFrames - 1);
			else
				RenderModelAnimation(*Actor->ShieldModel, *Actor->ShieldTexture, action, duration);

	// render the potion
	if (action == ACTION_DRINK)
		if (duration >= (Actor->PotionModel->Animations[0].NumFrames - 1) * framedur)
			RenderModelFrame(*Actor->PotionModel, *Actor->PotionTexture, 0,
				Actor->PotionModel->Animations[0].NumFrames - 1);
		else
			RenderModelAnimation(*Actor->PotionModel, *Actor->PotionTexture, 0, duration);

	if (transparency)
		if (HighDetails)
			glDisable(GL_BLEND);
		else
		{
			GLfloat diffuse[4] = {0.8f, 0.8f, 0.8f, 1.0f};
			glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
		}

	glPopMatrix();		// pop the current matrix stack
}

