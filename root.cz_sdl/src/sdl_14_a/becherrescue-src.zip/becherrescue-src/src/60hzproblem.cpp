#include "60hzproblem.h"
#ifdef WIN32
	#include <windows.h>
#endif

void Solve60HzProblem(const int MaxFrequency)
{
#ifdef WIN32
	if (!MaxFrequency)
		return;

	HDC desktop = GetDC(0);
	if (MaxFrequency != GetDeviceCaps(desktop, VREFRESH))
	{
		// get information about the actual video mode
		int newscrwidth = GetDeviceCaps(desktop, HORZRES);
		int newscrheight = GetDeviceCaps(desktop, VERTRES);
		int newbpp = GetDeviceCaps(desktop, BITSPIXEL);

		// find the highest frequency but it can equal to 'MaxFrequency' maximally
		int newfreq = 0, i = 0;
		DEVMODE devmode;
		while (EnumDisplaySettings(NULL, i++, &devmode))
			if (devmode.dmPelsWidth == newscrwidth && devmode.dmPelsHeight == newscrheight
					&& devmode.dmBitsPerPel == newbpp && devmode.dmDisplayFrequency > newfreq
					&& devmode.dmDisplayFrequency <= MaxFrequency)
				newfreq = devmode.dmDisplayFrequency;

		// set the new fullscreen
		if (newfreq)
		{
			devmode.dmScale = sizeof(devmode);
			devmode.dmPelsWidth = newscrwidth;
			devmode.dmPelsHeight = newscrheight;
			devmode.dmBitsPerPel = newbpp;
			devmode.dmDisplayFrequency = newfreq;
			devmode.dmFields = DM_PELSWIDTH | DM_PELSHEIGHT | DM_BITSPERPEL | DM_DISPLAYFREQUENCY;
			ChangeDisplaySettings(&devmode, CDS_FULLSCREEN);
		}
	}
	ReleaseDC(0, desktop);
#endif
}
