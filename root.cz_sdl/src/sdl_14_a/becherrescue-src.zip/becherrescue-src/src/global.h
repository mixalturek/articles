#ifndef GLOBAL_H
#define GLOBAL_H

#include <SDL/SDL.h>
#include "consts.h"
#ifdef USE_SDL_MIXER
	#include <SDL/SDL_mixer.h>
#endif
#include <GL/gl.h>
#include "models.h"
#include "actor.h"
#include "map.h"

#ifdef WIN32
	#include <windows.h>
#endif

extern char *ConfigFilePath;			// the name of the configuration file with its path
extern SDL_Surface *Screen;				// the screen surface
extern int DesktopFrequency;			// the monitor Hz before running this application
extern bool Is60HzProblem;				// the 60 Hz problem with full-screen is in Windows XP/2000
extern bool AreModelsLoaded;			// are all models loaded into the memory (video card)?
extern float Delay;						// delay in seconds from the last rendered frame
extern GLuint Textures[TEXTURES_NUM];	// array of texture IDs
extern Vertex LookAt;					// the point the camera is aimed
extern StructMap *Map;					// the level map
extern float Map_XLimit;				// max x-position of the camera in the map
extern int LastPicture;
extern SDL_Joystick *Joystick;
extern bool ShowFPS;
extern bool ShowQuitMessage;
extern float QuitMessage_Duration;
extern bool Paused;
extern int Difficulty;
#ifdef USE_SDL_MIXER
	extern Mix_Chunk *Sounds[SOUNDS_NUM];
#endif
extern float TotalPlay;

#ifdef WIN32
	extern BOOL ScreenSaverEnabled;
#endif

// the hero model parts
extern Model Hero_Body;
extern Model Hero_Head;
extern Model Hero_Hand_Left;
extern Model Hero_Hand_Right;
extern Model Hero_Sword;
extern Model Hero_Potion;

// the raider1 model parts
extern Model Raider1_Body;
extern Model Raider1_Head;
extern Model Raider1_Hand_Left;
extern Model Raider1_Hand_Right;
extern Model Raider1_Club;

// the raider2 model parts
extern Model Raider2_Body;
extern Model Raider2_Head;
extern Model Raider2_Hand_Left;
extern Model Raider2_Hand_Right;
extern Model Raider2_Axe;
extern Model Raider2_Helmet;

// the knight model parts
extern Model Knight_Body;
extern Model Knight_Head;
extern Model Knight_Hand_Left;
extern Model Knight_Hand_Right;
extern Model Knight_Sword;
extern Model Knight_Helmet;

extern Model Knight_Shield;

#endif

