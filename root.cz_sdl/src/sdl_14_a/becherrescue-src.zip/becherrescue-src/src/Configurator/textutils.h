// For Linux version

#ifndef TEXTUTILS_H
#define TEXTUTILS_H

#include <stdio.h>

// read one word from the file
char *ReadWord(FILE *file, char *output, const bool Decode = true);

#endif
