// For Linux version

#ifndef SETTINGS_H
#define SETTINGS_H

#define LANGUAGE_NAME_LENGTH 32

// the first joystick can be assigned to player 1 or player 2 or no-player
enum
{
	AJ_NONE = 0,
	AJ_PLAYER1,
	AJ_PLAYER2
};

// load settings from a file
bool LoadSettings(const char *FileName);

// save settings to a file
bool SaveSettings(const char *FileName);

extern char LanguageName[LANGUAGE_NAME_LENGTH];		// the language name
extern int ScreenWidth;								// the screen width
extern int ScreenHeight;							// the screen height
extern int ScreenBpp;								// the screen bits per pixel
extern int NumPlayers;
extern bool Mipmapping;								// use mipmapping?
extern bool Fullscreen;								// use fullscreen?
extern bool Filtering;								// use texture filtering?
extern bool HighDetails;
extern float Gamma;
extern int AssignJoystick;
extern bool Sound44kHz;
extern bool EnableMusic;

#endif
