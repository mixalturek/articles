// Windows version

#include <windows.h>
#include "../settings.h"
#include <conio.h>				// for 'Press any key' waiting (getch)
#include <string.h>				// string utilities
#include "config_private.h"	// contains program version info

#define	SZ_CONFIG_FILE_NAME "Becher Rescue.cfg"

bool Cestina = false;

void PressAnyKeyToClose(void)
{
	if (Cestina)
		printf("\nStiskem libovoln� kl�vesy ukon�ete");
	else
		printf("\nPress any key to close");
	getch();		// wait for key pressing
}

void FatalError(const char *text)
{
	if (Cestina)
		printf("CHYBA: %s\n", text);
	else
		printf("ERROR: %s\n", text);
	PressAnyKeyToClose();
}

void FatalError(const char *text, const char *insert)
{
	char buf[1024];
	sprintf(buf, text, insert);
	if (Cestina)
		printf("CHYBA: %s\n", buf);
	else
		printf("ERROR: %s\n", buf);
	PressAnyKeyToClose();
}

int SelectOption(const char *Options, const int MinValue, const int MaxValue, const int DefaultValue)
{
	int i;
	printf("\n");
	do
	{
		printf(Options);
		if (Cestina)
			printf("\nZadejte va� volbu [%d]: ", DefaultValue);
		else
			printf("\nEnter your option [%d]: ", DefaultValue);
		i = getch() - '0';
		if (i == -35)					// Enter key was pressed
			i = DefaultValue;
		printf("%d\n", i);
		if (i < MinValue || i > MaxValue)
			if (Cestina)
				printf("NEPLATN� VOLBA! Tady jsou spravn� volby:\n");
			else
				printf("INCORRECT OPTION! These are the correct options:\n");
	}
	while (i < MinValue || i > MaxValue);
	printf("\n");
	return i;
}

int main(int argc, char *argv[])
{
	printf(COMPANY_NAME" "FILE_DESCRIPTION" "VER_STRING"\n"
		LEGAL_COPYRIGHT"\n\n");

	// obtain the file name (with its path) where our configuration is stored
	char *ConfigFilePath;
	{
		OSVERSIONINFO os;
		os.dwOSVersionInfoSize = sizeof(os);
		if (GetVersionEx(&os))
			if (os.dwPlatformId == VER_PLATFORM_WIN32_NT)
			{
				HKEY key;
				if (RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders",
					0, KEY_READ, &key) == ERROR_SUCCESS)
				{
					DWORD size;
					if (RegQueryValueEx(key, "AppData", NULL, NULL, NULL, &size) == ERROR_SUCCESS) 	// we need obtain the size before obtaining
																									// the text (else it fails - a Windows bug)
					{
						ConfigFilePath = (char *)malloc(size + strlen("\\"SZ_CONFIG_FILE_NAME));
						if (RegQueryValueEx(key, "AppData", NULL, NULL, (LPBYTE)ConfigFilePath, &size) == ERROR_SUCCESS)
							strcat(ConfigFilePath, "\\"SZ_CONFIG_FILE_NAME);
						else
						{
							free(ConfigFilePath);
							ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
						}
					}
					else
						ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
					RegCloseKey(key);
				}
				else
					ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
			}
			else
				ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
		else
			ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
	}

	// load settings from the configuration file
	LoadSettings(ConfigFilePath);

	int option;
	char buf[1024];

	{
		printf("Select language:");

		char autodetection[128];
		{
			char *StartMenu = NULL;
			{
				HKEY key;
				if (RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders",
					0, KEY_READ, &key) == ERROR_SUCCESS)
				{
					DWORD size;
					if (RegQueryValueEx(key, "Start Menu", NULL, NULL, NULL, &size) == ERROR_SUCCESS) 	// we need obtain the size before obtaining
																										// the text (else it fails - a Windows bug)
					{
						StartMenu = (char *)malloc(size);
						if (RegQueryValueEx(key, "Start Menu", NULL, NULL, (LPBYTE)StartMenu, &size) != ERROR_SUCCESS)
						{
							free(StartMenu);
							StartMenu = NULL;
						}
					}
				}
			}
			
			if (StartMenu)
			{
				if (strstr(StartMenu, "Nab�dka"))
					strcpy(autodetection, "Cestina");
				else
					strcpy(autodetection, "English");
				free(StartMenu);
			}
			else
				strcpy(autodetection, "English");
		}

		sprintf(buf, "1: English\n2: Cestina\n3: Autodetection: %s\n4: Don't change (%s)", autodetection, LanguageName);
		option = SelectOption(buf, 1, 4, 3);
		if (option == 1)
			strcpy(LanguageName, "English");
		else if (option == 2)
		{
			strcpy(LanguageName, "Cestina");
			Cestina = true;
		}
		else if (option == 3)
		{
			strcpy(LanguageName, autodetection);
			Cestina = !strcmp(LanguageName, "Cestina");
		}
		else
			Cestina = !strcmp(LanguageName, "Cestina");
	}

	if (Cestina)
		printf("Vyberte rozli�en�:");
	else
		printf("Select resolution:");
	option = SelectOption("1: 640x480\n2: 800x600\n3: 1024x768\n4: 1280x1024", 1, 4,
		ScreenWidth == 1280 ? 4 : (ScreenWidth == 1024 ? 3: (ScreenWidth == 800 ? 2 : 1)));
	if (option == 1)
	{
		ScreenWidth = 640;
		ScreenHeight = 480;
	}
	else if (option == 2)
	{
		ScreenWidth = 800;
		ScreenHeight = 600;
	}
	else if (option == 3)
	{
		ScreenWidth = 1024;
		ScreenHeight = 768;
	}
	else
	{
		ScreenWidth = 1280;
		ScreenHeight = 1024;
	}

	if (Cestina)
		printf("Vyberte barevnou hloubku:");
	else
		printf("Select color depth:");
	option = SelectOption(Cestina ? "1: 16 bit�\n2: 32 bit�" : "1: 16 bits\n2: 32 bits", 1, 2, ScreenBpp == 32 ? 2 : 1);
	if (option == 2)
		ScreenBpp = 32;
	else
		ScreenBpp = 16;

	if (Cestina)
		printf("Hr�t v celoobrazovkov�m re�imu?");
	else
		printf("Play in full-screen?");
	Fullscreen = SelectOption(Cestina ? "1: Ano\n2: Ne" : "1: Yes\n2: No", 1, 2, Fullscreen ? 1 : 2) == 1;

	if (!SaveSettings(ConfigFilePath))
		if (Cestina)
			FatalError("Nepoda�ilo se ulo�it nastaven� do:\n%s", ConfigFilePath);
		else
			FatalError("Couldn't save settings to:\n%s", ConfigFilePath);
	else
		if (Cestina)
			printf("Nastaven� se ulo�ilo �sp��n� do:\n%s\n", ConfigFilePath);
		else
			printf("The settings were saved successfully to:\n%s\n", ConfigFilePath);

	free(ConfigFilePath);
	PressAnyKeyToClose();

	return 0;
}

