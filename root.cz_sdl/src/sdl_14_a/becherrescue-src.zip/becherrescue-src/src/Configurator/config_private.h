// THIS FILE WILL BE OVERWRITTEN BY DEV-C++!
// DO NOT EDIT!

#ifndef CONFIG_PRIVATE_H
#define CONFIG_PRIVATE_H

// VERSION DEFINITIONS
#define VER_STRING	"1.0.2.61"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	2
#define VER_BUILD	61
#define COMPANY_NAME	"Zimtech"
#define FILE_VERSION	"1.0"
#define FILE_DESCRIPTION	"Becher Rescue Configurator"
#define INTERNAL_NAME	"config"
#define LEGAL_COPYRIGHT	"Copyright (c) Zimtech 2003"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"config.exe"
#define PRODUCT_NAME	"config"
#define PRODUCT_VERSION	"1.0"

#endif //CONFIG_PRIVATE_H
