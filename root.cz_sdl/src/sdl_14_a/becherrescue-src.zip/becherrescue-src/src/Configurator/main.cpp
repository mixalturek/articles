// Linux version

//#define WIN32

#ifndef WIN32
	#define LINUX
#endif

#include <iostream>
#ifdef WIN32
	#include <stdlib>
	#include <windows.h>
	#include "../settings.h"
#else
	#include "settings.h"
#endif
#include <string>				// string utilities
#ifdef WIN32
	#include <conio.h>			// for 'Press any key' waiting (getch)
	#include "config_private.h"	// contains program version info
#endif

#define	SZ_CONFIG_FILE_NAME "Becher Rescue.cfg"

bool Cestina = false;

void PressAnyKeyToClose(void)
{
#ifdef WIN32
	if (Cestina)
		printf("\nStiskem libovolné klávesy ukončete");
	else
		printf("\nPress any key to close");
	getch();		// wait for key pressing
#endif
}

void FatalError(const char *text)
{
	if (Cestina)
		printf("CHYBA: %s\n", text);
	else
		printf("ERROR: %s\n", text);
	PressAnyKeyToClose();
}

void FatalError(const char *text, const char *insert)
{
	char buf[1024];
	sprintf(buf, text, insert);
	if (Cestina)
		printf("CHYBA: %s\n", buf);
	else
		printf("ERROR: %s\n", buf);
	PressAnyKeyToClose();
}

int SelectOption(const char *Options, const int MinValue, const int MaxValue, const int DefaultValue)
{
	int i;
	printf("\n");
	do
	{
		printf(Options);
		if (Cestina)
			printf("\nZadejte vaší volbu [%d]: ", DefaultValue);
		else
			printf("\nEnter your option [%d]: ", DefaultValue);
#ifdef WIN32
		i = getch() - '0';
		if (i == -35)					// Enter key was pressed
			i = DefaultValue;
		printf("%d\n", i);
#else
		i = getc(stdin) - '0';
		if (i == -38)					// Enter key was pressed
		{
			i = DefaultValue;
//			printf("%d\n", i);
		}
		else
			while (getc(stdin) - '0' !=  -38);
#endif
		if (i < MinValue || i > MaxValue)
			if (Cestina)
				printf("NEPLATNÁ VOLBA! Tady jsou spravné volby:\n");
			else
				printf("INCORRECT OPTION! These are the correct options:\n");
	}
	while (i < MinValue || i > MaxValue);
	printf("\n");
	return i;
}

int main(int argc, char *argv[])
{
	printf("Zimtech Becher Rescue Configurator 1.0.2.60\n"
		"Copyright (c) Zimtech 2003\n\n");

	// obtain the file name (with its path) where our configuration is stored
	char *ConfigFilePath;
#ifdef WIN32
	{
		OSVERSIONINFO os;
		os.dwOSVersionInfoSize = sizeof(os);
		if (GetVersionEx(&os))
			if (os.dwPlatformId == VER_PLATFORM_WIN32_NT)
			{
				HKEY key;
				if (RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders",
					0, KEY_READ, &key) == ERROR_SUCCESS)
				{
					DWORD size;
					if (RegQueryValueEx(key, "AppData", NULL, NULL, NULL, &size) == ERROR_SUCCESS) 	// we need obtain the size before obtaining
																									// the text (else it fails - a Windows bug)
					{
						ConfigFilePath = (char *)malloc(size + strlen("\\"SZ_CONFIG_FILE_NAME));
						if (RegQueryValueEx(key, "AppData", NULL, NULL, (LPBYTE)ConfigFilePath, &size) == ERROR_SUCCESS)
							strcat(ConfigFilePath, "\\"SZ_CONFIG_FILE_NAME);
						else
						{
							free(ConfigFilePath);
							ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
						}
					}
					else
						ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
					RegCloseKey(key);
				}
				else
					ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
			}
			else
				ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
		else
			ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
	}
#endif

	int option;
	char buf[1024];

#ifdef LINUX
	sprintf(buf, "%s/.Becher Rescue.cfg", getenv("HOME"));
	ConfigFilePath = strdup(buf);
#endif

	// load settings from the configuration file
	LoadSettings(ConfigFilePath);

	{
		printf("Select language:");

#ifdef WIN32
		char autodetection[128];
		{
			char *StartMenu = NULL;
			{
				HKEY key;
				if (RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders",
					0, KEY_READ, &key) == ERROR_SUCCESS)
				{
					DWORD size;
					if (RegQueryValueEx(key, "Start Menu", NULL, NULL, NULL, &size) == ERROR_SUCCESS) 	// we need obtain the size before obtaining
																										// the text (else it fails - a Windows bug)
					{
						StartMenu = (char *)malloc(size);
						if (RegQueryValueEx(key, "Start Menu", NULL, NULL, (LPBYTE)StartMenu, &size) != ERROR_SUCCESS)
						{
							free(StartMenu);
							StartMenu = NULL;
						}
					}
				}
			}

			if (StartMenu)
			{
				if (strstr(StartMenu, "Nabídka"))
					strcpy(autodetection, "Cestina");
				else
					strcpy(autodetection, "English");
				free(StartMenu);
			}
			else
				strcpy(autodetection, "English");
		}

		sprintf(buf, "1: English\n2: Cestina\n3: Autodetection: %s\n4: Don't change (%s)", autodetection, LanguageName);
		option = SelectOption(buf, 1, 4, 3);
#else
		sprintf(buf, "1: English\n2: Cestina\n3: Don't change (%s)", LanguageName);
		option = SelectOption(buf, 1, 3, 3);
#endif
		if (option == 1)
			strcpy(LanguageName, "English");
		else if (option == 2)
		{
			strcpy(LanguageName, "Cestina");
			Cestina = true;
		}
#ifdef WIN32
		else if (option == 3)
		{
			strcpy(LanguageName, autodetection);
			Cestina = !strcmp(LanguageName, "Cestina");
		}
#endif
		else
			Cestina = !strcmp(LanguageName, "Cestina");
	}

	if (Cestina)
		printf("Vyberte rozlišení:");
	else
		printf("Select resolution:");
	option = SelectOption("1: 640x480\n2: 800x600\n3: 1024x768\n4: 1280x1024", 1, 4,
		ScreenWidth == 1280 ? 4 : (ScreenWidth == 1024 ? 3: (ScreenWidth == 800 ? 2 : 1)));
	if (option == 1)
	{
		ScreenWidth = 640;
		ScreenHeight = 480;
	}
	else if (option == 2)
	{
		ScreenWidth = 800;
		ScreenHeight = 600;
	}
	else if (option == 3)
	{
		ScreenWidth = 1024;
		ScreenHeight = 768;
	}
	else
	{
		ScreenWidth = 1280;
		ScreenHeight = 1024;
	}

#ifdef WIN32
	if (Cestina)
		printf("Vyberte barevnou hloubku:");
	else
		printf("Select color depth:");
	option = SelectOption(Cestina ? "1: 16 bit\n2: 32 bit" : "1: 16 bits\n2: 32 bits", 1, 2, ScreenBpp == 32 ? 2 : 1);
	if (option == 2)
		ScreenBpp = 32;
	else
		ScreenBpp = 16;
#endif

	if (Cestina)
		printf("Hrát v celoobrazovkovém režimu?");
	else
		printf("Play in full-screen?");
	Fullscreen = SelectOption(Cestina ? "1: Ano\n2: Ne" : "1: Yes\n2: No", 1, 2, Fullscreen ? 1 : 2) == 1;

	if (!SaveSettings(ConfigFilePath))
		if (Cestina)
			FatalError("Nepodařilo se uložit nastavení do:\n%s", ConfigFilePath);
		else
			FatalError("Couldn't save settings to:\n%s", ConfigFilePath);
	else
	{
		if (Cestina)
			printf("Nastavení se uložilo úspěšně do:\n%s\n", ConfigFilePath);
		else
			printf("The settings were saved successfully to:\n%s\n", ConfigFilePath);
		PressAnyKeyToClose();
	}

	free(ConfigFilePath);

	return EXIT_SUCCESS;
}
