// For Linux version

#include "settings.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "textutils.h"

char LanguageName[LANGUAGE_NAME_LENGTH] = "English";
int ScreenWidth = 640;
int ScreenHeight = 480;
int ScreenBpp = 0;     					// 0 = Desktop color depth
int NumPlayers = 1;
bool Mipmapping = true;
bool Fullscreen = true;
bool Filtering = true;
bool HighDetails = true;
float Gamma = 1.0f;
int AssignJoystick = AJ_NONE;
bool Sound44kHz = true;
bool EnableMusic = true;

bool LoadSettings(const char *FileName)
{
	FILE *file = fopen(FileName, "r");			// open the text file for read-only
	if (!file)
		return false;

	char word[256];
	while (*ReadWord(file, word, false))
	{
		if (!strcmp(word, "set"))
		{
			if (!*ReadWord(file, word, false))
				break;							// it is the end of the file
			if (!strcmp(word, "language"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
 				word[LANGUAGE_NAME_LENGTH - 1] = '\0';	// a breakpoint according to the length of 'LanguageName'
 				strcpy(LanguageName, word);
 			}
			else if (!strcmp(word, "screenx"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
				ScreenWidth = strtol(word, NULL, 0);
			}
			else if (!strcmp(word, "screeny"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
				ScreenHeight = strtol(word, NULL, 0);
			}
			else if (!strcmp(word, "screenbpp"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
				ScreenBpp = strtol(word, NULL, 0);
			}
			else if (!strcmp(word, "numplayers"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
				NumPlayers = strtol(word, NULL, 0);
				if (NumPlayers != 1 && NumPlayers != 2)
					NumPlayers = 1;
			}
			else if (!strcmp(word, "mipmapping"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
				if (strtol(word, NULL, 0))		// non-zero value means true
 					Mipmapping = true;
 				else
					Mipmapping = false;			// "0" means false
			}
			else if (!strcmp(word, "fullscreen"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
				if (strtol(word, NULL, 0))		// non-zero value means true
 					Fullscreen = true;
 				else
					Fullscreen = false;			// "0" means false
			}
			else if (!strcmp(word, "filtering"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
				if (strtol(word, NULL, 0))		// non-zero value means true
 					Filtering = true;
 				else
					Filtering = false;			// "0" means false
			}
			else if (!strcmp(word, "highdetails"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
				if (strtol(word, NULL, 0))		// non-zero value means true
 					HighDetails = true;
 				else
					HighDetails = false;			// "0" means false
			}
			else if (!strcmp(word, "gamma"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
				Gamma = strtol(word, NULL, 0) / 100.0f;
			}
			else if (!strcmp(word, "assignjoy"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
				int value = strtol(word, NULL, 0);
				if (value == 1)
					AssignJoystick = AJ_PLAYER1;
				else
					if (value == 2)
						AssignJoystick = AJ_PLAYER2;
					else
						AssignJoystick = AJ_NONE;
			}
			else if (!strcmp(word, "44khzsound"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
				Sound44kHz = strtol(word, NULL, 0) == 1;
			}
			else if (!strcmp(word, "enablemusic"))
			{
				if (!*ReadWord(file, word, false))
					break;						// it is the end of the file
				EnableMusic = strtol(word, NULL, 0);
			}
		}
	}

	fclose(file);
	return true;
}

bool SaveSettings(const char *FileName)
{
	FILE *file = fopen(FileName, "w");			// open the text file for write-only
	if (!file)
		return false;

	fprintf(file, "set language %s\n", LanguageName);
	fprintf(file, "set screenx %d\n", ScreenWidth);
	fprintf(file, "set screeny %d\n", ScreenHeight);
	fprintf(file, "set screenbpp %d\n", ScreenBpp);
	fprintf(file, "set numplayers %d\n", NumPlayers);
	fprintf(file, "set mipmapping %d\n", Mipmapping ? 1 : 0);
	fprintf(file, "set fullscreen %d\n", Fullscreen ? 1 : 0);
	fprintf(file, "set filtering %d\n", Filtering ? 1 : 0);
	fprintf(file, "set highdetails %d\n", HighDetails ? 1 : 0);
	int i = int(Gamma * 100.0f);
	fprintf(file, "set gamma %d\n", i);
	fprintf(file, "set assignjoy %d\n", AssignJoystick);
	fprintf(file, "set 44khzsound %d\n", Sound44kHz ? 1 : 0);
	fprintf(file, "set enablemusic %d\n", EnableMusic ? 1 : 0);

	fclose(file);
	return true;
}
