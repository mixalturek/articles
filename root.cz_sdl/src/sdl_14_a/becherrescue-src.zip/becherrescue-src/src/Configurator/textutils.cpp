// For Linux version

#include "textutils.h"

char *ReadWord(FILE *file, char *output, const bool Decode)
{
	int c;

	// skip over spaces, tabs etc.
	do
		c = getc(file);
	while (c <= ' ' && c != EOF);

	if (c == EOF)
	{
		*output = '\0';
		return output;
	}

	// read the word
	char *curr = output;
	do
	{
		*curr++ = Decode ? c - 113 : c;
		c = getc(file);
	}
	while (c > ' ' && c != EOF);
	*curr = '\0';
	return output;
}
