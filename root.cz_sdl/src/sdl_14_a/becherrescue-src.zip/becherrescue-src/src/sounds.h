#ifndef SOUNDS_H
#define SOUNDS_H

#include "consts.h"
#ifdef USE_SDL_MIXER
	#include <SDL/SDL_mixer.h>
	#include "models.h"

	// play a sound effect
	void PlaySfx(Mix_Chunk *Sound, const Vertex Position);
#endif

#endif
