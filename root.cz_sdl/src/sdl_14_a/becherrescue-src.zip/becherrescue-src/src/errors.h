#ifndef ERRORS_H
#define ERRORS_H

// display an error message
void Error(const char *text);

// display an error message like "Cannot open file %s." where "%s" will be replaced with 'insert'
void Error(const char *text, const char *insert);

// display an error message with two "%s" which will be replaced with 'insert1' and 'insert2'
void Error(const char *text, const char *insert1, const char *insert2);

// display an error message and terminate the application
void FatalError(const char *text);

// display an error message like "Cannot open file %s.", where "%s" will be replaced with 'insert',
// and terminate the application
void FatalError(const char *text, const char *insert);

// display an error message with two "%s" which will be replaced with 'insert1' and 'insert2'
// and terminate the application
void FatalError(const char *text, const char *insert1, const char *insert2);

#endif

