#include "texts.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *Texts[TEXTS_NUM];
bool TextsAreLoaded = false;

bool LoadTexts(const char *FileName)
{
	FILE *file = fopen(FileName, "r");			// open the text file for read-only
	if (!file)
		return false;

	char line[4096], *curr;
	int c;

	for (int i = 0; i < TEXTS_NUM; i++)
	{
		do
			c = getc(file);
		while (c == '\n' || c == '\r');			// skip empty lines

		if (c == EOF)							// is end of file?
		{
			fclose(file);
			for (int j = 0; j < i; j++)			// free the alocated memory for previous texts
				free(Texts[i]);
			return false;
		}

		curr = line;							// 'curr' points to the start of 'line'

		// read a line ('c' contains the first character)
		do
		{
			*curr++ = c == '|' ? '\n' : c;		// '|' in text is replaced with '\n'
			c = getc(file);
		}
		while (c != '\n' && c != '\r' && c != EOF);
		*curr = '\0';

		// alloc a memory and copy the texts to it
		if (!(Texts[i] = strdup(line)))
		{
			fclose(file);
			for (int j = 0; j < i; j++)			// free the alocated memory for previous texts
				free(Texts[i]);
			return false;
		}
	}

	fclose(file);
	TextsAreLoaded = true;
	return true;
}

void ReleaseTexts()
{
	if (!TextsAreLoaded)
		return;

	for (int i = 0; i < TEXTS_NUM; i++)
		free(Texts[i]);
	TextsAreLoaded = false;
}

