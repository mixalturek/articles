#include "game.h"
#include <GL/gl.h>
#include <GL/glu.h>
#include "global.h"
#include "scene.h"
#include "map.h"
#include <string.h>
#include "texts.h"
#include "errors.h"
#include <math.h>								// for floor()
#include "settings.h"
#include "music.h"
#include "menu.h"
#ifndef WIN32
	#include <stdlib.h>
#endif

int AppState = APP_STARTING;					// the state of the application
float AppState_Duration = 0.0f;					// the duration of the app state
int Stage = 0;									// current stage

void Game_KeyPress(const SDLKey Key)
{
	if (AppState == APP_MENU)
		switch (Key)
		{
			case SDLK_ESCAPE:
				if (MenuState == MENU_MENUSTATE)
				{
					AppState = APP_MENU_EXIT;
					AppState_Duration = 0.0f;
				}
				else if (MenuState == PROLOGUE_MENUSTATE)
				{
					AppState = APP_MENU_FADE_OUT;
					AppState_Duration = 0.0f;
				}
				else if (MenuState == EPILOGUE_MENUSTATE)
					SetMenuState(SCORETAB_MENUSTATE);
				else
					SetMenuState(MENU_MENUSTATE);
				break;
			case SDLK_RETURN:
			case SDLK_SPACE:
				if (MenuState == PROLOGUE_MENUSTATE)
				{
					AppState = APP_MENU_FADE_OUT;
					AppState_Duration = 0.0f;
				}
				else if (MenuState == EPILOGUE_MENUSTATE)
					SetMenuState(SCORETAB_MENUSTATE);
				else if (MenuState != MENU_MENUSTATE)
					SetMenuState(MENU_MENUSTATE);
				break;
			case SDLK_F1:
				if (MenuState == MENU_MENUSTATE)
					SetMenuState(PROLOGUE_MENUSTATE);
				else if (MenuState == PROLOGUE_MENUSTATE)
				{
					AppState = APP_MENU_FADE_OUT;
					AppState_Duration = 0.0f;
				}

				break;
			case SDLK_F2:
				if (MenuState == MENU_MENUSTATE)
					NumPlayers = NumPlayers == 1 ? 2 : 1;
				break;
			case SDLK_F3:
				if (MenuState == MENU_MENUSTATE)
					if (++Difficulty == 3)
						Difficulty = 0;
				break;
			case SDLK_F4:
				if (MenuState == MENU_MENUSTATE)
					if (++AssignJoystick == 3)
						AssignJoystick = 0;
				break;
			case SDLK_F5:
				if (MenuState == MENU_MENUSTATE)
					SetMenuState(SCORETAB_MENUSTATE);
				break;
			case SDLK_F6:
				if (MenuState == MENU_MENUSTATE)
					SetMenuState(HELP_MENUSTATE);
				break;
			case SDLK_F7:
				if (MenuState == MENU_MENUSTATE)
					SetMenuState(CREDITS_MENUSTATE);
				break;
			default:
				break;
		}
	else if (AppState == APP_GAME)
		switch (Key)
		{
			case SDLK_ESCAPE:
				if (!ShowQuitMessage)
				{
					ShowQuitMessage = true;
					QuitMessage_Duration = 0.0f;
 				}
				else
				{
					AppState = APP_GAME_FADE_OUT;
					AppState_Duration = 0.0f;
				}
				break;
			case SDLK_SPACE:
				if (AppState_Duration < 4.0f)		// space key hides stage info text
					AppState_Duration = 4.0f;
				else
					Paused = !Paused;
				break;
			default:
				break;
		}
}

void UpdateGame()
{
	if (AppState_Duration < 4.0f)
		AppState_Duration += Delay;

	if (AppState == APP_STARTING)
	{
		LoadMenuData();
		SetMenuState(MENU_MENUSTATE, false);
		AppState = APP_MENU_FADE_IN;
		AppState_Duration = 0.0f;

		PlayMusic("music/menu.ogg", 0.6f);
	}
	else if (AppState == APP_MENU_FADE_IN && AppState_Duration > 1.0f)
	{
		AppState = APP_MENU;
		SetLightIntensity(1.0f);
	}
	else if (AppState == APP_MENU_EXIT && AppState_Duration > 1.0f)
		exit(0);
	else if (AppState == APP_MENU_FADE_OUT && AppState_Duration > 1.0f)
	{	// new game is started
		ReleaseMenu();

		AppState = APP_GAME_FADE_IN;
		AppState_Duration = 0.0f;
		TotalPlay = 0.0f;

		glMatrixMode(GL_PROJECTION);						// select the projection matrix
		glLoadIdentity();									// reset the projection matrix
		gluPerspective(30.0, 4.0 / 3.0, 6.0, 27.0);
		glMatrixMode(GL_MODELVIEW);							// select the modelview matrix

		// setup lights
		{
			if (Stage > 2)
			{	// it is dusk
				GLfloat light_ambient[4] = {0.5f, 0.10f, 0.25f, 1.0f};
				GLfloat light_diffuse[4] = {0.10f, 0.15f, 0.35f, 1.0f};
				glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
				glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
				glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient);
				glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);

				GLfloat light2_ambient[4] = {0.0f, 0.0f, 0.0f, 1.0f};
				GLfloat light2_diffuse[4] = {1.0f, 1.0f, 0.0f, 1.0f};
				if (Actors[PLAYER1].Used && Actors[PLAYER2].Used)
				{
					*light2_diffuse *= 0.5f;
					light2_diffuse[1] *= 0.5f;
				}
				glLightfv(GL_LIGHT2, GL_AMBIENT, light2_ambient);
				glLightfv(GL_LIGHT2, GL_DIFFUSE, light2_diffuse);
				glLightfv(GL_LIGHT3, GL_AMBIENT, light2_ambient);
				glLightfv(GL_LIGHT3, GL_DIFFUSE, light2_diffuse);
			}
			else
			{	// it is day
				GLfloat light_ambient[4] = {0.5f, 0.5f, 0.5f, 1.0f};
				GLfloat light_diffuse[4] = {0.5f, 0.5f, 0.5f, 1.0f};
				glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
				glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
				glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient);
				glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);
			}

			GLfloat light0_position[4] = {-20.0f, 100.0f, -20.0f, 0.0f};	// the light is directional (w = 0)
			GLfloat light0_spotdirection[3] = {0.2f, -1.0f, 0.0f};

			glLightfv(GL_LIGHT0, GL_POSITION, light0_position);
			glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, light0_spotdirection);
			glEnable(GL_LIGHT0);

			GLfloat light1_position[4] = {0.0f, 100.0f, 100.0f, 0.0f};		// the light is directional (w = 0)
			GLfloat light1_spotdirection[3] = {0.0f, 1.0f, 0.0f};

			glLightfv(GL_LIGHT1, GL_POSITION, light1_position);
			glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, light1_spotdirection);
			glEnable(GL_LIGHT1);
		}

		// setup players
		for (ACTOR *actor = Actors; actor < &Actors[ENEMY0]; actor++)
		{
			actor->Health = MAX_HEALTH_HERO;
			actor->Immortal = false;
			actor->Immortal_Duration = 0.0f;
			actor->Credits = 5;
			actor->Bottles = Difficulty ? (Difficulty == 1 ? 5 : 3) : 7;
			actor->TotalDamage = 0;
		}

		Stage = 1;
		LookAt.X = 0.0f;
		Paused = false;

		char path[1024];
		sprintf(path, "maps/stage%d.brx", Stage);
		if (!LoadMap(path, &Map))
			FatalError(Texts[T_COULDNT_LOAD_MAP], path);

		Actors[PLAYER1].Used = true;
		Actors[PLAYER2].Used = NumPlayers == 2;

		if (Actors[PLAYER2].Used)
		{
			Map_XLimit = floor((Actors[PLAYER1].Position.X > Actors[PLAYER2].Position.X ? Actors[PLAYER1].Position.X : Actors[PLAYER2].Position.X) / 8.0f) * 8.0f + 8.0f;
			if (Stage > 2)
			{
				glEnable(GL_LIGHT2);
				glEnable(GL_LIGHT3);
			}
			else
			{
				glDisable(GL_LIGHT2);
				glDisable(GL_LIGHT3);
			}
		}
		else
		{
			Map_XLimit = floor(Actors[PLAYER1].Position.X / 8.0f) * 8.0f + 8.0f;
			if (Stage > 2)
				glEnable(GL_LIGHT2);
			else
				glDisable(GL_LIGHT2);
		}

		PlayMusic("music/ingame.ogg", 0.15f);
	}
	else if (AppState == APP_GAME_FADE_IN && AppState_Duration > 1.0f)
	{
		AppState = APP_GAME;
		SetLightIntensity(1.0f);
	}
	else if (AppState == APP_GAME_FADE_OUT && AppState_Duration > 1.0f)
	{
		if (!ShowQuitMessage && (Actors[PLAYER1].Used || Actors[PLAYER2].Used))	// a hero lives
		{
			// unload current map
			ReleaseMap(&Map);

			if (Stage == 4)				// this is the last stage
			{
				LoadMenuData();
				SetMenuState(EPILOGUE_MENUSTATE, false);
				AppState = APP_MENU_FADE_IN;

				PlayMusic("music/menu.ogg", 0.6f);
			}
			else
			{
				// load the next map
				char path[1024];
				sprintf(path, "maps/stage%d.brx", ++Stage);
				if (!LoadMap(path, &Map))
					FatalError(Texts[T_COULDNT_LOAD_MAP], path);

				if (Stage > 2)
				{	// it is dusk
					GLfloat light_ambient[4] = {0.5f, 0.10f, 0.25f, 1.0f};
					GLfloat light_diffuse[4] = {0.10f, 0.15f, 0.35f, 1.0f};
					glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
					glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
					glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient);
					glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);

					GLfloat light2_ambient[4] = {0.0f, 0.0f, 0.0f, 1.0f};
					GLfloat light2_diffuse[4] = {1.0f, 1.0f, 0.0f, 1.0f};
					if (Actors[PLAYER1].Used && Actors[PLAYER2].Used)
					{
						*light2_diffuse *= 0.5f;
						light2_diffuse[1] *= 0.5f;
					}
					glLightfv(GL_LIGHT2, GL_AMBIENT, light2_ambient);
					glLightfv(GL_LIGHT2, GL_DIFFUSE, light2_diffuse);
					glLightfv(GL_LIGHT3, GL_AMBIENT, light2_ambient);
					glLightfv(GL_LIGHT3, GL_DIFFUSE, light2_diffuse);
				}
				else
				{	// it is day
					GLfloat light_ambient[4] = {0.5f, 0.5f, 0.5f, 1.0f};
					GLfloat light_diffuse[4] = {0.5f, 0.5f, 0.5f, 1.0f};
					glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
					glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
					glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient);
					glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);
				}

				if (Actors[PLAYER1].Used)
					if (Actors[PLAYER2].Used)
					{
						Map_XLimit = floor((Actors[PLAYER1].Position.X > Actors[PLAYER2].Position.X ? Actors[PLAYER1].Position.X : Actors[PLAYER2].Position.X) / 8.0f) * 8.0f + 8.0f;
						if (Stage > 2)
						{
							glEnable(GL_LIGHT2);
							glEnable(GL_LIGHT3);
						}
						else
						{
							glDisable(GL_LIGHT2);
							glDisable(GL_LIGHT3);
						}
					}
					else
					{
						Map_XLimit = floor(Actors[PLAYER1].Position.X / 8.0f) * 8.0f + 8.0f;
						if (Stage > 2)
							glEnable(GL_LIGHT2);
						else
							glDisable(GL_LIGHT2);
					}
				else
				{
					Map_XLimit = floor(Actors[PLAYER2].Position.X / 8.0f) * 8.0f + 8.0f;
					if (Stage > 2)
						glEnable(GL_LIGHT3);
					else
						glDisable(GL_LIGHT3);
				}

				LookAt.X = 0.0f;

				AppState = APP_GAME_FADE_IN;
			}
			AppState_Duration = 0.0f;
		}
		else
		{
			ShowQuitMessage = false;
			ReleaseMap(&Map);			// unload current map

			LoadMenuData();
			SetMenuState(SCORETAB_MENUSTATE, false);
			AppState = APP_MENU_FADE_IN;
			AppState_Duration = 0.0f;

			PlayMusic("music/menu.ogg", 0.6f);
		}
	}

	if (AppState == APP_GAME)									// in game
		if (!Actors[PLAYER1].Used && !Actors[PLAYER2].Used)		// no player lefts
		{
			AppState = APP_GAME_FADE_OUT;
			AppState_Duration = 0.0f;
		}
		else
		{
			bool IsEnemy = false;

			ACTOR *end_actor = &Actors[MAX_ACTORS];
			for (ACTOR *actor = &Actors[ENEMY0]; actor < end_actor; actor++)
				if (actor->Used)
				{
					IsEnemy = true;
					break;
				}

			if (!IsEnemy)										// no enemy lefts
			{
				AppState = APP_GAME_FADE_OUT;
				AppState_Duration = 0.0f;
			}
		}

	if (AppState == APP_GAME_FADE_IN || AppState == APP_MENU_FADE_IN)
		SetLightIntensity(AppState_Duration);
	else
		if (AppState == APP_GAME_FADE_OUT || AppState == APP_MENU_FADE_OUT || AppState == APP_MENU_EXIT)
			SetLightIntensity(1.0f - AppState_Duration);

	if (AppState >= APP_GAME_FADE_IN && AppState <= APP_GAME_FADE_OUT)
	{
		if (!Paused)
		{
			UpdateAllActors();			// update all actors
			TotalPlay += Delay;
		}
		RenderScene();					// render the scene
	}
	else if ((AppState >= APP_MENU_FADE_IN && AppState <= APP_MENU_FADE_OUT) || AppState == APP_MENU_EXIT)
	{
		RenderMenu();					// render the menu
	}
}
