#ifndef KEYS_H
#define KEYS_H

#include <SDL/SDL.h>

// important keys for remembering
enum
{
	PLAYER1_DOWN_KEY = 0,
	PLAYER1_RDOWN_KEY,
	PLAYER1_RIGHT_KEY,
	PLAYER1_RUP_KEY,
	PLAYER1_UP_KEY,
	PLAYER1_LUP_KEY,
	PLAYER1_LEFT_KEY,
	PLAYER1_LDOWN_KEY,
	PLAYER1_FIRE_KEY,
	PLAYER1_JUMP_KEY,
	PLAYER1_MAGIC_KEY,
	PLAYER2_DOWN_KEY,
	PLAYER2_RDOWN_KEY,
	PLAYER2_RIGHT_KEY,
	PLAYER2_RUP_KEY,
	PLAYER2_UP_KEY,
	PLAYER2_LUP_KEY,
	PLAYER2_LEFT_KEY,
	PLAYER2_LDOWN_KEY,
	PLAYER2_FIRE_KEY,
	PLAYER2_JUMP_KEY,
	PLAYER2_MAGIC_KEY,
	KEYS_NUM
};

extern int Keys[KEYS_NUM];		// the pressed keys (0 = released, 1 = first pressed, 2 = repeatedly pressed)
extern Uint32 KeysPressTime[KEYS_NUM];		// the time the keys were pressed
extern Uint32 KeysPressTimePrev[KEYS_NUM];	// the previous time the keys were pressed

// call this function if some key is released (Down = 0) or pressed (Down = 1)
void KeyEvent(const SDLKey Key, const bool Down);

#endif

