#include "errors.h"
#include <stdio.h>
#ifdef WIN32
	#include <windows.h>
#endif
#include "texts.h"
#include "finalization.h"
#ifndef WIN32
	#include <stdlib.h>
#endif

void Error(const char *text)
{
#ifdef WIN32
	MessageBox(0, text, TextsAreLoaded ? Texts[T_ERROR] : "Error", MB_ICONSTOP);
#else
	printf(TextsAreLoaded ? Texts[T_ERROR] : "Error");
	printf(": ");
	printf(text);
	printf("\n");
#endif
}

void Error(const char *text, const char *insert)
{
	char msg[4096];
	sprintf(msg, text, insert);
	Error(msg);
}

void Error(const char *text, const char *insert1, const char *insert2)
{
	char msg[4096];
	sprintf(msg, text, insert1, insert2);
	Error(msg);
}

void FatalError(const char *text)
{
	Error(text);
	exit(1);
}

void FatalError(const char *text, const char *insert)
{
	Error(text, insert);
	exit(1);
}

void FatalError(const char *text, const char *insert1, const char *insert2)
{
	Error(text, insert1, insert2);
	exit(1);
}
