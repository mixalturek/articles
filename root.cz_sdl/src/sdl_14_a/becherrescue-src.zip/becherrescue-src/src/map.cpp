#include "map.h"
#include <stdlib.h>
#include <GL/gl.h>
#include "textutils.h"
#include "scene.h"
#include <string.h>
#include "textures.h"
#include "global.h"
#include "settings.h"

#define MAX_FIELD_MODELS		128

static FieldModel *FieldModels[MAX_FIELD_MODELS] = {0};

bool LoadMap(const char *PathName, StructMap **Map)
{
	if (!(*Map = new StructMap))
		return false;

	(*Map)->Fields = NULL;

	FILE *file = fopen(PathName, "rb");			// open the file for read-only
	if (!file)
		return false;

	char word[1024];

	// test the format of the file
	if (!*ReadWord(file, word, false))			// is it this the end of the file?
	{
		fclose(file);
		return false;
	}
	if (strcmp(word, "Zimtech"))
	{
		fclose(file);
		return false;
	}
	if (!*ReadWord(file, word, false))			// is it this the end of the file?
	{
		fclose(file);
		return false;
	}
	if (strcmp(word, "Map"))
	{
		fclose(file);
		return false;
	}
	if (!*ReadWord(file, word))					// is it this the end of the file?
	{
		fclose(file);
		return false;
	}
	if (strcmp(word, "version"))
	{
		fclose(file);
		return false;
	}
	if (!*ReadWord(file, word))					// is it this the end of the file?
	{
		fclose(file);
		return false;
	}
	if (strcmp(word, "1.0"))
	{
		fclose(file);
		return false;
	}

	char fieldnames[256][32];
	for (int i = 0; i < 256; i++)
		*fieldnames[i] = '\0';
	FieldModel *fieldmodels[256];
	for (int i = 0; i < 256; i++)
		fieldmodels[i] = NULL;

	(*Map)->Width = -1;
	(*Map)->Length = -1;

	Actors[PLAYER1].Position.X = 0.5f;
	Actors[PLAYER1].Position.Y = 0.5f;
	Actors[PLAYER1].Action = ACTION_STAY;
	Actors[PLAYER1].Direction = DIRECTION_EAST;
	Actors[PLAYER1].Duration = 0.0f;

	Actors[PLAYER2].Position.X = 0.5f;
	Actors[PLAYER2].Position.Y = 1.5f;
	Actors[PLAYER2].Action = ACTION_STAY;
	Actors[PLAYER2].Direction = DIRECTION_EAST;
	Actors[PLAYER2].Duration = 0.48f;

	ACTOR *end_actor = &Actors[MAX_ACTORS];
	for (ACTOR *actor = &Actors[ENEMY0]; actor < end_actor; actor++)
		actor->Used = false;

	ACTOR *current_enemy = &Actors[ENEMY0];

	while (*ReadWord(file, word))
	{
		if (!strcmp(word, "width"))
		{
			if (!*ReadWord(file, word))
				break;							// it is the end of the file
			(*Map)->Width = strtol(word, NULL, 0);
 		}
		else if (!strcmp(word, "length"))
		{
			if (!*ReadWord(file, word))
				break;							// it is the end of the file
			(*Map)->Length = strtol(word, NULL, 0);
		}
		else if (!strcmp(word, "player1_posx"))
		{
			if (!*ReadWord(file, word))
				break;							// it is the end of the file
			Actors[PLAYER1].Position.X = strtol(word, NULL, 0) + 0.5f;
		}
		else if (!strcmp(word, "player1_posy"))
		{
			if (!*ReadWord(file, word))
				break;							// it is the end of the file
			Actors[PLAYER1].Position.Y = strtol(word, NULL, 0) + 0.5f;
		}
		else if (!strcmp(word, "player2_posx"))
		{
			if (!*ReadWord(file, word))
				break;							// it is the end of the file
			Actors[PLAYER2].Position.X = strtol(word, NULL, 0) + 0.5f;
		}
		else if (!strcmp(word, "player2_posy"))
		{
			if (!*ReadWord(file, word))
				break;							// it is the end of the file
			Actors[PLAYER2].Position.Y = strtol(word, NULL, 0) + 0.5f;
		}
		else if (!strcmp(word, "field"))
		{
			if (!*ReadWord(file, word))
				break;							// it is the end of the file
			int i = word[0];
			if (!*ReadWord(file, word))
				break;							// it is the end of the file
			if (strlen(word) > 31)
			{
				fclose(file);
				return false;
			}
			strcpy(fieldnames[i], word);
		}
		else if (!strcmp(word, "fields"))
		{
			if ((*Map)->Width == -1 || (*Map)->Length == -1 || (*Map)->Fields)
			{
				fclose(file);
				return false;
			}

			// load field models
			FieldModel **curr = FieldModels;
			for (int i = 0; i < 256; i++)
				if (*fieldnames[i] && strcmp(fieldnames[i], "<NOTHING>"))
				{
					// alloc memory
					if (!(*curr = new FieldModel))
					{
						fclose(file);
						return false;
					}
					fieldmodels[i] = *curr;

					(*curr)->Width = 1;
					(*curr)->Length = 1;
					(*curr)->Heights = NULL;
					for (int j = 0; j < MAX_MODELS_IN_FIELD; j++)
						(*curr)->Models[j] = NULL;
					(*curr)->IsWater = false;

					// open the file with information about this field
					char buf[1024];
					sprintf(buf, "models/terrain/%s.brx", fieldnames[i]);
					FILE *fieldfile = fopen(buf, "rb");			// open the file for read-only
					if (!fieldfile)
					{
						fclose(file);
						return false;
					}

					// test the format of the file
					if (!*ReadWord(fieldfile, word, false))					// is it this the end of the file?
					{
						fclose(fieldfile);
						fclose(file);
						return false;
					}
					if (strcmp(word, "Zimtech"))
					{
						fclose(fieldfile);
						fclose(file);
						return false;
					}
					if (!*ReadWord(fieldfile, word, false))					// is it this the end of the file?
					{
						fclose(fieldfile);
						fclose(file);
						return false;
					}
					if (strcmp(word, "Area"))
					{
						fclose(fieldfile);
						fclose(file);
						return false;
					}
					if (!*ReadWord(fieldfile, word))					// is it this the end of the file?
					{
						fclose(fieldfile);
						fclose(file);
						return false;
					}
					if (strcmp(word, "version"))
					{
						fclose(fieldfile);
						fclose(file);
						return false;
					}
					if (!*ReadWord(fieldfile, word))					// is it this the end of the file?
					{
						fclose(fieldfile);
						fclose(file);
						return false;
					}
					if (strcmp(word, "1.0"))
					{
						fclose(fieldfile);
						fclose(file);
						return false;
					}

					// load field data
					while (*ReadWord(fieldfile, word))
					{
						if (!strcmp(word, "model"))
						{
							if (!*ReadWord(fieldfile, word))
							{
								fclose(fieldfile);
								fclose(file);
								return false;
							}
							int j = strtol(word, NULL, 0);
							if (!*ReadWord(fieldfile, word))
							{
								fclose(fieldfile);
								fclose(file);
								return false;
							}
							if (!strcmp(word, "transparent"))
							{
								(*curr)->Class[j] = FIELD_CLASS_TRANSPARENT;
								if (!*ReadWord(fieldfile, word))
								{
									fclose(fieldfile);
									fclose(file);
									return false;
								}
							}
							else
								if (!strcmp(word, "grass"))
								{
									(*curr)->Class[j] = FIELD_CLASS_GRASS;
									if (!*ReadWord(fieldfile, word))
									{
										fclose(fieldfile);
										fclose(file);
										return false;
									}
								}
								else
									(*curr)->Class[j] = FIELD_CLASS_NORMAL;
							sprintf(buf, "models/terrain/%s.br", word);
							if (!*ReadWord(fieldfile, word))
							{
								fclose(fieldfile);
								fclose(file);
								return false;
							}

							(*curr)->Models[j] = new Model;

							if (!LoadModel(buf, (*curr)->Models[j]))
							{
								delete (*curr)->Models[j];
								(*curr)->Models[j] = NULL;
								fclose(fieldfile);
								fclose(file);
								return false;
							}

							sprintf(buf, "textures/terrain/%s", word);
							if (!LoadTexture(buf, &(*curr)->Textures[j], (*curr)->Class[j]))
							{
								ReleaseModel((*curr)->Models[j]);
								delete (*curr)->Models[j];
								(*curr)->Models[j] = NULL;
								fclose(fieldfile);
								fclose(file);
								return false;
							}
				 		}
						else if (!strcmp(word, "width"))
						{
							if (!*ReadWord(fieldfile, word))
							{
								fclose(fieldfile);
								fclose(file);
								return false;
							}
							(*curr)->Width = strtol(word, NULL, 0);
						}
						else if (!strcmp(word, "length"))
						{
							if (!*ReadWord(fieldfile, word))
							{
								fclose(fieldfile);
								fclose(file);
								return false;
							}
							(*curr)->Length = strtol(word, NULL, 0);
						}
						else if (!strcmp(word, "heights"))
						{
							if (!((*curr)->Heights = new float[(*curr)->Width * (*curr)->Length]))
							{
								fclose(fieldfile);
								fclose(file);
								return false;
							}

							float *end = &(*curr)->Heights[(*curr)->Width * (*curr)->Length];
							for (float *current = (*curr)->Heights; current < end; current++)
							{
								if (!*ReadWord(fieldfile, word))
								{
									fclose(fieldfile);
									fclose(file);
									return false;
								}
								*current = strtod(word, NULL);
							}
						}
						else if (!strcmp(word, "water"))
						{
							(*curr)->IsWater = true;
						}
					}

					fclose(fieldfile);
					curr++;
				}

			if (!((*Map)->Fields = new Field[(*Map)->Width * (*Map)->Length]))
			{
				fclose(file);
				return false;
			}

			// load fields
			Field *end = &(*Map)->Fields[(*Map)->Width * (*Map)->Length];
			for (Field *field = (*Map)->Fields; field < end; field++)
			{
				if (!*ReadWord(file, word))
				{								// it is the end of the file
					fclose(file);
					return false;
				}
				field->Model = fieldmodels[word[0]];
				field->Height = word[1] - '0';
			}
		}
		else if (!strcmp(word, "enemy"))
		{
			if (!*ReadWord(file, word))
				break;							// it is the end of the file
			current_enemy->Class = -1;			// undefined value
			if (!strcmp(word, "raider1"))
				current_enemy->Class = CLASS_RAIDER1;
			else
				if (!strcmp(word, "raider2"))
					current_enemy->Class = CLASS_RAIDER2;
				else
					if (!strcmp(word, "knight"))
						current_enemy->Class = CLASS_KNIGHT;
					else
						break;					// unknown class

			if (!*ReadWord(file, word))
				break;						// it is the end of the file
			int modification = strtol(word, NULL, 0);

			if (!*ReadWord(file, word))
				break;						// it is the end of the file
			current_enemy->Position.X = strtol(word, NULL, 0) + 0.5f;

			if (!*ReadWord(file, word))
				break;						// it is the end of the file
			current_enemy->Position.Y = strtol(word, NULL, 0) + 0.5f;

			current_enemy->Position.Z = 100.0f;		// default value

			if (!*ReadWord(file, word))
				break;						// it is the end of the file
			current_enemy->Health = strtol(word, NULL, 0);
			if (!Difficulty)
				current_enemy->Health = int(0.8f * (float)current_enemy->Health);
			else
				if (Difficulty == 2)
					current_enemy->Health = int(1.2f * (float)current_enemy->Health);
			if (NumPlayers == 2)
				current_enemy->Health = int(1.2f * (float)current_enemy->Health);

			if (!*ReadWord(file, word))
				break;						// it is the end of the file
			current_enemy->Damage = strtol(word, NULL, 0);
			if (!Difficulty)
				current_enemy->Damage = int(0.8f * (float)current_enemy->Damage);
			else
				if (Difficulty == 2)
					current_enemy->Damage = int(1.2f * (float)current_enemy->Damage);
			if (NumPlayers == 2)
				current_enemy->Damage = int(1.2f * (float)current_enemy->Damage);

			current_enemy->FallSpeed = HERO_FALL_SPEED;
			current_enemy->LyingTime = HERO_LYING_TIME;
			current_enemy->FlyingTime = HERO_FLYING_TIME;
			current_enemy->BlockingTime = HERO_BLOCKING_TIME;
			current_enemy->Action = ACTION_STAY;
			current_enemy->Direction = DIRECTION_WEST;
			current_enemy->Duration = 0.0f;
			current_enemy->Target = NULL;
			current_enemy->Immortal = false;
			current_enemy->Immortal_Duration = 0.0f;
			current_enemy->Credits = 0;
			current_enemy->Bottles = 0;
			current_enemy->TotalDamage = 0;

			if (current_enemy->Class != CLASS_KNIGHT)		// it is a raider1 or a raider2
			{
				current_enemy->Radius = BODY_RADIUS;
				current_enemy->Height = BODY_HEIGHT;
				current_enemy->HitRadius = HIT_RADIUS;
				current_enemy->HitShift = HIT_SHIFT;
				current_enemy->HitHeight = HIT_HEIGHT;
				current_enemy->ShieldModel = NULL;
				current_enemy->PotionModel = NULL;
				current_enemy->ShieldTexture = NULL;
				current_enemy->PotionTexture = NULL;

				if (current_enemy->Class == CLASS_RAIDER1)
				{
					current_enemy->WalkSpeed = 0.8f * HERO_WALK_SPEED;
					current_enemy->RunSpeed = 0.7f * HERO_RUN_SPEED;
					current_enemy->BodyModel = &Raider1_Body;
					current_enemy->HeadModel = &Raider1_Head;
					current_enemy->HandLeftModel = &Raider1_Hand_Left;
					current_enemy->HandRightModel = &Raider1_Hand_Right;
					current_enemy->WeaponModel = &Raider1_Club;
					current_enemy->HelmetModel = NULL;
					current_enemy->HelmetTexture = NULL;

					if (!modification)
					{
						current_enemy->BodyTexture = &Textures[RAIDER1_BODY_TEXTURE1];
						current_enemy->HeadTexture = &Textures[RAIDER1_HEAD_TEXTURE1];
						current_enemy->HandTexture = &Textures[RAIDER1_HAND_TEXTURE1];
						current_enemy->WeaponTexture = &Textures[RAIDER1_CLUB_TEXTURE1];
					}
					else if (modification == 1)
					{
						current_enemy->BodyTexture = &Textures[RAIDER1_BODY_TEXTURE2];
						current_enemy->HeadTexture = &Textures[RAIDER1_HEAD_TEXTURE2];
						current_enemy->HandTexture = &Textures[RAIDER1_HAND_TEXTURE2];
						current_enemy->WeaponTexture = &Textures[RAIDER1_CLUB_TEXTURE2];
					}
					else
					{
						current_enemy->BodyTexture = &Textures[RAIDER1_BODY_TEXTURE3];
						current_enemy->HeadTexture = &Textures[RAIDER1_HEAD_TEXTURE3];
						current_enemy->HandTexture = &Textures[RAIDER1_HAND_TEXTURE3];
						current_enemy->WeaponTexture = &Textures[RAIDER1_CLUB_TEXTURE3];
					}
				}
				else
				{
					current_enemy->WalkSpeed = 0.9f * HERO_WALK_SPEED;
					current_enemy->RunSpeed = 0.8f * HERO_RUN_SPEED;
					current_enemy->BodyModel = &Raider2_Body;
					current_enemy->HeadModel = &Raider2_Head;
					current_enemy->HandLeftModel = &Raider2_Hand_Left;
					current_enemy->HandRightModel = &Raider2_Hand_Right;
					current_enemy->WeaponModel = &Raider2_Axe;
					current_enemy->HelmetModel = &Raider2_Helmet;

					if (!modification)
					{
						current_enemy->BodyTexture = &Textures[RAIDER2_BODY_TEXTURE1];
						current_enemy->HeadTexture = &Textures[RAIDER2_HEAD_TEXTURE1];
						current_enemy->HandTexture = &Textures[RAIDER2_HAND_TEXTURE1];
						current_enemy->WeaponTexture = &Textures[RAIDER2_AXE_TEXTURE1];
						current_enemy->HelmetTexture = &Textures[RAIDER2_HELMET_TEXTURE1];
					}
					else if (modification == 1)
					{
						current_enemy->BodyTexture = &Textures[RAIDER1_BODY_TEXTURE2];
						current_enemy->HeadTexture = &Textures[RAIDER1_HEAD_TEXTURE2];
						current_enemy->HandTexture = &Textures[RAIDER1_HAND_TEXTURE2];
						current_enemy->WeaponTexture = &Textures[RAIDER2_AXE_TEXTURE1];
						current_enemy->HelmetTexture = &Textures[RAIDER2_HELMET_TEXTURE1];
					}
					else
					{
						current_enemy->BodyTexture = &Textures[RAIDER1_BODY_TEXTURE3];
						current_enemy->HeadTexture = &Textures[RAIDER1_HEAD_TEXTURE3];
						current_enemy->HandTexture = &Textures[RAIDER1_HAND_TEXTURE3];
						current_enemy->WeaponTexture = &Textures[RAIDER2_AXE_TEXTURE3];
						current_enemy->HelmetTexture = &Textures[RAIDER2_HELMET_TEXTURE1];
					}
				}
			}
			else		// it is a knight
			{
				current_enemy->WalkSpeed = 0.7f * HERO_WALK_SPEED;
				current_enemy->RunSpeed = 0.7f * HERO_RUN_SPEED;
				current_enemy->BodyModel = &Knight_Body;
				current_enemy->HeadModel = &Knight_Head;
				current_enemy->HandLeftModel = &Knight_Hand_Left;
				current_enemy->HandRightModel = &Knight_Hand_Right;
				current_enemy->WeaponModel = &Knight_Sword;
				current_enemy->HelmetModel = &Knight_Helmet;
				current_enemy->ShieldModel = &Knight_Shield;
				current_enemy->PotionModel = NULL;
				current_enemy->PotionTexture = NULL;

				if (!modification)
				{
					current_enemy->Radius = BODY_RADIUS * 1.2f;
					current_enemy->Height = BODY_HEIGHT * 1.2f;
					current_enemy->HitRadius = HIT_RADIUS * 1.2f;;
					current_enemy->HitShift = HIT_SHIFT * 1.2f;;
					current_enemy->HitHeight = HIT_HEIGHT * 1.2f;;
					current_enemy->BodyTexture = &Textures[KNIGHT_BODY_TEXTURE1];
					current_enemy->HeadTexture = &Textures[KNIGHT_HEAD_TEXTURE1];
					current_enemy->HandTexture = &Textures[KNIGHT_HAND_TEXTURE1];
					current_enemy->WeaponTexture = &Textures[KNIGHT_SWORD_TEXTURE1];
					current_enemy->HelmetTexture = &Textures[KNIGHT_HELMET_TEXTURE1];
					current_enemy->ShieldTexture = &Textures[KNIGHT_SHIELD_TEXTURE1];
				}
				else
				{
					current_enemy->Radius = BODY_RADIUS * 1.4f;
					current_enemy->Height = BODY_HEIGHT * 1.4f;
					current_enemy->HitRadius = HIT_RADIUS * 1.4f;;
					current_enemy->HitShift = HIT_SHIFT * 1.4f;;
					current_enemy->HitHeight = HIT_HEIGHT * 1.4f;;
					current_enemy->BodyTexture = &Textures[KNIGHT_BODY_TEXTURE2];
					current_enemy->HeadTexture = &Textures[KNIGHT_HEAD_TEXTURE2];
					current_enemy->HandTexture = &Textures[KNIGHT_HAND_TEXTURE2];
					current_enemy->WeaponTexture = &Textures[KNIGHT_SWORD_TEXTURE2];
					current_enemy->HelmetTexture = &Textures[KNIGHT_HELMET_TEXTURE2];
					current_enemy->ShieldTexture = &Textures[KNIGHT_SHIELD_TEXTURE2];
				}
			}

			current_enemy->Used = true;

			current_enemy++;
		}
	}

	fclose(file);

	// update the heights in the map by the heights in the used fields
	for (int y = 0; y < (*Map)->Width; y++)
		for (int x = 0; x < (*Map)->Length; x++)
		{
			Field *field = &(*Map)->Fields[y * (*Map)->Length + x];
			if (field->Model)
			{
				float height = field->Height;
				for (int y2 = 0; y2 < field->Model->Width; y2++)
					for (int x2 = 0; x2 < field->Model->Length; x2++)
					{
						(*Map)->Fields[(y + y2) * (*Map)->Length + x + x2].Height
							= height + field->Model->Heights[y2 * field->Model->Length + x2];
					}
			}
		}

	Actors[PLAYER1].Position.Z = GetMapRectHeight(*Map, Actors[PLAYER1].Position.X, Actors[PLAYER1].Position.Y, Actors[PLAYER1].Radius);
	Actors[PLAYER2].Position.Z = GetMapRectHeight(*Map, Actors[PLAYER2].Position.X, Actors[PLAYER2].Position.Y, Actors[PLAYER2].Radius);

	for (ACTOR *enemy = &Actors[ENEMY0]; enemy < end_actor; enemy++)
		if (enemy->Used)
			enemy->Position.Z = GetMapRectHeight(*Map, enemy->Position.X, enemy->Position.Y, enemy->Radius);

	return true;
}

void ReleaseMap(StructMap **Map)
{
	if (*Map)
	{
		if ((*Map)->Fields)
			delete[] (*Map)->Fields;
		delete *Map;
		*Map = NULL;

		for (int i = 0; i < MAX_FIELD_MODELS; i++)
			if (FieldModels[i])
			{
				for (int j = 0; j < MAX_MODELS_IN_FIELD; j++)
				{
					if (FieldModels[i]->Models[j])
					{
						ReleaseModel(FieldModels[i]->Models[j]);
						delete FieldModels[i]->Models[j];
						ReleaseTexture(&FieldModels[i]->Textures[j]);
					}
 				}
				delete[] FieldModels[i]->Heights;
				delete FieldModels[i];
				FieldModels[i] = NULL;
			}
	}
}

float GetMapHeight(const StructMap *Map, const float X, const float Y)
{
	int x = (int)X, y = (int)Y;
	if (X < 0.0f || Y < 0.0f || x >= Map->Length || y >= Map->Width)
		return 100.0f;
	return Map->Fields[y * Map->Length + x].Height;
}

float GetMapRectHeight(const StructMap *Map, const float X, const float Y, const float Radius)
{
	float max = GetMapHeight(Map, X + Radius, Y - Radius), f;
	if (max < (f = GetMapHeight(Map, X + Radius, Y + Radius)))
		max = f;
	if (max < (f = GetMapHeight(Map, X - Radius, Y + Radius)))
		max = f;
	if (max < (f = GetMapHeight(Map, X - Radius, Y - Radius)))
		return f;
	return max;
}

void RenderMap(StructMap *Map, const int FieldClass)
{
	int length = Map->Length;
	int center_x = (int)LookAt.X;

	int y1 = (int)LookAt.Y - 15, y2 = (int)LookAt.Y + 7;
	if (y1 < 0)
		y1 = 0;
	if (y2 > Map->Width)
		y2 = Map->Width;

	int x1 = center_x - 13, x2 = (int)LookAt.X + 9;
	if (x1 < 0)
		x1 = 0;
	if (x2 > length)
		x2 = length;

	if (FieldClass && HighDetails)
	{
		glDepthMask(0);								// set depth-buffer to read-only mode
		GLfloat diffuse[4] = {0.8f, 0.8f, 0.8f, 1.0f};
		glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);		// blending function for transparency based on alfa-value
		glEnable(GL_BLEND);
	}

	glPushMatrix();		// push the current matrix stack (not to modify next objects)

	glTranslatef(x1, 0.0f, y1);

	for (int y = y1; y < y2; y++)
	{
		// render fields on the left
		for (int x = x1; x < center_x; x++)
		{
			Field *field = &Map->Fields[y * length + x];

			if (field->Model)
			{
				float altitude = field->Height - *field->Model->Heights;
				glTranslatef(0.0f, altitude, 0.0f);

				for (int i = 0; i < MAX_MODELS_IN_FIELD; i++)
					if (field->Model->Models[i] && field->Model->Class[i] == FieldClass)
						RenderModelFrame(*field->Model->Models[i], field->Model->Textures[i], 0, 0);

				glTranslatef(1.0f, -altitude, 0.0f);
			}
			else
				glTranslatef(1.0f, 0.0f, 0.0f);
		}

		// render fields on the right
		glTranslatef(x2 - center_x - 1, 0.0f, 0.0f);
		for (int x = x2 - 1; x >= center_x; x--)
		{
			Field *field = &Map->Fields[y * length + x];

			if (field->Model)
			{
				float altitude = field->Height - *field->Model->Heights;
				glTranslatef(0.0f, altitude, 0.0f);

				for (int i = 0; i < MAX_MODELS_IN_FIELD; i++)
					if (field->Model->Models[i] && field->Model->Class[i] == FieldClass)
						RenderModelFrame(*field->Model->Models[i], field->Model->Textures[i], 0, 0);

				glTranslatef(-1.0f, -altitude, 0.0f);
			}
			else
				glTranslatef(-1.0f, 0.0f, 0.0f);
		}

		glTranslatef(x1 - center_x + 1, 0.0f, 1.0f);
	}

	glPopMatrix();		// pop the current matrix stack

	if (FieldClass && HighDetails)
	{
		glDisable(GL_BLEND);
		glDepthMask(1);								// set depth-buffer to read-write mode
	}
}
