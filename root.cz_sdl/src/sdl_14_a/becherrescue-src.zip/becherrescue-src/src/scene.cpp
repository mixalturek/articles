#include "scene.h"
#include <math.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <SDL/SDL.h>
#include "global.h"
#include "map.h"
#include "settings.h"
#include "font.h"
#include "texts.h"
#include "game.h"
#ifndef WIN32
	#include <string.h>
#endif

ACTOR Actors[MAX_ACTORS];
float LightIntensity = 1.0f;

static float FPS_Duration = 0.0f;
static int FPS_Frames = 0;
static float FPS = 0.0f;

float GetSceneHeight(const ACTOR *Actor, const float X, const float Y)
{
	if (X < LookAt.X - 4.0f)	// for all
		return 100.0f;

	if ((Actor == &Actors[PLAYER1] || Actor == &Actors[PLAYER2]) && X > LookAt.X + 4.0f)
		return 100.0f;

	float max = GetMapHeight(Map, X, Y), f;

	ACTOR *end = &Actors[MAX_ACTORS];
	for (ACTOR *actor = Actors; actor < end; actor++)
		if (actor->Used && Actor != actor && (actor->Class == CLASS_HERO || actor->Health > 0))		// current actor must not be the actor specified as parameter and must be alive
		{
			if (X > actor->Position.X - actor->Radius - 0.05f && X < actor->Position.X + actor->Radius + 0.05f
					&& Y > actor->Position.Y - actor->Radius - 0.05f && Y < actor->Position.Y + actor->Radius + 0.05f
					&& actor->Position.Z - 0.0001f < Actor->Position.Z + Actor->Height)
				if (max < (f = actor->Position.Z + (actor->Action == ACTION_FALL && actor->Class != CLASS_HERO ? 0.25f * actor->Height : actor->Height)))
					max = f;
		}

	return max;
}

float GetSceneRectHeight(const ACTOR *Actor, const float X, const float Y, const float Radius)
{
	if (Actor == &Actors[PLAYER1])
	{
		if (Actors[PLAYER2].Used)
			if (fabs(Y - Actors[PLAYER2].Position.Y) > 8.0f)
				return 100.0f;
	}
	else
		if (Actor == &Actors[PLAYER2] && Actors[PLAYER1].Used)
			if (fabs(Y - Actors[PLAYER1].Position.Y) > 8.0f)
				return 100.0f;

	float max = GetSceneHeight(Actor, X + Radius, Y - Radius), f;
	if (max < (f = GetSceneHeight(Actor, X + Radius, Y + Radius)))
		max = f;
	if (max < (f = GetSceneHeight(Actor, X - Radius, Y + Radius)))
		max = f;
	if (max < (f = GetSceneHeight(Actor, X - Radius, Y - Radius)))
		return f;
	return max;
}

bool HitActorsInBox(ACTOR *Actor, const float X, const float Y, const float Z, const float Radius, const int Damage)
{
	bool hit = false;

	ACTOR *end = &Actors[MAX_ACTORS];
	for (ACTOR *actor = Actors; actor < end; actor++)
		if (actor->Used && Actor != actor && actor->Health > 0)
			if (X + Radius > actor->Position.X - actor->Radius && X - Radius < actor->Position.X + actor->Radius
					&& Y + Radius > actor->Position.Y - actor->Radius && Y - Radius < actor->Position.Y + actor->Radius
					&& Z + Radius > actor->Position.Z && Z - Radius < actor->Position.Z + actor->Height)
			{
				HitActor(actor, Actor, Damage);
				hit = true;
			}

	return hit;
}

void UpdateAllActors()
{
	ACTOR *end = &Actors[MAX_ACTORS];
	for (ACTOR *actor = Actors; actor < end; actor++)
		if (actor->Used)
			UpdateActor(actor);
}

static void RenderActorShadows()
{
	glDepthMask(0);								// set depth-buffer to read-only mode
	glDisable(GL_LIGHTING);
	glBlendFunc(GL_ZERO, GL_ONE_MINUS_SRC_COLOR);			// substractive transparency
	glEnable(GL_BLEND);
	glBindTexture(GL_TEXTURE_2D, Textures[SHADOW_TEXTURE]);

	ACTOR *end = &Actors[MAX_ACTORS];
	for (ACTOR *actor = Actors; actor < end; actor++)
		if (actor->Used && actor->Health > 0 && actor->Position.X < LookAt.X + 9.0f
			&& actor->Position.Z > 4.6f)
		{
			glPushMatrix();		// push the current matrix stack (not to modify next objects)

			glTranslatef(actor->Position.X, actor->Position.Z + 0.02f, actor->Position.Y);		// translate to the actor's position

			float shadow_altitude = GetSceneRectHeight(actor, actor->Position.X, actor->Position.Y, actor->Radius) - actor->Position.Z;
			if (shadow_altitude > 0.0f)
				shadow_altitude = 0.0f;
			float shadow_radius = 0.35f + 0.075f * shadow_altitude;
			float shadow_intensity = 0.6f + 0.25f * shadow_altitude;

			glColor3f(shadow_intensity, shadow_intensity, shadow_intensity);

			// knight and super-knight are bigger
			if (actor->Class == CLASS_KNIGHT)
				if (actor->BodyTexture == &Textures[KNIGHT_BODY_TEXTURE2])	// is it the bigger variant of the knight?
					glScalef(1.4f, 1.4f, 1.4f);
				else
					glScalef(1.2f, 1.2f, 1.2f);

			// render the shadow
			glBegin(GL_QUADS);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f(-shadow_radius, shadow_altitude, -shadow_radius);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f(-shadow_radius, shadow_altitude, shadow_radius);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f(shadow_radius, shadow_altitude, shadow_radius);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f(shadow_radius, shadow_altitude, -shadow_radius);
			glEnd();

			glPopMatrix();		// pop the current matrix stack
		}

	glDisable(GL_BLEND);
	glEnable(GL_LIGHTING);
	glDepthMask(1);								// set depth-buffer to read-write mode
}

static void RenderExplosions()
{
	glDepthMask(0);								// set depth-buffer to read-only mode
	glDisable(GL_LIGHTING);
	glBlendFunc(GL_ONE_MINUS_DST_COLOR, GL_ONE);			// additive transparency
	glEnable(GL_BLEND);

	glBindTexture(GL_TEXTURE_2D, Textures[EXPLOSION_TEXTURE]);

	ACTOR *end = &Actors[ENEMY0];
	for (ACTOR *actor = Actors; actor < end; actor++)
		if (actor->Used && actor->Action == ACTION_DRINK_EXPLOSION)
		{
			glPushMatrix();		// push the current matrix stack (not to modify next objects)

			glTranslatef(actor->Position.X, actor->Position.Z + 1.0f, actor->Position.Y);	// translate to the actor's position

			float intensity = 1.2f - actor->Duration * 1.9f;
			glColor3f(intensity, intensity, intensity);

			float scale = actor->Duration * 16.0f;
			scale *= scale / 5.0f;
			glScalef(scale, 1.0f, scale);

			// render the explosion
			glBegin(GL_QUADS);
				glTexCoord2f(0.0f, 0.0f);
				glVertex3f(-1.0f, 0.0f, -1.0f);
				glTexCoord2f(0.0f, 1.0f);
				glVertex3f(-1.0f, 0.0f, 1.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex3f(1.0f, 0.0f, 1.0f);
				glTexCoord2f(1.0f, 0.0f);
				glVertex3f(1.0f, 0.0f, -1.0f);
			glEnd();

			glPopMatrix();		// pop the current matrix stack
		}

	glDisable(GL_BLEND);
	glEnable(GL_LIGHTING);
	glDepthMask(1);								// set depth-buffer to read-write mode
}

void SetLightIntensity(const float Intensity)
{
	if (Stage > 2 && (AppState >= APP_GAME_FADE_IN && AppState <= APP_GAME_FADE_OUT))
	{	// it is dusk
		GLfloat light_ambient[4] = {Intensity * 0.5f, Intensity * 0.10f, Intensity * 0.25f, 1.0f};
		GLfloat light_diffuse[4] = {Intensity * 0.10f, Intensity * 0.15f, Intensity * 0.35f, 1.0f};
		glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
		glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
		glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient);
		glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);

		GLfloat light2_ambient[4] = {0.0f, 0.0f, 0.0f, 1.0f};
		GLfloat light2_diffuse[4] = {Intensity * 1.0f, Intensity * 1.0f, 0.0f, 1.0f};
		if (Actors[PLAYER1].Used && Actors[PLAYER2].Used)
		{
			*light2_diffuse *= 0.5f;
			light2_diffuse[1] *= 0.5f;
		}
		glLightfv(GL_LIGHT2, GL_AMBIENT, light2_ambient);
		glLightfv(GL_LIGHT2, GL_DIFFUSE, light2_diffuse);
		glLightfv(GL_LIGHT3, GL_AMBIENT, light2_ambient);
		glLightfv(GL_LIGHT3, GL_DIFFUSE, light2_diffuse);
	}
	else
	{	// it is day
		GLfloat light_ambient[4] = {Intensity * 0.5f, Intensity * 0.5f, Intensity * 0.5f, 1.0f};
		GLfloat light_diffuse[4] = {Intensity * 0.5f, Intensity * 0.5f, Intensity * 0.5f, 1.0f};
		glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
		glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
		glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient);
		glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);
	}

	LightIntensity = Intensity;
}

static void RenderGameInfo()
{
	glDisable(GL_DEPTH_TEST);
	glMatrixMode(GL_PROJECTION);							// select the projection matrix
	glPushMatrix();											// store the projection matrix
	glLoadIdentity();										// reset the projection matrix
	glOrtho(0.0, 640.0, 0.0, 480.0, -1.0, 1.0);				// set up an ortho screen
	glMatrixMode(GL_MODELVIEW);								// select the modelview matrix
	glLoadIdentity();										// reset the modelview matrix

	glDisable(GL_LIGHTING);
	if (HighDetails)
	{
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);		// blending function for transparency based on alfa-value
		glEnable(GL_BLEND);
	}
	glColor4f(LightIntensity, LightIntensity, LightIntensity, 1.0f);

	if (Actors[PLAYER2].Used)
	{	// render big bottles
		glBindTexture(GL_TEXTURE_2D, Textures[BOTTLE_BIG_TEXTURE]);
		if (Actors[PLAYER2].Health < 1 && !Actors[PLAYER2].Credits && Actors[PLAYER2].Duration > 5.0f)
			glColor4f(LightIntensity, LightIntensity, LightIntensity, 1.0f - 0.5f * (Actors[PLAYER2].Duration - 5.0f));
		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 0.652344f);
			glVertex2f(0.0f, 0.0f);
			glTexCoord2f(0.773437f, 0.652344f);
			glVertex2f(60.0f, 0.0f);
			glTexCoord2f(0.773437f, 0.0f);
			glVertex2f(60.0f, 104.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex2f(0.0f, 104.0f);
		glEnd();

		// render little bottles
		glBindTexture(GL_TEXTURE_2D, Textures[BOTTLE_LITTLE_TEXTURE]);
		glBegin(GL_QUADS);
		int last_bottle = Actors[PLAYER2].Bottles - 1;
		for (int i = 0; i < Actors[PLAYER2].Bottles; i++)
		{
			if (i == last_bottle && Actors[PLAYER2].Action == ACTION_DRINK)
				glColor4f(LightIntensity, LightIntensity, LightIntensity, 1.0f - 2.5f * Actors[PLAYER2].Duration);
			float f = 71 + i * 21;
			glTexCoord2f(0.0f, 0.0f);
			glVertex2f(f, 42.0f);
			glTexCoord2f(0.0f, 0.609375f);
			glVertex2f(f, 3.0f);
			glTexCoord2f(0.8125f, 0.609375f);
			glVertex2f(f + 13.0f, 3.0f);
			glTexCoord2f(0.8125f, 0.0f);
			glVertex2f(f + 13.0f, 42.0f);
		}
		glEnd();

		// render the life-meter
		if (Actors[PLAYER2].Health > 0)
		{
			glColor4f(LightIntensity, LightIntensity, LightIntensity, 0.3f);
			glBindTexture(GL_TEXTURE_2D, Textures[LIFE_TEXTURE]);
			glBegin(GL_QUADS);
				float y1_t = 1.0f - (float)Actors[PLAYER2].Health / (float)MAX_HEALTH_HERO;
				glTexCoord2f(0.0f, y1_t);
				float y1_v = 469.0f - y1_t * 360.0f;
				glVertex2f(9.0f, y1_v);
				glTexCoord2f(0.0f, 1.0f);
				glVertex2f(9.0f, 115.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex2f(22.0f, 115.0f);
				glTexCoord2f(1.0f, y1_t);
				glVertex2f(22.0f, y1_v);
			glEnd();
		}

		// render 'credits left'
		if (Actors[PLAYER2].Immortal)
		{
			char text[256];
			sprintf(text, "%s: %d", Texts[T_CREDITS_LEFT], Actors[PLAYER2].Credits);
			RenderText(50.0f, 50.0f, text, 0.65f * LightIntensity, 0.65f * LightIntensity, 0.6f * LightIntensity, 1.0f - Actors[PLAYER2].Immortal_Duration + 2.0f);
		}
	}
	glColor4f(LightIntensity, LightIntensity, LightIntensity, 1.0f);
	if (Actors[PLAYER1].Used)
	{	// render big bottles
		glBindTexture(GL_TEXTURE_2D, Textures[BOTTLE_BIG_TEXTURE]);
		if (Actors[PLAYER1].Health < 1 && !Actors[PLAYER1].Credits && Actors[PLAYER1].Duration > 5.0f)
			glColor4f(LightIntensity, LightIntensity, LightIntensity, 1.0f - 0.5f * (Actors[PLAYER1].Duration - 5.0f));
		glBegin(GL_QUADS);
			glTexCoord2f(0.773437f, 0.652344f);
			glVertex2f(580.0f, 0.0f);
			glTexCoord2f(0.0f, 0.652344f);
			glVertex2f(640.0f, 0.0f);
			glTexCoord2f(0.0f, 0.0f);
			glVertex2f(640.0f, 104.0f);
			glTexCoord2f(0.773437f, 0.0f);
			glVertex2f(580.0f, 104.0f);
		glEnd();

		// render little bottles
		glBindTexture(GL_TEXTURE_2D, Textures[BOTTLE_LITTLE_TEXTURE]);
		glBegin(GL_QUADS);
		int last_bottle = Actors[PLAYER1].Bottles - 1;
		for (int i = 0; i < Actors[PLAYER1].Bottles; i++)
		{
			if (i == last_bottle && Actors[PLAYER1].Action == ACTION_DRINK)
				glColor4f(LightIntensity, LightIntensity, LightIntensity, 1.0f - 2.5f * Actors[PLAYER1].Duration);
			float f = 557 - i * 21;
			glTexCoord2f(0.0f, 0.0f);
			glVertex2f(f, 42.0f);
			glTexCoord2f(0.0f, 0.609375f);
			glVertex2f(f, 3.0f);
			glTexCoord2f(0.8125f, 0.609375f);
			glVertex2f(f + 13.0f, 3.0f);
			glTexCoord2f(0.8125f, 0.0f);
			glVertex2f(f + 13.0f, 42.0f);
		}
		glEnd();

		// render the life-meter
		if (Actors[PLAYER1].Health > 0)
		{
			glColor4f(LightIntensity, LightIntensity, LightIntensity, 0.3f);
			glBindTexture(GL_TEXTURE_2D, Textures[LIFE_TEXTURE]);
			glBegin(GL_QUADS);
				float y1_t = 1.0f - (float)Actors[PLAYER1].Health / (float)MAX_HEALTH_HERO;
				glTexCoord2f(0.0f, y1_t);
				float y1_v = 469.0f - y1_t * 360.0f;
				glVertex2f(618.0f, y1_v);
				glTexCoord2f(0.0f, 1.0f);
				glVertex2f(618.0f, 115.0f);
				glTexCoord2f(1.0f, 1.0f);
				glVertex2f(631.0f, 115.0f);
				glTexCoord2f(1.0f, y1_t);
				glVertex2f(631.0f, y1_v);
			glEnd();
		}

		// render 'credits left'
		if (Actors[PLAYER1].Immortal)
		{
			char text[256];
			sprintf(text, "%s: %d", Texts[T_CREDITS_LEFT], Actors[PLAYER1].Credits);
			RenderText(590.0f - strlen(text) * CHAR_WIDTH, 50.0f, text, 0.65f * LightIntensity, 0.65f * LightIntensity, 0.6f * LightIntensity, 1.0f - Actors[PLAYER1].Immortal_Duration + 2.0f);
		}
	}

	if (AppState_Duration < 4.0f && AppState != APP_GAME_FADE_OUT)		// render stage info
	{
		char stage[128];
		sprintf(stage, "%s %d", Texts[T_STAGE], Stage);
		RenderText((640.0f - strlen(stage) * CHAR_WIDTH) / 2.0f, 230.0f, stage, 0.75f * LightIntensity, 0.0f, 0.0f, AppState_Duration < 3.2f ? 0.8f : 0.8f - (AppState_Duration - 3.2f));
	}

	// show 'Game Over'
	{
		ACTOR *last_player = NULL;
		if (Actors[PLAYER1].Used)
			if (Actors[PLAYER2].Used)
			{
				if (Actors[PLAYER1].Health < 1 && !Actors[PLAYER1].Credits
						&& Actors[PLAYER2].Health < 1 && !Actors[PLAYER2].Credits)
					last_player = Actors[PLAYER1].Duration < Actors[PLAYER2].Duration ? &Actors[PLAYER1] : &Actors[PLAYER2];
 			}
			else
			{
				if (Actors[PLAYER1].Health < 1 && !Actors[PLAYER1].Credits)
					last_player = &Actors[PLAYER1];
 			}
		else
			if (Actors[PLAYER2].Used && Actors[PLAYER2].Health < 1 && !Actors[PLAYER2].Credits)
				last_player = &Actors[PLAYER2];

		if (last_player)
		{
			if (last_player->Duration > 2.0f)
				RenderText((640.0f - strlen(Texts[T_GAME_OVER]) * CHAR_WIDTH) / 2.0f, 230.0f, Texts[T_GAME_OVER], 0.75f * LightIntensity, 0.0f, 0.0f, last_player->Duration < 2.8f ? last_player->Duration - 2.0f : 0.8f);
		}
		else
			if (AppState == APP_GAME_FADE_OUT && !Actors[PLAYER1].Used && !Actors[PLAYER2].Used)
				RenderText((640.0f - strlen(Texts[T_GAME_OVER]) * CHAR_WIDTH) / 2.0f, 230.0f, Texts[T_GAME_OVER], 0.75f * LightIntensity, 0.0f, 0.0f, 0.8f);
	}

	if (ShowQuitMessage)
	{
		QuitMessage_Duration += Delay;
		if (AppState == APP_GAME && QuitMessage_Duration > 2.0f)
			ShowQuitMessage = false;
		else
			RenderText((640.0f - strlen(Texts[T_QUIT_MESSAGE]) * CHAR_WIDTH) / 2.0f, 240.0f, Texts[T_QUIT_MESSAGE], 0.75f * LightIntensity, 0.0f, 0.0f, 0.8f);
	}

	if (Paused)
		RenderText((640.0f - strlen(Texts[T_PAUSED]) * CHAR_WIDTH) / 2.0f, 120.0f, Texts[T_PAUSED], 0.8f * LightIntensity, 0.4f * LightIntensity, 0.0f, 0.8f);

	if (ShowFPS)
		RenderFPS();

	if (HighDetails)
		glDisable(GL_BLEND);
	glEnable(GL_LIGHTING);

	glMatrixMode(GL_PROJECTION);							// select the projection matrix
	glPopMatrix();											// restore the old projection matrix
	glMatrixMode(GL_MODELVIEW);								// select the modelview matrix
	glEnable(GL_DEPTH_TEST);
}

void RenderScene()
{
//	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);		// clear the screen and depth buffer
	glClear(GL_DEPTH_BUFFER_BIT);		// clear the depth buffer only (to prevent black pixels between faces)
	glLoadIdentity();										// reset the current modelview matrix

	LookAt.Z = 5.0f;
	float new_x = -1100.0f, actor_on_left_x = 5000.0f;

	ACTOR *end_actor = &Actors[MAX_ACTORS];
	for (ACTOR *actor = Actors; actor < end_actor; actor++)
		if (actor->Used && (actor->Health > 0 || actor->Credits))
			if (actor->Position.X - actor->Radius < actor_on_left_x)
				actor_on_left_x = actor->Position.X - actor->Radius;
	actor_on_left_x -= 0.05f;

	if (Actors[PLAYER1].Used && Actors[PLAYER2].Used)
	{
		if (Actors[PLAYER1].Position.X > Actors[PLAYER2].Position.X)
			new_x = Actors[PLAYER1].Position.X;
		else
			new_x = Actors[PLAYER2].Position.X;
		LookAt.Y = (Actors[PLAYER1].Position.Y + Actors[PLAYER2].Position.Y) / 2.0f;
	}
	else
		if (Actors[PLAYER1].Used)
		{
			new_x = Actors[PLAYER1].Position.X;
			LookAt.Y = Actors[PLAYER1].Position.Y;
		}
		else
			if (Actors[PLAYER2].Used)
			{
				new_x = Actors[PLAYER2].Position.X;
				LookAt.Y = Actors[PLAYER2].Position.Y;
			}

	if ((Actors[PLAYER1].Used && Map_XLimit - Actors[PLAYER1].Position.X < 2.0f)
		|| (Actors[PLAYER2].Used && Map_XLimit - Actors[PLAYER2].Position.X < 2.0f))
	{
		bool enemy_presents = false;
		float limit = Map_XLimit + 4.0f;
		for (ACTOR *actor = &Actors[ENEMY0]; actor < end_actor; actor++)
			if (actor->Used && actor->Health > 0 && actor->Position.X < limit)
			{
				enemy_presents = true;
				break;
			}
		if (!enemy_presents)
			Map_XLimit += 8.0f;
	}

	if (new_x > -1000.0f)
	{
		new_x = floor(new_x / 4.0f) * 4.0f + 4.0f;
		if (LookAt.X < new_x)
		{
			LookAt.X += Delay * 6.0f;
			if (LookAt.X > new_x)
				LookAt.X = new_x;
			if (actor_on_left_x < LookAt.X - 4.0f)
				LookAt.X = actor_on_left_x + 4.0f;
			if (LookAt.X > Map_XLimit)
				LookAt.X = Map_XLimit;
		}
	}

	if (LookAt.X < 8)
		LookAt.X = 8;
	else
		if (LookAt.X > Map->Length - 8)
			LookAt.X = Map->Length - 8;
	if (LookAt.Y < 12)
		LookAt.Y = 12;
	else
		if (LookAt.Y > Map->Width - 6)
			LookAt.Y = Map->Width - 6;

	// place the camera
	gluLookAt(LookAt.X, LookAt.Z + 10.0f, LookAt.Y + 10.0f, LookAt.X, LookAt.Z, LookAt.Y - 0.9f, 0.0, 1.0, 0.0);

	// repair the lights (needed after glLoadIdentity() and gluLookAt())
	{
		GLfloat light0_position[4] = {-20.0f, 100.0f, -20.0f, 0.0f};	// the light is directional (w = 0)
		glLightfv(GL_LIGHT0, GL_POSITION, light0_position);
		GLfloat light1_position[4] = {0.0f, 100.0f, 100.0f, 0.0f};		// the light is directional (w = 0)
		glLightfv(GL_LIGHT1, GL_POSITION, light1_position);

		if (Stage > 2)
		{
			ACTOR *player1 = &Actors[PLAYER1];
			if (player1->Used)
			{
				float x = player1->Position.X, y = player1->Position.Y, z = 7.0f;
				GLfloat light2_position[4] = {x, z, y, 1.0f};
				GLfloat light2_spotdirection[3] = {x, z, y};
				glLightfv(GL_LIGHT2, GL_POSITION, light2_position);
				glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, light2_spotdirection);
			}
			ACTOR *player2 = &Actors[PLAYER2];
			if (player2->Used)
			{
				float x = player2->Position.X, y = player2->Position.Y, z = 7.0f;
				GLfloat light3_position[4] = {x, z, y, 1.0f};
				GLfloat light3_spotdirection[3] = {x, z, y};
				glLightfv(GL_LIGHT3, GL_POSITION, light3_position);
				glLightfv(GL_LIGHT3, GL_SPOT_DIRECTION, light3_spotdirection);
			}
		}
	}

	RenderMap(Map, FIELD_CLASS_NORMAL);			// render non-transparent objects

	// render normal actors
	GLuint *ghost_body_texture = &Textures[RAIDER1_BODY_TEXTURE3];
	for (ACTOR *actor = Actors; actor < end_actor; actor++)
		if (actor->Used && !actor->Immortal && actor->BodyTexture != ghost_body_texture && actor->Position.X < LookAt.X + 9.0f)
			RenderActor(actor);

	if (HighDetails)
		RenderMap(Map, FIELD_CLASS_TRANSPARENT);	// render transparent objects

	// render immortal actors
	for (ACTOR *actor = Actors; actor < end_actor; actor++)
		if (actor->Used && (actor->Immortal || actor->BodyTexture == ghost_body_texture))
			RenderActor(actor);

	if (HighDetails)
		RenderActorShadows();						// render actor shadows

	if (HighDetails)
		RenderMap(Map, FIELD_CLASS_GRASS);			// render grass objects

	if (HighDetails)
		RenderExplosions();							// render explosions

	RenderGameInfo();

	SDL_GL_SwapBuffers();									// swap the front- and back-buffer
}

void UpdateFPS()
{
	FPS_Frames++;
	FPS_Duration += Delay;
}

void RenderFPS()
{
	if (FPS_Duration >= 0.25f)
	{
		FPS = FPS_Frames / FPS_Duration;
		FPS_Frames = 0;
		FPS_Duration = 0.0f;
	}

	char text[32];
	sprintf(text, "%.1f fps", FPS);
	RenderText(10.0f, 450.0f, text, 0.3f, 0.6f, 0.8f, 1.0f);
}

