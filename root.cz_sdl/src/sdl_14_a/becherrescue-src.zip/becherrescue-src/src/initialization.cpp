#include "initialization.h"
#include <stdlib.h>
#include <SDL/SDL.h>
#include "consts.h"
#ifdef USE_SDL_MIXER
	#include <SDL/SDL_mixer.h>
#endif
#include <unistd.h>				// for chdir()
#include "settings.h"
#include "errors.h"
#include "global.h"
#include "texts.h"
#include "finalization.h"
#include "60hzproblem.h"
#include "models.h"
#include <GL/gl.h>
#include <GL/glu.h>
#include "timer.h"
#include "textures.h"
#include "keys.h"
#include <time.h>				// for time() for truly random numbers
#include "scene.h"
#include "font.h"
#ifndef WIN32
	#include <string.h>
#endif

#ifdef WIN32
	#include <windows.h>		// for working with the Windows registry and solving the 60 Hz problem
#endif

void Initialize(int argc, char *argv[])
{
	// change the working directory to the directory my application is placed
	char *c = &argv[0][strlen(argv[0])];
	while (*c != '/' && *c != '\\' && c != argv[0])
		c--;
	if (c != argv[0])
	{
		char bak = *c;
		*c = '\0';
		chdir(argv[0]);
		*c = bak;			// return the previous content of 'argv[0]'

	}

	// obtain the file name (with its path) where our configuration is stored
	if (ConfigFilePath)					// has it allocated a memory for some text?
		free(ConfigFilePath);
#ifdef WIN32
	{
		OSVERSIONINFO os;
		os.dwOSVersionInfoSize = sizeof(os);
		if (GetVersionEx(&os))
			if (os.dwPlatformId == VER_PLATFORM_WIN32_NT)
			{
				HKEY key;
				if (RegOpenKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders",
					0, KEY_READ, &key) == ERROR_SUCCESS)
				{
					DWORD size;
					if (RegQueryValueEx(key, "AppData", NULL, NULL, NULL, &size) == ERROR_SUCCESS) 	// we need obtain the size before obtaining
																									// the text (else it fails - a Windows bug)
					{
						ConfigFilePath = (char *)malloc(size + strlen("\\"SZ_CONFIG_FILE_NAME));
						if (RegQueryValueEx(key, "AppData", NULL, NULL, (LPBYTE)ConfigFilePath, &size) == ERROR_SUCCESS)
							strcat(ConfigFilePath, "\\"SZ_CONFIG_FILE_NAME);
						else
						{
							free(ConfigFilePath);
							ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
						}
					}
					else
						ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
					RegCloseKey(key);
				}
				else
					ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
			}
			else
				ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
		else
			ConfigFilePath = strdup(SZ_CONFIG_FILE_NAME);
	}
#else
	{
		char buf[1024];
		sprintf(buf, "%s/.Becher Rescue.cfg", getenv("HOME"));
		ConfigFilePath = strdup(buf);
	}
#endif

	// load settings from the configuration file
	LoadSettings(ConfigFilePath);

	// zero all texture IDs to identify that they are not used
	for (int i = 0; i < TEXTURES_NUM; i++)
		Textures[i] = 0;

	// register my function Finalize() as the cleanup function
	atexit(Finalize);

	// load all texts
	{
		char path[1024];
		sprintf(path, "texts/%s.lng", LanguageName);
		if (!LoadTexts(path))
			FatalError("Couldn't load texts from %s.", path);
	}

	// initialize SDL video
#ifdef USE_SDL_MIXER
	if (SDL_Init(SDL_INIT_AUDIO | SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) < 0)
		FatalError(Texts[T_COULDNT_INITIALIZE_SDL], SDL_GetError());
#else
	if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_JOYSTICK) < 0)
		FatalError(Texts[T_COULDNT_INITIALIZE_SDL], SDL_GetError());
#endif

	// set the window caption
	SDL_WM_SetCaption(SZ_WINDOW_CAPTION, NULL);

	// hide the cursor
	SDL_ShowCursor(SDL_DISABLE);

	// set the window icon
	{
		SDL_Surface *icon = SDL_LoadBMP("textures/icons/icon32.bmp");
		SDL_WM_SetIcon(icon, NULL);
		SDL_FreeSurface(icon);
	}

	// initialize a joystick
	SDL_JoystickEventState(SDL_ENABLE);
	Joystick = SDL_JoystickOpen(0);

	// if ScreenBpp is 0 (Default), detect the system color depth
#ifdef WIN32
	int bpp = ScreenBpp;
#else
	int bpp = 0;
#endif
	if (!bpp)
	{
		const SDL_VideoInfo* info = SDL_GetVideoInfo();
		bpp = info->vfmt->BitsPerPixel;
	}

	// we want *at least* 5 bits of red, green and blue and double buffering
	SDL_GL_SetAttribute(SDL_GL_RED_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_GREEN_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_BLUE_SIZE, 5);
	SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
	SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE, 0);       // we aren't going to use the stencil buffer
	SDL_GL_SetAttribute(SDL_GL_ACCUM_RED_SIZE, 0);     // this and the next three lines set the bits allocated per pixel -
	SDL_GL_SetAttribute(SDL_GL_ACCUM_GREEN_SIZE, 0);   // - for the accumulation buffer to 0
	SDL_GL_SetAttribute(SDL_GL_ACCUM_BLUE_SIZE, 0);
	SDL_GL_SetAttribute(SDL_GL_ACCUM_ALPHA_SIZE, 0);

#ifdef WIN32
	// we want at least a 16-bit depth buffer, but if it is a 24-bit depth buffer aviable, use it
	SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);
#else	// linux: setting 24 in 16bit color depth causes fatal error (nVidia GeForce 2 MX)
	SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 16);
#endif

#ifdef WIN32
	// detect whether we are running on Windows XP/2000 where the 60 Hz problem is
	{
		OSVERSIONINFO os;
		os.dwOSVersionInfoSize = sizeof(os);
		if (GetVersionEx(&os))
			if (os.dwPlatformId == VER_PLATFORM_WIN32_NT && os.dwMajorVersion > 4)
			{
				Is60HzProblem = true;

				// get the monitor frequency (for solving 60 Hz problem in Windows XP/2000)
				HDC desktop = GetDC(0);
				DesktopFrequency = GetDeviceCaps(desktop, VREFRESH);
				ReleaseDC(0, desktop);
			}
	}
#endif

	// set the video mode
	if (!(Screen = SDL_SetVideoMode(ScreenWidth, ScreenHeight, bpp, SDL_OPENGL | (Fullscreen ? SDL_FULLSCREEN : 0))))
	{
		char str[1024];
		sprintf(str, Texts[T_COULDNT_SET_VIDEO_MODE], ScreenWidth, ScreenHeight, bpp, SDL_GetError());
		FatalError(str);
	}

#ifdef WIN32
	// check the monitor frequency (60 Hz is mostly default in Windows XP/2000!)
	if (Is60HzProblem)
		Solve60HzProblem(DesktopFrequency);
#endif

/*	// debug renderer info
	FILE *f = fopen("_debug.txt", "w");
	fprintf(f, "[GL VENDOR]\n%s\n\n", glGetString(GL_VENDOR));
	fprintf(f, "[GL RENDERER]\n%s\n\n", glGetString(GL_RENDERER));
	fprintf(f, "[GL VERSION]\n%s\n\n", glGetString(GL_VERSION));
	fprintf(f, "[GL EXTENSIONS]\n%s\n", glGetString(GL_EXTENSIONS));
	fclose(f);
*/
	// setup OpenGL
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);				// background color
	glShadeModel(GL_SMOOTH);							// select smooth shading
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);	// set perspective calculations to most accurate
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);	// textures are prepared for repeating
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);	// textures are prepared for repeating
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glEnable(GL_DEPTH_TEST);							// enable depth testing
	glEnable(GL_TEXTURE_2D);							// enable texture mapping
	glEnable(GL_NORMALIZE);								// enable normal vectors scaling to unit length after transformation (needed for lighting)
	glEnable(GL_LIGHTING);								// enable lighting
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CCW);								// defines front- and back-facing polygons
	glViewport(0, 0, Screen->w, Screen->h);				// set viewport size and position
	glLightModeli(GL_LIGHT_MODEL_TWO_SIDE, GL_FALSE);
/*	glMatrixMode(GL_PROJECTION);						// select the projection matrix
	glLoadIdentity();									// reset the projection matrix
	if (Fullscreen)
		gluPerspective(30.0, 4.0 / 3.0, 6.0, 27.0);
	else
		gluPerspective(30.0, (GLdouble)Screen->w / (GLdouble)Screen->h, 6.0, 27.0);
	glMatrixMode(GL_MODELVIEW);							// select the modelview matrix	*/

/*	// make screen black
	glClear(GL_COLOR_BUFFER_BIT);						// clear the screen buffer
	SDL_GL_SwapBuffers();								// swap the front- and back-buffer
	glClear(GL_COLOR_BUFFER_BIT);						// clear the screen buffer in the second buffer
		(halts the game with ATI RagePro and doesn't have any reason)
*/
	// set gamma correction
	glPixelTransferf(GL_RED_SCALE, Gamma);
	glPixelTransferf(GL_GREEN_SCALE, Gamma);
	glPixelTransferf(GL_BLUE_SCALE, Gamma);

	// load all models
	if (!LoadModel(SZ_MODEL_HERO_BODY_PATH, &Hero_Body))
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_HERO_BODY_PATH);
	if (!LoadModel(SZ_MODEL_HERO_HEAD_PATH, &Hero_Head))
	{
		ReleaseModel(&Hero_Body);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_HERO_HEAD_PATH);
	}
	if (!LoadModel(SZ_MODEL_HERO_HAND_LEFT_PATH, &Hero_Hand_Left))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_HERO_HAND_LEFT_PATH);
	}
	if (!LoadModel(SZ_MODEL_HERO_HAND_RIGHT_PATH, &Hero_Hand_Right))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_HERO_HAND_RIGHT_PATH);
	}
	if (!LoadModel(SZ_MODEL_HERO_SWORD_PATH, &Hero_Sword))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_HERO_SWORD_PATH);
	}
	if (!LoadModel(SZ_MODEL_HERO_POTION_PATH, &Hero_Potion))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_HERO_POTION_PATH);
	}
	if (!LoadModel(SZ_MODEL_RAIDER1_BODY_PATH, &Raider1_Body))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);

		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_RAIDER1_BODY_PATH);
	}
	if (!LoadModel(SZ_MODEL_RAIDER1_HEAD_PATH, &Raider1_Head))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_RAIDER1_HEAD_PATH);
	}
	if (!LoadModel(SZ_MODEL_RAIDER1_HAND_LEFT_PATH, &Raider1_Hand_Left))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_RAIDER1_HAND_LEFT_PATH);
	}
	if (!LoadModel(SZ_MODEL_RAIDER1_HAND_RIGHT_PATH, &Raider1_Hand_Right))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_RAIDER1_HAND_RIGHT_PATH);
	}
	if (!LoadModel(SZ_MODEL_RAIDER1_CLUB_PATH, &Raider1_Club))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_RAIDER1_CLUB_PATH);
	}
	if (!LoadModel(SZ_MODEL_RAIDER2_BODY_PATH, &Raider2_Body))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_RAIDER2_BODY_PATH);
	}
	if (!LoadModel(SZ_MODEL_RAIDER2_HEAD_PATH, &Raider2_Head))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_RAIDER2_HEAD_PATH);
	}
	if (!LoadModel(SZ_MODEL_RAIDER2_HAND_LEFT_PATH, &Raider2_Hand_Left))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		ReleaseModel(&Raider2_Head);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_RAIDER2_HAND_LEFT_PATH);
	}
	if (!LoadModel(SZ_MODEL_RAIDER2_HAND_RIGHT_PATH, &Raider2_Hand_Right))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		ReleaseModel(&Raider2_Head);
		ReleaseModel(&Raider2_Hand_Left);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_RAIDER2_HAND_RIGHT_PATH);
	}
	if (!LoadModel(SZ_MODEL_RAIDER2_AXE_PATH, &Raider2_Axe))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		ReleaseModel(&Raider2_Head);
		ReleaseModel(&Raider2_Hand_Left);
		ReleaseModel(&Raider2_Hand_Right);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_RAIDER2_AXE_PATH);
	}
	if (!LoadModel(SZ_MODEL_RAIDER2_HELMET_PATH, &Raider2_Helmet))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		ReleaseModel(&Raider2_Head);
		ReleaseModel(&Raider2_Hand_Left);
		ReleaseModel(&Raider2_Hand_Right);
		ReleaseModel(&Raider2_Axe);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_RAIDER2_HELMET_PATH);
	}
	if (!LoadModel(SZ_MODEL_KNIGHT_BODY_PATH, &Knight_Body))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		ReleaseModel(&Raider2_Head);
		ReleaseModel(&Raider2_Hand_Left);
		ReleaseModel(&Raider2_Hand_Right);
		ReleaseModel(&Raider2_Axe);
		ReleaseModel(&Raider2_Helmet);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_KNIGHT_BODY_PATH);
	}
	if (!LoadModel(SZ_MODEL_KNIGHT_HEAD_PATH, &Knight_Head))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		ReleaseModel(&Raider2_Head);
		ReleaseModel(&Raider2_Hand_Left);
		ReleaseModel(&Raider2_Hand_Right);
		ReleaseModel(&Raider2_Axe);
		ReleaseModel(&Raider2_Helmet);
		ReleaseModel(&Knight_Body);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_KNIGHT_HEAD_PATH);
	}
	if (!LoadModel(SZ_MODEL_KNIGHT_HAND_LEFT_PATH, &Knight_Hand_Left))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		ReleaseModel(&Raider2_Head);
		ReleaseModel(&Raider2_Hand_Left);
		ReleaseModel(&Raider2_Hand_Right);
		ReleaseModel(&Raider2_Axe);
		ReleaseModel(&Raider2_Helmet);
		ReleaseModel(&Knight_Body);
		ReleaseModel(&Knight_Head);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_KNIGHT_HAND_LEFT_PATH);
	}
	if (!LoadModel(SZ_MODEL_KNIGHT_HAND_RIGHT_PATH, &Knight_Hand_Right))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		ReleaseModel(&Raider2_Head);
		ReleaseModel(&Raider2_Hand_Left);
		ReleaseModel(&Raider2_Hand_Right);
		ReleaseModel(&Raider2_Axe);
		ReleaseModel(&Raider2_Helmet);
		ReleaseModel(&Knight_Body);

		ReleaseModel(&Knight_Head);
		ReleaseModel(&Knight_Hand_Left);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_KNIGHT_HAND_RIGHT_PATH);
	}
	if (!LoadModel(SZ_MODEL_KNIGHT_SWORD_PATH, &Knight_Sword))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		ReleaseModel(&Raider2_Head);
		ReleaseModel(&Raider2_Hand_Left);
		ReleaseModel(&Raider2_Hand_Right);
		ReleaseModel(&Raider2_Axe);
		ReleaseModel(&Raider2_Helmet);
		ReleaseModel(&Knight_Body);
		ReleaseModel(&Knight_Head);
		ReleaseModel(&Knight_Hand_Left);
		ReleaseModel(&Knight_Hand_Right);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_KNIGHT_SWORD_PATH);
	}
	if (!LoadModel(SZ_MODEL_KNIGHT_HELMET_PATH, &Knight_Helmet))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		ReleaseModel(&Raider2_Head);
		ReleaseModel(&Raider2_Hand_Left);
		ReleaseModel(&Raider2_Hand_Right);
		ReleaseModel(&Raider2_Axe);
		ReleaseModel(&Raider2_Helmet);
		ReleaseModel(&Knight_Body);
		ReleaseModel(&Knight_Head);
		ReleaseModel(&Knight_Hand_Left);
		ReleaseModel(&Knight_Hand_Right);
		ReleaseModel(&Knight_Sword);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_KNIGHT_HELMET_PATH);
	}
	if (!LoadModel(SZ_MODEL_KNIGHT_SHIELD_PATH, &Knight_Shield))
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		ReleaseModel(&Raider2_Head);
		ReleaseModel(&Raider2_Hand_Left);
		ReleaseModel(&Raider2_Hand_Right);
		ReleaseModel(&Raider2_Axe);
		ReleaseModel(&Raider2_Helmet);
		ReleaseModel(&Knight_Body);
		ReleaseModel(&Knight_Head);
		ReleaseModel(&Knight_Hand_Left);
		ReleaseModel(&Knight_Hand_Right);
		ReleaseModel(&Knight_Sword);
		ReleaseModel(&Knight_Helmet);
		FatalError(Texts[T_COULDNT_LOAD_MODEL], SZ_MODEL_KNIGHT_SHIELD_PATH);
	}
	AreModelsLoaded = true;

	// correct frame durations in the animations :)
	{
		float hero_anim_speeds[MAX_ACTIONS]
			= {0.25f, 0.0f, 0.041667f, 0.07f, 0.0f, 0.0f, 0.040625f, 0.040625f, 0.040625f, 0.0f, 0.040625f, 0.040625f, 0.0f};
		for (int i = 0; i < MAX_ACTIONS; i++)
			if (hero_anim_speeds[i])
			{
				float speed = hero_anim_speeds[i];
				Hero_Body.Animations[i].FrameDuration = speed;
				Hero_Head.Animations[i].FrameDuration = speed;
				Hero_Hand_Left.Animations[i].FrameDuration = speed;
				Hero_Hand_Right.Animations[i].FrameDuration = speed;
				Hero_Sword.Animations[i].FrameDuration = speed;
			}
		float raider1_anim_speeds[MAX_ACTIONS - 3]
			= {0.25f, 0.0625f / 0.8f, 0.041667f / 0.7f, 0.07f, 0.0f, 0.0f, 0.040625f, 0.040625f, 0.040625f, 0.0f};
		for (int i = 0; i < MAX_ACTIONS - 3; i++)
			if (raider1_anim_speeds[i])
			{
				float speed = raider1_anim_speeds[i];
				Raider1_Body.Animations[i].FrameDuration = speed;
				Raider1_Head.Animations[i].FrameDuration = speed;
				Raider1_Hand_Left.Animations[i].FrameDuration = speed;
				Raider1_Hand_Right.Animations[i].FrameDuration = speed;
				Raider1_Club.Animations[i].FrameDuration = speed;
			}
		float raider2_anim_speeds[MAX_ACTIONS - 3]
			= {0.25f, 0.0625f / 0.9f, 0.041667f / 0.8f, 0.07f, 0.0f, 0.0f, 0.040625f, 0.040625f, 0.040625f, 0.0f};
		for (int i = 0; i < MAX_ACTIONS - 3; i++)
			if (raider2_anim_speeds[i])
			{
				float speed = raider2_anim_speeds[i];
				Raider2_Body.Animations[i].FrameDuration = speed;
				Raider2_Head.Animations[i].FrameDuration = speed;
				Raider2_Hand_Left.Animations[i].FrameDuration = speed;
				Raider2_Hand_Right.Animations[i].FrameDuration = speed;
				Raider2_Axe.Animations[i].FrameDuration = speed;
				Raider2_Helmet.Animations[i].FrameDuration = speed;
			}
		float knight_anim_speeds[MAX_ACTIONS - 4]
			= {0.5f, 0.0625f / 0.7f, 0.041667f / 0.7f, 0.07f, 0.0f, 0.0f, 0.8f * 0.040625f, 0.040625f, 0.040625f};
		for (int i = 0; i < MAX_ACTIONS - 4; i++)
			if (knight_anim_speeds[i])
			{
				float speed = knight_anim_speeds[i];
				Knight_Body.Animations[i].FrameDuration = speed;
				Knight_Head.Animations[i].FrameDuration = speed;
				Knight_Hand_Left.Animations[i].FrameDuration = speed;
				Knight_Hand_Right.Animations[i].FrameDuration = speed;
				Knight_Sword.Animations[i].FrameDuration = speed;
				Knight_Helmet.Animations[i].FrameDuration = speed;
				Knight_Shield.Animations[i].FrameDuration = speed;
			}
	}

	// load all textures
	if (!LoadTexture(SZ_HERO_BODY_TEXTURE1_PATH, &Textures[HERO_BODY_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_HERO_BODY_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_HERO_BODY_TEXTURE2_PATH, &Textures[HERO_BODY_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_HERO_BODY_TEXTURE2_PATH, SDL_GetError());
	if (!LoadTexture(SZ_HERO_HEAD_TEXTURE1_PATH, &Textures[HERO_HEAD_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_HERO_HEAD_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_HERO_HEAD_TEXTURE2_PATH, &Textures[HERO_HEAD_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_HERO_HEAD_TEXTURE2_PATH, SDL_GetError());
	if (!LoadTexture(SZ_HERO_HAND_TEXTURE1_PATH, &Textures[HERO_HAND_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_HERO_HAND_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_HERO_HAND_TEXTURE2_PATH, &Textures[HERO_HAND_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_HERO_HAND_TEXTURE2_PATH, SDL_GetError());
	if (!LoadTexture(SZ_HERO_SWORD_TEXTURE_PATH, &Textures[HERO_SWORD_TEXTURE]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_HERO_SWORD_TEXTURE_PATH, SDL_GetError());
	if (!LoadTexture(SZ_HERO_POTION_TEXTURE_PATH, &Textures[HERO_POTION_TEXTURE]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_HERO_POTION_TEXTURE_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER1_BODY_TEXTURE1_PATH, &Textures[RAIDER1_BODY_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER1_BODY_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER1_BODY_TEXTURE2_PATH, &Textures[RAIDER1_BODY_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER1_BODY_TEXTURE2_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER1_BODY_TEXTURE3_PATH, &Textures[RAIDER1_BODY_TEXTURE3]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER1_BODY_TEXTURE3_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER1_HEAD_TEXTURE1_PATH, &Textures[RAIDER1_HEAD_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER1_HEAD_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER1_HEAD_TEXTURE2_PATH, &Textures[RAIDER1_HEAD_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER1_HEAD_TEXTURE2_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER1_HEAD_TEXTURE3_PATH, &Textures[RAIDER1_HEAD_TEXTURE3]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER1_HEAD_TEXTURE3_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER1_HAND_TEXTURE1_PATH, &Textures[RAIDER1_HAND_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER1_HAND_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER1_HAND_TEXTURE2_PATH, &Textures[RAIDER1_HAND_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER1_HAND_TEXTURE2_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER1_HAND_TEXTURE3_PATH, &Textures[RAIDER1_HAND_TEXTURE3]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER1_HAND_TEXTURE3_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER1_CLUB_TEXTURE1_PATH, &Textures[RAIDER1_CLUB_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER1_CLUB_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER1_CLUB_TEXTURE2_PATH, &Textures[RAIDER1_CLUB_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER1_CLUB_TEXTURE2_PATH, SDL_GetError());

	if (!LoadTexture(SZ_RAIDER1_CLUB_TEXTURE3_PATH, &Textures[RAIDER1_CLUB_TEXTURE3]))

		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER1_CLUB_TEXTURE3_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER2_BODY_TEXTURE1_PATH, &Textures[RAIDER2_BODY_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER2_BODY_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER2_HEAD_TEXTURE1_PATH, &Textures[RAIDER2_HEAD_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER2_HEAD_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER2_HAND_TEXTURE1_PATH, &Textures[RAIDER2_HAND_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER2_HAND_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER2_AXE_TEXTURE1_PATH, &Textures[RAIDER2_AXE_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER2_AXE_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER2_AXE_TEXTURE3_PATH, &Textures[RAIDER2_AXE_TEXTURE3]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER2_AXE_TEXTURE3_PATH, SDL_GetError());
	if (!LoadTexture(SZ_RAIDER2_HELMET_TEXTURE1_PATH, &Textures[RAIDER2_HELMET_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_RAIDER2_HELMET_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_KNIGHT_BODY_TEXTURE1_PATH, &Textures[KNIGHT_BODY_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_KNIGHT_BODY_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_KNIGHT_BODY_TEXTURE2_PATH, &Textures[KNIGHT_BODY_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_KNIGHT_BODY_TEXTURE2_PATH, SDL_GetError());
	if (!LoadTexture(SZ_KNIGHT_HEAD_TEXTURE1_PATH, &Textures[KNIGHT_HEAD_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_KNIGHT_HEAD_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_KNIGHT_HEAD_TEXTURE2_PATH, &Textures[KNIGHT_HEAD_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_KNIGHT_HEAD_TEXTURE2_PATH, SDL_GetError());
	if (!LoadTexture(SZ_KNIGHT_HAND_TEXTURE1_PATH, &Textures[KNIGHT_HAND_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_KNIGHT_HAND_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_KNIGHT_HAND_TEXTURE2_PATH, &Textures[KNIGHT_HAND_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_KNIGHT_HAND_TEXTURE2_PATH, SDL_GetError());
	if (!LoadTexture(SZ_KNIGHT_SWORD_TEXTURE1_PATH, &Textures[KNIGHT_SWORD_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_KNIGHT_SWORD_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_KNIGHT_SWORD_TEXTURE2_PATH, &Textures[KNIGHT_SWORD_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_KNIGHT_SWORD_TEXTURE2_PATH, SDL_GetError());
	if (!LoadTexture(SZ_KNIGHT_HELMET_TEXTURE1_PATH, &Textures[KNIGHT_HELMET_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_KNIGHT_HELMET_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_KNIGHT_HELMET_TEXTURE2_PATH, &Textures[KNIGHT_HELMET_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_KNIGHT_HELMET_TEXTURE2_PATH, SDL_GetError());
	if (!LoadTexture(SZ_KNIGHT_SHIELD_TEXTURE1_PATH, &Textures[KNIGHT_SHIELD_TEXTURE1]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_KNIGHT_SHIELD_TEXTURE1_PATH, SDL_GetError());
	if (!LoadTexture(SZ_KNIGHT_SHIELD_TEXTURE2_PATH, &Textures[KNIGHT_SHIELD_TEXTURE2]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_KNIGHT_SHIELD_TEXTURE2_PATH, SDL_GetError());
	if (!LoadTexture(SZ_SHADOW_TEXTURE_PATH, &Textures[SHADOW_TEXTURE]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_SHADOW_TEXTURE_PATH, SDL_GetError());
	if (!LoadTexture(SZ_EXPLOSION_TEXTURE_PATH, &Textures[EXPLOSION_TEXTURE]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_EXPLOSION_TEXTURE_PATH, SDL_GetError());
	if (!LoadTexture(SZ_BOTTLE_BIG_TEXTURE_PATH, &Textures[BOTTLE_BIG_TEXTURE], true))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_BOTTLE_BIG_TEXTURE_PATH, SDL_GetError());
	if (!LoadTexture(SZ_BOTTLE_LITTLE_TEXTURE_PATH, &Textures[BOTTLE_LITTLE_TEXTURE], true))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_BOTTLE_LITTLE_TEXTURE_PATH, SDL_GetError());
	if (!LoadTexture(SZ_LIFE_TEXTURE_PATH, &Textures[LIFE_TEXTURE]))
		FatalError(Texts[T_COULDNT_LOAD_TEXTURE], SZ_LIFE_TEXTURE_PATH, SDL_GetError());
	{
		char buf[1024];
		sprintf(buf, "texts/%s_font.bmp", LanguageName);
		if (!LoadTexture(buf, &Textures[FONT_TEXTURE], true))
			FatalError(Texts[T_COULDNT_LOAD_TEXTURE], buf, SDL_GetError());
	}

#ifdef USE_SDL_MIXER
	// init sound subsystem
	if (Mix_OpenAudio(Sound44kHz ? 44100 : 22050, MIX_DEFAULT_FORMAT, 2, Sound44kHz ? 2048 : 1024) == -1)
		FatalError(Texts[T_COULDNT_INITIALIZE_SOUND_SUBSYSTEM], Mix_GetError());

	// allocate 16 mixing channels
	Mix_AllocateChannels(16);

	// load all sounds
	for (int i = 0; i < SOUNDS_NUM; i++)
	{
		char path[1024];

		if (!i)
			strcpy(path, "sounds/fall.wav");
		else if (i == 1)
			strcpy(path, "sounds/foot_splash.wav");
		else if (i == 2)
			strcpy(path, "sounds/hero_attack1.wav");
		else if (i == 3)
			strcpy(path, "sounds/hero_attack2.wav");
		else if (i == 4)
			strcpy(path, "sounds/hit1.wav");
		else if (i == 5)
			strcpy(path, "sounds/hit2.wav");
		else if (i == 6)
			strcpy(path, "sounds/hit3.wav");
		else if (i == 7)
			strcpy(path, "sounds/hit4.wav");
		else if (i == 8)
			strcpy(path, "sounds/jump.wav");
		else if (i == 9)
			strcpy(path, "sounds/knight_attack.wav");
		else
			strcpy(path, "sounds/magic.wav");

		if (!(Sounds[i] = Mix_LoadWAV(path)))
			FatalError(Texts[T_COULDNT_LOAD_SOUND], path, Mix_GetError());

		Mix_VolumeChunk(Sounds[i], MIX_MAX_VOLUME);
	}
#endif

	InitFont();

	// to produce truly random numbers (not just pseudo-random)
	srand(time(NULL));

	// set all actor structures to 'not used' state
	ACTOR *end = &Actors[MAX_ACTORS];
	for (ACTOR *actor = Actors; actor < end; actor++)
		actor->Used = false;

	// material settings
	{
		GLfloat mat_diffuse[4] = {0.8f, 0.8f, 0.8f, 1.0f};		// default values
		GLfloat mat_ambient[4] = {0.2f, 0.2f, 0.2f, 1.0f};
		glMateriali(GL_FRONT, GL_SHININESS, 128);
		glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
		glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);

	}

	// setup players
	for (ACTOR *actor = Actors; actor < &Actors[ENEMY0]; actor++)
	{
		actor->Class = CLASS_HERO;
		actor->Radius = BODY_RADIUS;
		actor->Height = BODY_HEIGHT;
		actor->Damage = DAMAGE_HERO;
		actor->WalkSpeed = HERO_WALK_SPEED;
		actor->RunSpeed = HERO_RUN_SPEED;
		actor->FallSpeed = HERO_FALL_SPEED;
		actor->LyingTime = HERO_LYING_TIME;
		actor->FlyingTime = HERO_FLYING_TIME;
		actor->BlockingTime = HERO_BLOCKING_TIME;
		actor->HitRadius = HIT_RADIUS;
		actor->HitShift = HIT_SHIFT;
		actor->HitHeight = HIT_HEIGHT;
		actor->BodyModel = &Hero_Body;
		actor->HeadModel = &Hero_Head;
		actor->HandLeftModel = &Hero_Hand_Left;
		actor->HandRightModel = &Hero_Hand_Right;
		actor->WeaponModel = &Hero_Sword;
		actor->HelmetModel = NULL;
		actor->ShieldModel = NULL;
		actor->PotionModel = &Hero_Potion;
		if (actor == &Actors[PLAYER1])
		{
			actor->BodyTexture = &Textures[HERO_BODY_TEXTURE1];
			actor->HeadTexture = &Textures[HERO_HEAD_TEXTURE1];
			actor->HandTexture = &Textures[HERO_HAND_TEXTURE1];
		}
		else
		{
			actor->BodyTexture = &Textures[HERO_BODY_TEXTURE2];
			actor->HeadTexture = &Textures[HERO_HEAD_TEXTURE2];
			actor->HandTexture = &Textures[HERO_HAND_TEXTURE2];
		}
		actor->WeaponTexture = &Textures[HERO_SWORD_TEXTURE];
		actor->HelmetTexture = NULL;
		actor->ShieldTexture = NULL;
		actor->PotionTexture = &Textures[HERO_POTION_TEXTURE];
		actor->Target = NULL;
	}

	// set all keys to unpressed state & inicialize press times
	for (int i = 0; i < KEYS_NUM; i++)
	{
		Keys[i] = 0;
		KeysPressTime[i] = (Uint32)-20;
		KeysPressTimePrev[i] = (Uint32)-20;
	}

	// initialize the timer (this must be the last operation here!)
	InitTimer();
	ResetTimer();

#ifdef WIN32
	// disable sreen saver
	SystemParametersInfo(SPI_GETSCREENSAVEACTIVE, 0, &ScreenSaverEnabled, 0);
	SystemParametersInfo(SPI_SETSCREENSAVEACTIVE, 0, NULL, 0);
#endif
}
