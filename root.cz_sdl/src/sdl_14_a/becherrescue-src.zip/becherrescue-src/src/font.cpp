#include "font.h"
#include <GL/gl.h>
#include "global.h"

static GLuint FontBase;

void InitFont()
{
	FontBase = glGenLists(256);							// creating display lists

	float char_width = CHAR_WIDTH + 5.0f;
	float cw = (1.0f / 512.0f) * char_width;			// CharWidth in texture units
	float ch = (1.0f / 512.0f) * CHAR_HEIGHT;			// CharHeight in texture units
	float cw2 = (1.0f / 512.0f) * (char_width + 1.0f);	// CharWidth + 1 in texture units
	float ch2 = (1.0f / 512.0f) * (CHAR_HEIGHT + 1.0f);	// CharHeight + 1 in texture units

	for (int loop = 0; loop < 256; loop++)				// loop through all lists
	{
		float x = float(loop % 16) * cw2;				// X position of current character
		float y = float(loop / 16) * ch2;				// Y position of current character

		glNewList(FontBase + loop, GL_COMPILE);			// start building a list
			glBegin(GL_QUADS);							// use a quad for each character
				glTexCoord2f(x, y + ch);				// texture coord (bottom left)
				glVertex2f(0.0f, 0.0f);					// vertex coord (bottom left)
				glTexCoord2f(x + cw, y + ch);			// texture coord (bottom right)
				glVertex2f(char_width, 0.0f);			// vertex coord (bottom right)
				glTexCoord2f(x + cw, y);				// texture coord (top right)
				glVertex2f(char_width, CHAR_HEIGHT);	// vertex coord (top right)
				glTexCoord2f(x, y);						// texture coord (top left)
				glVertex2f(0.0f, CHAR_HEIGHT);			// vertex coord (top left)
			glEnd();									// done building our quad (character)
			glTranslatef(CHAR_WIDTH, 0.0f, 0.0f);		// move to the right of the character
		glEndList();									// done building the display list
	}													// loop until all are built
}

void ReleaseFont()
{
	glDeleteLists(FontBase, 256);						// delete allocated display lists
}

void RenderText(const float X, const float Y, const char *Text, const float R, const float G, const float B, const float A)
{
	glPushMatrix();											// store the modelview matrix

	glBindTexture(GL_TEXTURE_2D, Textures[FONT_TEXTURE]);	// select our font texture
	glColor4f(R, G, B, A);									// set the color and transparency

	glTranslatef(X, Y, 0.0f);								// position the text
	int line_length = 0;

	for (unsigned char *c = (unsigned char *)Text; *c; c++)
		if (*c == '\n')
		{
			glTranslatef(-line_length * CHAR_WIDTH, -CHAR_HEIGHT, 0.0f);	// move to the beginning of the next line
			line_length = 0;
		}
		else
		{
			glCallList(FontBase + *c);						// write the character to the screen
			line_length++;
		}

	glPopMatrix();											// restore the old projection matrix
}

