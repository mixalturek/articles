#ifndef GAME_H
#define GAME_H

#include <SDL/SDL.h>

// application states
enum
{
	APP_STARTING = 0,
	APP_MENU_FADE_IN,
	APP_MENU,
	APP_MENU_FADE_OUT,
	APP_GAME_FADE_IN,
	APP_GAME,
	APP_GAME_FADE_OUT,
	APP_MENU_EXIT
};

extern int AppState;				// the state of the application
extern float AppState_Duration;		// the duration of the app state
extern int Stage;					// current stage

// call this if a key is pressed
void Game_KeyPress(const SDLKey Key);

// call this every frame
void UpdateGame();

#endif

