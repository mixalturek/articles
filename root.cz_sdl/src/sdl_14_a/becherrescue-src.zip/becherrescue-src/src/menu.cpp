#include "menu.h"
#include "landscape.h"
#include <SDL/SDL.h>
#include <GL/gl.h>
#include "global.h"
#include "texts.h"
#include "scene.h"
#include "font.h"
#include "settings.h"
#include <time.h>
#ifndef WIN32
	#include <string.h>
#endif

int MenuState = MENU_MENUSTATE;

struct SCORE
{
	int Score;
	char DateTime[20];
};

static int PrevState = MenuState;
static float Duration;
static float Transition_Dur = 1.0f;
static SCORE ScoreTab1P[8];
static SCORE ScoreTab2P[8];
static int HiScore_Pos = -1;
static bool HiScore_Player = 1;

void LoadMenuData()
{
	Duration = 0.0f;
	LoadLandscapeData();

	// load high scores
	HiScore_Pos = -1;

	char buf[1024];
	strcpy(buf, ConfigFilePath);
	buf[strlen(buf) - 3] = '\0';
	strcat(buf, "his");

	for (int i = 0; i < 8; i++)
	{
		ScoreTab1P[i].Score = (8 - i) * 200;
		strcpy(ScoreTab1P[i].DateTime, "2003-11-14 22:00:00");
		ScoreTab2P[i].Score = (8 - i) * 200;
		strcpy(ScoreTab2P[i].DateTime, "2003-11-14 22:00:00");
	}

	FILE *score_file;
	if ((score_file = fopen(buf, "rb")))
	{
		for (int i = 0; i < 8; i++)
		{
			fread(&ScoreTab1P[i].Score, sizeof(ScoreTab1P->Score), 1, score_file);
			fread(&ScoreTab2P[i].Score, sizeof(ScoreTab2P->Score), 1, score_file);
			fread(ScoreTab1P[i].DateTime, 1, 19, score_file);
			ScoreTab1P[i].DateTime[19] = '\0';
			if (fread(ScoreTab2P[i].DateTime, 1, 19, score_file) < 19)
			{
				ScoreTab1P[i].Score = (i + 1) * 100;
				strcpy(ScoreTab1P[i].DateTime, "2003-11-14 22:00:00");
				ScoreTab2P[i].Score = (i + 1) * 100;
				strcpy(ScoreTab2P[i].DateTime, "2003-11-14 22:00:00");
				break;
			}
			ScoreTab2P[i].DateTime[19] = '\0';
		}
		fclose(score_file);
	}

	if (TotalPlay > 0.0f)
	{
		int score = NumPlayers == 1 ? Actors[PLAYER1].TotalDamage + Actors[PLAYER1].Health + Actors[PLAYER1].Bottles * 50 + Actors[PLAYER1].Credits * 100:
			Actors[PLAYER1].TotalDamage + Actors[PLAYER2].TotalDamage + Actors[PLAYER1].Health + Actors[PLAYER1].Bottles * 50 + Actors[PLAYER1].Credits * 100 + Actors[PLAYER2].Health + Actors[PLAYER2].Bottles * 50 + Actors[PLAYER2].Credits * 100;

		if (NumPlayers == 1)
		{
			HiScore_Player = 1;

			for (int i = 0; i < 8; i++)
				if (score > ScoreTab1P[i].Score)
				{
					HiScore_Pos = i;

					for (int j = 7; j > i; j--)
					{
						ScoreTab1P[j].Score = ScoreTab1P[j - 1].Score;
						strcpy(ScoreTab1P[j].DateTime, ScoreTab1P[j - 1].DateTime);
					}

					ScoreTab1P[i].Score = score;

					time_t curtime;
					tm *loctime;
					curtime = time(NULL);				// get the current time
					loctime = localtime(&curtime);		// convert it to local time representation
					strftime(buf, 1024, "%Y-%m-%d %H:%M:%S", loctime);	// print out the date and time
					strcpy(ScoreTab1P[i].DateTime, buf);

					break;
				}
		}
		else
		{
			HiScore_Player = 2;

			for (int i = 0; i < 8; i++)
				if (score > ScoreTab2P[i].Score)
				{
					HiScore_Pos = i;

					for (int j = 7; j > i; j--)
					{
						ScoreTab2P[j].Score = ScoreTab2P[j - 1].Score;
						strcpy(ScoreTab2P[j].DateTime, ScoreTab2P[j - 1].DateTime);
					}

					ScoreTab2P[i].Score = score;

					time_t curtime;
					tm *loctime;
					curtime = time(NULL);				// get the current time
					loctime = localtime(&curtime);		// convert it to local time representation
					strftime(buf, 1024, "%Y-%m-%d %H:%M:%S", loctime);	// print out the date and time
					strcpy(ScoreTab2P[i].DateTime, buf);

					break;
				}
		}
	}
}

void ReleaseMenu()
{
	if (TotalPlay > 0.0f)
	{
		char buf[1024];
		strcpy(buf, ConfigFilePath);
		buf[strlen(buf) - 3] = '\0';
		strcat(buf, "his");

		FILE *score_file;
		if ((score_file = fopen(buf, "wb")))
		{
			for (int i = 0; i < 8; i++)
			{
				fwrite(&ScoreTab1P[i].Score, sizeof(ScoreTab1P->Score), 1, score_file);
				fwrite(&ScoreTab2P[i].Score, sizeof(ScoreTab2P->Score), 1, score_file);
				fwrite(ScoreTab1P[i].DateTime, 1, 19, score_file);
				fwrite(ScoreTab2P[i].DateTime, 1, 19, score_file);
			}
			fclose(score_file);
		}
	}

	ReleaseLandscape();
}

static void RenderMenuState(const int State, const float Visibility)
{
	float r = 1.0f * LightIntensity, g = r, b = 0.8f * LightIntensity;

	if (State == MENU_MENUSTATE)
	{
		float a = Duration < 4.0f ? 0.5f + 0.125f * Duration : 1.0f - 0.125f * (Duration - 4.0f);
		a *= Visibility;

		// render menu options
		RenderText(290.0f, 350.0f, Texts[T_F1_START_GAME], r, g, b, a);
		RenderText(290.0f, 327.0f, NumPlayers == 1 ? Texts[T_F2_ONE_PLAYER] : Texts[T_F2_TWO_PLAYERS], r, g, b, a);
		RenderText(290.0f, 304.0f, Difficulty ? (Difficulty == 1 ? Texts[T_F3_DIFFICULTY_NORMAL] : Texts[T_F3_DIFFICULTY_HARD]) : Texts[T_F3_DIFFICULTY_EASY], r, g, b, a);
		RenderText(290.0f, 281.0f, AssignJoystick ? (AssignJoystick == AJ_PLAYER1 ? Texts[T_F4_JOYSTICK_ASSIGNED_TO_P1] : Texts[T_F4_JOYSTICK_ASSIGNED_TO_P2]) : Texts[T_F4_JOYSTICK_NOT_ASSIGNED], r, g, b, a);
		RenderText(290.0f, 258.0f, Texts[T_F5_VIEW_SCORES], r, g, b, a);
		RenderText(290.0f, 235.0f, Texts[T_F6_HELP], r, g, b, a);
		RenderText(290.0f, 212.0f, Texts[T_F7_CREDITS], r, g, b, a);
		RenderText(278.0f, 189.0f, Texts[T_ESC_EXIT], r, g, b, a);
	}
	else if (State == PROLOGUE_MENUSTATE)
		RenderText(10.0f, 330.0f, Texts[T_PROLOGUE], r, g, b, 0.8f * Visibility);
	else if (State == EPILOGUE_MENUSTATE)
		RenderText(10.0f, 330.0f, Texts[T_EPILOGUE], r, g, b, 0.8f * Visibility);
	else if (State == SCORETAB_MENUSTATE)
	{
		char buf[1024];
		sprintf(buf, "%s - %s", Texts[T_SCORETAB_TITLE], NumPlayers == 1 ? Texts[T_F2_ONE_PLAYER] + 4 : Texts[T_F2_TWO_PLAYERS] + 4);
		RenderText(10.0f, 395.0f, buf, r, g, b, 0.8f * Visibility);

		for (int i = 0; i < 8; i++)
		{
			if (NumPlayers == 1)
				sprintf(buf, "%d. %5d %s", i + 1, ScoreTab1P[i].Score, ScoreTab1P[i].DateTime);
			else
				sprintf(buf, "%d. %5d %s", i + 1, ScoreTab2P[i].Score, ScoreTab2P[i].DateTime);
			if (i == HiScore_Pos && NumPlayers == HiScore_Player)
				RenderText(10.0f, 349.0f - CHAR_HEIGHT * i, buf, 1.0f * LightIntensity, 1.0f * LightIntensity, 1.0f * LightIntensity, 1.0f * Visibility);
			else
				RenderText(10.0f, 349.0f - CHAR_HEIGHT * i, buf, r, g, b, 0.8f * Visibility);
		}
	}
	else if (State == HELP_MENUSTATE)
		RenderText(10.0f, 395.0f, Texts[T_HELP], r, g, b, 0.8f * Visibility);
	else if (State == CREDITS_MENUSTATE)
		RenderText(10.0f, 395.0f, Texts[T_CREDITS], r, g, b, 0.8f * Visibility);
}

void RenderMenu()
{
	Duration += Delay;
	while (Duration >= 8.0f)
		Duration -= 8.0f;

	if (Transition_Dur < 1.0f)
		Transition_Dur += Delay;

	RenderLandscape();

	if (Transition_Dur < 0.5f)
		RenderMenuState(PrevState, 1.0f - 2.0f * Transition_Dur);
	else
		if (Transition_Dur < 1.0f)
			RenderMenuState(MenuState, 2.0f * (Transition_Dur - 0.5f));
		else
			RenderMenuState(MenuState, 1.0f);

	if (ShowFPS)
		RenderFPS();

	glDisable(GL_BLEND);
	glEnable(GL_LIGHTING);

	glMatrixMode(GL_PROJECTION);							// select the projection matrix
	glPopMatrix();											// restore the old projection matrix
	glMatrixMode(GL_MODELVIEW);								// select the modelview matrix
	glEnable(GL_DEPTH_TEST);

	SDL_GL_SwapBuffers();				// swap the front- and back-buffer
}

void SetMenuState(const int NewState, const bool Transition)
{
	if (Transition)
	{
		PrevState = MenuState;
		Transition_Dur = 0.0f;
	}
	else
		Transition_Dur = 1.0f;
	MenuState = NewState;
}

