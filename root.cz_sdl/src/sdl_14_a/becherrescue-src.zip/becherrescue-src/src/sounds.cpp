#include "sounds.h"

#ifdef USE_SDL_MIXER

#include "global.h"

void PlaySfx(Mix_Chunk *Sound, const Vertex Position)
{
	int channel;
	if ((channel = Mix_PlayChannel(-1, Sound, 0)) != -1)
	{
		int i = int((Position.X - LookAt.X) * 32.0f);
		if (i > 0)
			Mix_SetPanning(channel, 255 - i, 255);
		else
			Mix_SetPanning(channel, 255, 255 + i);
	}
}

#endif
