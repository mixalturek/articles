#ifndef MUSIC_H
#define MUSIC_H

// play music from a file
bool PlayMusic(const char *FileName, const float Volume);

// stop playing the current music and free the associated memory
void FreeMusic();

#endif

