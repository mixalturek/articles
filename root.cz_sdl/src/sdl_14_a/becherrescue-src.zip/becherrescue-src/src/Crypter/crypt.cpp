#include <stdio.h>				// file operations
#include <conio.h>				// for 'Press any key' waiting (getch)
#include <string.h>				// string utilities
#include "Crypter_private.h"	// contains program version info

void PressAnyKeyToClose(void)
{
	printf("\nPress any key to close");
	getch();		// wait for key pressing
}

char *ReadWord(FILE *file, char *output, const bool Code = false)
{
	int c;

	// skip over spaces, tabs etc.
	do
		c = getc(file);
	while (c == '\t' || c == ' ' || c == '\r' || c == '\n');

	if (c == EOF)
	{
		*output = '\0';
		return output;
	}

	// read the word
	char *curr = output;
	*curr++ = Code ? c + 113 : c;
	c = getc(file);
	while (c != '\t' && c != ' ' && c != '\r' && c != '\n' && c != EOF)
	{
		*curr++ = Code ? c + 113 : c;
		c = getc(file);
	}
	*curr = '\0';
	return output;
}

void FatalError(const char *text)
{
	printf("\nERROR: %s\n", text);
	PressAnyKeyToClose();
}

int main(int argc, char *argv[])
{
	printf(COMPANY_NAME" "FILE_DESCRIPTION" "VER_STRING"\n"
		LEGAL_COPYRIGHT"\n"
		"For internal use only.\n\n"
		"Crypts a text file.\n\n"
		"USE: crypt.exe filename\n");

	if (!argv[1])		// no parameters
	{
		PressAnyKeyToClose();
		return 0;
	}

	char buf[1024];

	FILE *srcfile = fopen(argv[1], "r");		// open the file
	if (!srcfile)		// error check
	{
		printf("\n%s", argv[1]);
		FatalError("Cannot open the selected file.");
		return 0;
	}

	strcpy(buf, argv[1]);
	strncpy(buf + strlen(buf) - 3, "brx", 3);
	FILE *dstfile = fopen(buf, "wb");
	if (!dstfile)
	{
		printf("\n%s", buf);
		FatalError("Cannot create temporary file.");
		return 0;
	}

	if (!*ReadWord(srcfile, buf))
	{
		printf("\n%s", buf);
		FatalError("The file is corrupted.");
		return 0;
	}
	fprintf(dstfile, "%s ", buf);

	if (!*ReadWord(srcfile, buf))
	{
		printf("\n%s", buf);
		FatalError("The file is corrupted.");
		return 0;
	}
	fprintf(dstfile, "%s%c", buf, 27);

	while (*ReadWord(srcfile, buf, true))
		fprintf(dstfile, "%s%c", buf, 27);

	fclose(srcfile);
	fclose(dstfile);

	printf("\nThe file %s is crypted successfully.\n", argv[1]);
//	PressAnyKeyToClose();		<-- if there is no error don't wait for key pressing

	return 0;
}

