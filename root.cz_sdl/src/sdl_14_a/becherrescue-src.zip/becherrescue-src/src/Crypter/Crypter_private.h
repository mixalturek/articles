// THIS FILE WILL BE OVERWRITTEN BY DEV-C++!
// DO NOT EDIT!

#ifndef CRYPTER_PRIVATE_H
#define CRYPTER_PRIVATE_H

// VERSION DEFINITIONS
#define VER_STRING	"1.0.1.9"
#define VER_MAJOR	1
#define VER_MINOR	0
#define VER_RELEASE	1
#define VER_BUILD	9
#define COMPANY_NAME	"Zimtech"
#define FILE_VERSION	"1.0"
#define FILE_DESCRIPTION	"Crypter"
#define INTERNAL_NAME	"Crypter"
#define LEGAL_COPYRIGHT	"Copyright (c) Zimtech 2003"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"crypt.exe"
#define PRODUCT_NAME	"Crypter"
#define PRODUCT_VERSION	"1.0"

#endif //CRYPTER_PRIVATE_H
