#include "landscape.h"
#include <stdlib.h>
#include <SDL/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include "global.h"
#include "models.h"
#include "errors.h"
#include "texts.h"
#include "scene.h"
#include "textures.h"
#include <math.h>
#include "settings.h"
#include "font.h"
#ifndef WIN32
	#include <string.h>
#endif

enum
{
	LAND_TEX_GROUND = 0,
	LAND_TEX_WATER,
	LAND_TEX_BOTTLE,
	LAND_TEX_GRASS,
	LAND_TEX_BACKGROUND,
	LAND_TEX_BECHER,
	LAND_TEX_RESCUE,
	LAND_TEX_TEAM_LOGO,
	LAND_TEX_BG2003,
	LAND_TEX_NUM
};

struct LAND_DATA
{
	float Scene_Duration;
	float Camera_Duration;
	Model Ground;
	Model Water;
	Model Bottle_Left;
	Model Bottle_Right;
	Model Grass_Left;
	Model Grass_Center;
	Model Grass_Right;
	GLuint Textures[LAND_TEX_NUM];		// array of texture IDs
};

static LAND_DATA *LandData = NULL;

void LoadLandscapeData()
{
	LandData = new LAND_DATA;

	LandData->Scene_Duration = 0.0f;
	LandData->Camera_Duration = 0.0f;

	if (!LoadModel("models/menu/ground.br", &LandData->Ground))
	{
		delete LandData;
		FatalError(Texts[T_COULDNT_LOAD_MODEL], "models/menu/ground.br");
	}
	if (!LoadModel("models/menu/water.br", &LandData->Water))
	{
		ReleaseModel(&LandData->Ground);
		delete LandData;
		FatalError(Texts[T_COULDNT_LOAD_MODEL], "models/menu/water.br");
	}
	LandData->Water.Animations[0].FrameDuration = 1.5f;
	if (!LoadModel("models/menu/bottle_left.br", &LandData->Bottle_Left))
	{
		ReleaseModel(&LandData->Water);
		ReleaseModel(&LandData->Ground);
		delete LandData;
		FatalError(Texts[T_COULDNT_LOAD_MODEL], "models/menu/bottle_left.br");
	}
	if (!LoadModel("models/menu/bottle_right.br", &LandData->Bottle_Right))
	{
		ReleaseModel(&LandData->Bottle_Left);
		ReleaseModel(&LandData->Water);
		ReleaseModel(&LandData->Ground);
		delete LandData;
		FatalError(Texts[T_COULDNT_LOAD_MODEL], "models/menu/bottle_right.br");
	}
	if (!LoadModel("models/menu/grass_left.br", &LandData->Grass_Left))
	{
		ReleaseModel(&LandData->Bottle_Right);
		ReleaseModel(&LandData->Bottle_Left);
		ReleaseModel(&LandData->Water);
		ReleaseModel(&LandData->Ground);
		delete LandData;
		FatalError(Texts[T_COULDNT_LOAD_MODEL], "models/menu/grass_left.br");
	}
	if (!LoadModel("models/menu/grass_center.br", &LandData->Grass_Center))
	{
		ReleaseModel(&LandData->Grass_Left);
		ReleaseModel(&LandData->Bottle_Right);
		ReleaseModel(&LandData->Bottle_Left);
		ReleaseModel(&LandData->Water);
		ReleaseModel(&LandData->Ground);
		delete LandData;
		FatalError(Texts[T_COULDNT_LOAD_MODEL], "models/menu/grass_center.br");
	}
	if (!LoadModel("models/menu/grass_right.br", &LandData->Grass_Right))
	{
		ReleaseModel(&LandData->Grass_Center);
		ReleaseModel(&LandData->Grass_Left);
		ReleaseModel(&LandData->Bottle_Right);
		ReleaseModel(&LandData->Bottle_Left);
		ReleaseModel(&LandData->Water);
		ReleaseModel(&LandData->Ground);
		delete LandData;
		FatalError(Texts[T_COULDNT_LOAD_MODEL], "models/menu/grass_right.br");
	}

	for (int i = 0; i < LAND_TEX_NUM; i++)
	{
		char buf[1024];

		if (!i)
			strcpy(buf, "textures/menu/ground.bmp");
		else if (i == 1)
			strcpy(buf, "textures/menu/water.bmp");
		else if (i == 2)
			strcpy(buf, "textures/menu/bottle.bmp");
		else if (i == 3)
			strcpy(buf, "textures/menu/grass.bmp");
		else if (i == 4)
			strcpy(buf, "textures/menu/background.bmp");
		else if (i == 5)
			strcpy(buf, "textures/menu/becher.bmp");
		else if (i == 6)
			strcpy(buf, "textures/menu/rescue.bmp");
		else if (i == 7)
			strcpy(buf, "textures/menu/team_logo.bmp");
		else if (i == 8)
			strcpy(buf, "textures/menu/bg2003.bmp");

		if (!LoadTexture(buf, &LandData->Textures[i], i == 3 || i > 4 ? true : false))
		{
			for (int j = 0; j < i; j++)
				ReleaseTexture(&LandData->Textures[j]);
			ReleaseModel(&LandData->Grass_Right);
			ReleaseModel(&LandData->Grass_Center);
			ReleaseModel(&LandData->Grass_Left);
			ReleaseModel(&LandData->Bottle_Right);
			ReleaseModel(&LandData->Bottle_Left);
			ReleaseModel(&LandData->Water);
			ReleaseModel(&LandData->Ground);
			delete LandData;
			FatalError(Texts[T_COULDNT_LOAD_TEXTURE], buf, SDL_GetError());
		}
	}

	glMatrixMode(GL_PROJECTION);						// select the projection matrix
	glLoadIdentity();									// reset the projection matrix
	gluPerspective(30.0, 4.0 / 3.0, 1.8, 7.0);
	glMatrixMode(GL_MODELVIEW);							// select the modelview matrix

	// setup lights
	{
		GLfloat light0_ambient[4] = {0.5f, 0.5f, 0.5f, 1.0f};
		GLfloat light0_diffuse[4] = {0.5f, 0.5f, 0.5f, 1.0f};
		GLfloat light0_position[4] = {-20.0f, 100.0f, -20.0f, 0.0f};	// the light is directional (w = 0)
		GLfloat light0_spotdirection[3] = {0.0f, -1.0f, 1.0f};

		glLightfv(GL_LIGHT0, GL_AMBIENT, light0_ambient);
		glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse);
		glLightfv(GL_LIGHT0, GL_POSITION, light0_position);
		glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, light0_spotdirection);
		glEnable(GL_LIGHT0);

		GLfloat light1_position[4] = {-100.0f, 100.0f, 0.0f, 0.0f};		// the light is directional (w = 0)
		GLfloat light1_spotdirection[3] = {0.0f, -1.0f, 0.0f};

		glLightfv(GL_LIGHT1, GL_AMBIENT, light0_ambient);
		glLightfv(GL_LIGHT1, GL_DIFFUSE, light0_diffuse);
		glLightfv(GL_LIGHT1, GL_POSITION, light1_position);
		glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, light1_spotdirection);
		glEnable(GL_LIGHT1);

		glDisable(GL_LIGHT2);
		glDisable(GL_LIGHT3);
	}
}

void ReleaseLandscape()
{
	for (int i = 0; i < LAND_TEX_NUM; i++)
		ReleaseTexture(&LandData->Textures[i]);

	ReleaseModel(&LandData->Grass_Right);
	ReleaseModel(&LandData->Grass_Center);
	ReleaseModel(&LandData->Grass_Left);
	ReleaseModel(&LandData->Bottle_Right);
	ReleaseModel(&LandData->Bottle_Left);
	ReleaseModel(&LandData->Water);
	ReleaseModel(&LandData->Ground);

	delete LandData;
	LandData = NULL;
}

void RenderLandscape()
{
	LandData->Scene_Duration += Delay;
	while (LandData->Scene_Duration >= 15.0f)
		LandData->Scene_Duration -= 15.0f;

	LandData->Camera_Duration += Delay / 1.5f;
	while (LandData->Camera_Duration >= 6.283185f)			// 6.283185f = 2 PI
		LandData->Camera_Duration -= 6.283185f;

	glClear(GL_DEPTH_BUFFER_BIT);		// clear the depth buffer only
	glLoadIdentity();					// reset the current modelview matrix

	// place the camera
	float f = 0.01f * sin(LandData->Camera_Duration);
	gluLookAt(-4.5, 0.4 - f, 0.5 + 5.0f * f, 0.0, 0.0 - f, 0.5 + f, 0.0, 1.0, 0.0);

	// repair the lights (needed after glLoadIdentity() and gluLookAt())
	{
		GLfloat light0_position[4] = {-20.0f, 100.0f, -20.0f, 0.0f};	// the light is directional (w = 0)
		glLightfv(GL_LIGHT0, GL_POSITION, light0_position);
		GLfloat light1_position[4] = {-100.0f, 100.0f, 0.0f, 0.0f};		// the light is directional (w = 0)
		glLightfv(GL_LIGHT1, GL_POSITION, light1_position);
	}

	// render the background
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glBindTexture(GL_TEXTURE_2D, LandData->Textures[LAND_TEX_BACKGROUND]);
	glColor3f(LightIntensity, LightIntensity, LightIntensity);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex3f(0.0f, 1.2f, -1.15f);

		glTexCoord2f(0.0f, 1.0f);
		glVertex3f(0.0f, -0.9f, -1.15f);
		glTexCoord2f(1.0f, 1.0f);
		glVertex3f(0.0f, -0.9f, 2.15f);
		glTexCoord2f(1.0f, 0.0f);
		glVertex3f(0.0f, 1.2f, 2.15f);
	glEnd();
	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);

	RenderModelFrame(LandData->Ground, LandData->Textures[LAND_TEX_GROUND], 0, 0);
	RenderModelFrame(LandData->Bottle_Left, LandData->Textures[LAND_TEX_BOTTLE], 0, 0);
	RenderModelFrame(LandData->Bottle_Right, LandData->Textures[LAND_TEX_BOTTLE], 0, 0);

	glDepthMask(0);						// set depth-buffer to read-only mode

	if (HighDetails)
	{
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);		// blending function for transparency based on alfa-value
		glEnable(GL_BLEND);

		RenderModelFrame(LandData->Grass_Right, LandData->Textures[LAND_TEX_GRASS], 0, 0);
		RenderModelFrame(LandData->Grass_Center, LandData->Textures[LAND_TEX_GRASS], 0, 0);
		RenderModelFrame(LandData->Grass_Left, LandData->Textures[LAND_TEX_GRASS], 0, 0);
	}

	GLfloat diffuse[4] = {0.8f, 0.8f, 0.8f, 0.6f};
	glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);

	RenderModelAnimation(LandData->Water, LandData->Textures[LAND_TEX_WATER], 0, LandData->Scene_Duration);

	diffuse[3] = 1.0f;
	glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse);

	if (HighDetails)
		glDisable(GL_BLEND);

	glDepthMask(1);						// set depth-buffer to read-write mode

	glDisable(GL_DEPTH_TEST);
	glMatrixMode(GL_PROJECTION);							// select the projection matrix
	glPushMatrix();											// store the projection matrix
	glLoadIdentity();										// reset the projection matrix
	glOrtho(0.0, 640.0, 0.0, 480.0, -1.0, 1.0);				// set up an ortho screen
	glMatrixMode(GL_MODELVIEW);								// select the modelview matrix
	glLoadIdentity();										// reset the modelview matrix

	glDisable(GL_LIGHTING);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);		// blending function for transparency based on alfa-value
	glEnable(GL_BLEND);

	glColor4f(LightIntensity, LightIntensity, LightIntensity, 0.9f);

	// render 'Becher' text
	glBindTexture(GL_TEXTURE_2D, LandData->Textures[LAND_TEX_BECHER]);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.003906f);
		glVertex2f(7.0f, 475.0f);
		glTexCoord2f(0.0f, 0.8125f);
		glVertex2f(7.0f, 425.0f);
		glTexCoord2f(0.957031f, 0.8125f);
		glVertex2f(251.0f, 425.0f);
		glTexCoord2f(0.957031f, 0.003906f);
		glVertex2f(251.0f, 475.0f);
	glEnd();

	// render 'Rescue' text
	glBindTexture(GL_TEXTURE_2D, LandData->Textures[LAND_TEX_RESCUE]);
	glBegin(GL_QUADS);
		glTexCoord2f(0.011718f, 0.027344f);
		glVertex2f(278.0f, 475.0f);
		glTexCoord2f(0.011718f, 0.796875f);
		glVertex2f(278.0f, 425.0f);
		glTexCoord2f(0.953125f, 0.796875f);
		glVertex2f(518.0f, 425.0f);
		glTexCoord2f(0.953125f, 0.027344f);
		glVertex2f(518.0f, 475.0f);
	glEnd();

	// render team logo
	glBindTexture(GL_TEXTURE_2D, LandData->Textures[LAND_TEX_TEAM_LOGO]);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0625f, 0.046875f);
		glVertex2f(8.0f, 97.0f);
		glTexCoord2f(0.0625f, 0.757812f);
		glVertex2f(8.0f, 6.0f);
		glTexCoord2f(0.773437f, 0.757812f);
		glVertex2f(99.0f, 6.0f);
		glTexCoord2f(0.773437f, 0.046875f);
		glVertex2f(99.0f, 97.0f);
	glEnd();

	// render Becher Game logo
	glBindTexture(GL_TEXTURE_2D, LandData->Textures[LAND_TEX_BG2003]);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(474.0f, 86.0f);
		glTexCoord2f(0.0f, 0.578125f);
		glVertex2f(474.0f, 12.0f);
		glTexCoord2f(0.589844f, 0.578125f);
		glVertex2f(625.0f, 12.0f);
		glTexCoord2f(0.589844f, 0.0f);
		glVertex2f(625.0f, 86.0f);
	glEnd();

	RenderText(105.0f, 33.0f, "Copyright � Zimtech 2003\n(http://zimtech.ceskehry.cz)", 0.3f * LightIntensity, 0.6f * LightIntensity, 0.8f * LightIntensity, 0.9f);
}

