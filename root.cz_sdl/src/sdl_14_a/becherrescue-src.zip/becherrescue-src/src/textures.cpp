#include "textures.h"
#include <SDL/SDL.h>
#include <GL/glu.h>
#include <GL/glext.h>
#include "settings.h"
#include <string.h>

bool LoadTexture(const char *PathName, GLuint *TextureID, const bool bTransparent)
{
	// generate an empty texture
	glGenTextures(1, TextureID);

	// load the BMP file into a surface
	SDL_Surface *image = SDL_LoadBMP(PathName);
	if (!image)
		return false;

	SDL_Surface *alpha = NULL;
	if (bTransparent)		// it is a transparent texture?
	{
		// load the alpha-channel BMP file into a surface
		char buf[1024];
		strcpy(buf, PathName);
		buf[strlen(buf) - 4] = '\0';
		strcat(buf, "_a.bmp");
		alpha = SDL_LoadBMP(buf);
		if (!alpha)
		{
			SDL_FreeSurface(image);
			return false;
		}
	}

	// choose this texture
	glBindTexture(GL_TEXTURE_2D, *TextureID);

	// setup the texture parameters
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, Filtering ? GL_LINEAR : GL_NEAREST);
	if (Mipmapping)
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, Filtering ? GL_LINEAR_MIPMAP_NEAREST : GL_NEAREST_MIPMAP_NEAREST);
	else
		glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, Filtering ? GL_LINEAR : GL_NEAREST);

	if (bTransparent)		// it is transparent texture
	{
		// create RGBA texture data
		Uint8 *rgba = new Uint8[image->w * image->h * 4];	// temporary buffer
		Uint8 *max = rgba + image->w * image->h * 4;
		for (Uint8 *prgba = rgba, *palpha = (Uint8 *)alpha->pixels, *pimage = (Uint8 *)image->pixels;
			prgba < max; prgba += 4, palpha++, pimage += 3)
		{
			*prgba = *(pimage + 2);				// red channel
			*(prgba + 1) = *(pimage + 1);		// green channel
			*(prgba + 2) = *pimage;				// blue channel
			*(prgba + 3) = *palpha;				// alpha channel
		}

		// load the texture into OpenGL
		if (Mipmapping)
			gluBuild2DMipmaps(GL_TEXTURE_2D, 4, image->w, image->h, GL_RGBA, GL_UNSIGNED_BYTE, rgba);
		else
			glTexImage2D(GL_TEXTURE_2D, 0, 4, image->w, image->h, 0, GL_RGBA, GL_UNSIGNED_BYTE, rgba);

		delete[] rgba;
		SDL_FreeSurface(alpha);
	}
	else		// it is normal texture
	{
		// load the texture into OpenGL
		if (Mipmapping)
			gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image->w, image->h, GL_BGR, GL_UNSIGNED_BYTE, image->pixels);
		else
			glTexImage2D(GL_TEXTURE_2D, 0, 3, image->w, image->h, 0, GL_BGR, GL_UNSIGNED_BYTE, image->pixels);
	}

	// free the allocated BMP surface
	SDL_FreeSurface(image);

	return true;
}

void ReleaseTexture(const GLuint *TextureID)
{
	// delete the texture specified with its ID
	glDeleteTextures(1, TextureID);
}
