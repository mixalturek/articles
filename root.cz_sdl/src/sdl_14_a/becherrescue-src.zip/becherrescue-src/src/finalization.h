#ifndef FINALIZATION_H
#define FINALIZATION_H

// release all associated memory and other resources
void Finalize();

#endif

