#include "finalization.h"
#include <stdlib.h>
#include <SDL/SDL.h>
#include "consts.h"
#ifdef USE_SDL_MIXER
	#include <SDL/SDL_mixer.h>
#endif
#include "texts.h"
#include "settings.h"
#include "global.h"
#include "errors.h"
#include "models.h"
#include "textures.h"
#include "map.h"
#include "music.h"
#include "font.h"
#include "game.h"
#include "menu.h"

#ifdef WIN32
	#include <windows.h>
#endif

void Finalize()
{
#ifdef WIN32
	SystemParametersInfo(SPI_SETSCREENSAVEACTIVE, ScreenSaverEnabled, NULL, 0);
#endif

	if ((AppState >= APP_MENU_FADE_IN && AppState <= APP_MENU_FADE_OUT) || AppState == APP_MENU_EXIT)
		ReleaseMenu();

	ReleaseFont();

#ifdef USE_SDL_MIXER
	// halt playback on all channels
	Mix_HaltChannel(-1);

	// release all sounds
	for (int i = 0; i < SOUNDS_NUM; i++)
		if (Sounds[i])
			Mix_FreeChunk(Sounds[i]);
#endif

	// stop playing the current music and free the associated memory
	FreeMusic();

#ifdef USE_SDL_MIXER
	Mix_CloseAudio();
#endif

	// release the map data
	ReleaseMap(&Map);

	// release all textures
	for (int i = 0; i < TEXTURES_NUM; i++)
		if (Textures[i])
			ReleaseTexture(&Textures[i]);

	// release all models
	if (AreModelsLoaded)
	{
		ReleaseModel(&Hero_Body);
		ReleaseModel(&Hero_Head);
		ReleaseModel(&Hero_Hand_Left);
		ReleaseModel(&Hero_Hand_Right);
		ReleaseModel(&Hero_Sword);
		ReleaseModel(&Hero_Potion);
		ReleaseModel(&Raider1_Body);
		ReleaseModel(&Raider1_Head);
		ReleaseModel(&Raider1_Hand_Left);
		ReleaseModel(&Raider1_Hand_Right);
		ReleaseModel(&Raider1_Club);
		ReleaseModel(&Raider2_Body);
		ReleaseModel(&Raider2_Head);
		ReleaseModel(&Raider2_Hand_Left);
		ReleaseModel(&Raider2_Hand_Right);
		ReleaseModel(&Raider2_Axe);
		ReleaseModel(&Raider2_Helmet);
		ReleaseModel(&Knight_Body);
		ReleaseModel(&Knight_Head);
		ReleaseModel(&Knight_Hand_Left);
		ReleaseModel(&Knight_Hand_Right);
		ReleaseModel(&Knight_Sword);
		ReleaseModel(&Knight_Helmet);
		ReleaseModel(&Knight_Shield);
	}

	if (!SaveSettings(ConfigFilePath))
		Error(Texts[T_COULDNT_SAVE_SETTINGS], ConfigFilePath);
	free(ConfigFilePath);

	ReleaseTexts();

	SDL_JoystickClose(Joystick);

	SDL_Quit();
}

