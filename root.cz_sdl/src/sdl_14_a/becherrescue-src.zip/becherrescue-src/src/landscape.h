#ifndef LANDSCAPE_H
#define LANDSCAPE_H

// load landscape files
void LoadLandscapeData();

// release landscape files
void ReleaseLandscape();

// render landscape
void RenderLandscape();

#endif

