#ifndef MENU_H
#define MENU_H

enum
{
	MENU_MENUSTATE = 0,
	PROLOGUE_MENUSTATE,
	EPILOGUE_MENUSTATE,
	SCORETAB_MENUSTATE,
	HELP_MENUSTATE,
	CREDITS_MENUSTATE
};

extern int MenuState;

// load menu files & init menu
void LoadMenuData();

// release menu files
void ReleaseMenu();

// render menu
void RenderMenu();

// set menu state (call this instead of assigning to MenuState)
void SetMenuState(const int NewState, const bool Transition = true);

#endif

