#ifndef CONSTS_H
#define CONSTS_H

//#define USE_SDL_MIXER

#define	SZ_CONFIG_FILE_NAME					"Becher Rescue.cfg"
#define	SZ_WINDOW_CAPTION					"Becher Rescue"

#define MAX_MODEL_VERTEX_COUNT				1000	// next, do this by allocating a memory at app start up
#define MAX_MODEL_FACE_COUNT				2000	// next, do this by allocating a memory at app start up
#define MAX_DELAY							0.05f	// [s]; 20 fps is minimum frame-rate
#define MAX_ACTORS							200

#define DOUBLE_PRESS_DELAY					500 	// the time between two press of one key [ms]

#define JUMP_POWER_DECREASE					40.0f	// the value the gravitation decreases the jump power [m/s]
#define JUMP_POWER_AFTER_WALK				11.5f	// the actor's jump power after walking/staying [m/s]
#define JUMP_POWER_AFTER_RUN				14.5f	// the actor's jump power after running [m/s]
#define JUMP_ATTACK_SPEED					10.0f	// speed of the attack after running [m/s]

#define DRINKING_TIME						0.4f 	// the time the actor drinks the potion [s]
#define EXPLOSION_TIME						0.5f

// hero model constants

#define	SZ_MODEL_HERO_BODY_PATH				"models/actors/hero/body.br"
#define	SZ_MODEL_HERO_HEAD_PATH				"models/actors/hero/head.br"
#define	SZ_MODEL_HERO_HAND_LEFT_PATH		"models/actors/hero/hand_left.br"
#define	SZ_MODEL_HERO_HAND_RIGHT_PATH		"models/actors/hero/hand_right.br"
#define	SZ_MODEL_HERO_SWORD_PATH			"models/actors/hero/sword.br"
#define	SZ_MODEL_HERO_POTION_PATH			"models/actors/hero/potion.br"

#define	SZ_HERO_BODY_TEXTURE1_PATH			"textures/actors/hero/body1.bmp"
#define	SZ_HERO_BODY_TEXTURE2_PATH			"textures/actors/hero/body2.bmp"
#define	SZ_HERO_HEAD_TEXTURE1_PATH			"textures/actors/hero/head1.bmp"
#define	SZ_HERO_HEAD_TEXTURE2_PATH			"textures/actors/hero/head2.bmp"
#define	SZ_HERO_HAND_TEXTURE1_PATH			"textures/actors/hero/hand1.bmp"
#define	SZ_HERO_HAND_TEXTURE2_PATH			"textures/actors/hero/hand2.bmp"
#define	SZ_HERO_SWORD_TEXTURE_PATH			"textures/actors/hero/sword.bmp"
#define	SZ_HERO_POTION_TEXTURE_PATH			"textures/actors/hero/potion.bmp"

#define BODY_RADIUS							0.3f
#define BODY_HEIGHT							1.75f

#define HIT_RADIUS							0.45f
#define HIT_SHIFT							1.0f
#define HIT_HEIGHT							1.2f

#define HERO_LYING_TIME						1.0f	// the time the hero lies on the ground [s]
#define HERO_FLYING_TIME					0.41f	// the time the hero flies after jump after run [s]
#define HERO_BLOCKING_TIME					0.3f	// the time the hero blocks a hit [s]

#define HERO_WALK_SPEED						3.0f	// walking speed [m/s]
#define HERO_RUN_SPEED						6.0f	// running speed [m/s]
#define HERO_FALL_SPEED						6.0f	// falling speed [m/s]

// raider1 model constants

#define	SZ_MODEL_RAIDER1_BODY_PATH			"models/actors/raider1/body.br"
#define	SZ_MODEL_RAIDER1_HEAD_PATH			"models/actors/raider1/head.br"
#define	SZ_MODEL_RAIDER1_HAND_LEFT_PATH		"models/actors/raider1/hand_left.br"
#define	SZ_MODEL_RAIDER1_HAND_RIGHT_PATH	"models/actors/raider1/hand_right.br"
#define	SZ_MODEL_RAIDER1_CLUB_PATH			"models/actors/raider1/club.br"

#define	SZ_RAIDER1_BODY_TEXTURE1_PATH		"textures/actors/raider1/body1.bmp"
#define	SZ_RAIDER1_BODY_TEXTURE2_PATH		"textures/actors/raider1/body2.bmp"
#define	SZ_RAIDER1_BODY_TEXTURE3_PATH		"textures/actors/raider1/body3.bmp"
#define	SZ_RAIDER1_HEAD_TEXTURE1_PATH		"textures/actors/raider1/head1.bmp"
#define	SZ_RAIDER1_HEAD_TEXTURE2_PATH		"textures/actors/raider1/head2.bmp"
#define	SZ_RAIDER1_HEAD_TEXTURE3_PATH		"textures/actors/raider1/head3.bmp"
#define	SZ_RAIDER1_HAND_TEXTURE1_PATH		"textures/actors/raider1/hand1.bmp"
#define	SZ_RAIDER1_HAND_TEXTURE2_PATH		"textures/actors/raider1/hand2.bmp"
#define	SZ_RAIDER1_HAND_TEXTURE3_PATH		"textures/actors/raider1/hand3.bmp"
#define	SZ_RAIDER1_CLUB_TEXTURE1_PATH		"textures/actors/raider1/club1.bmp"
#define	SZ_RAIDER1_CLUB_TEXTURE2_PATH		"textures/actors/raider1/club2.bmp"
#define	SZ_RAIDER1_CLUB_TEXTURE3_PATH		"textures/actors/raider1/club3.bmp"

// raider2 model constants

#define	SZ_MODEL_RAIDER2_BODY_PATH			"models/actors/raider2/body.br"
#define	SZ_MODEL_RAIDER2_HEAD_PATH			"models/actors/raider2/head.br"
#define	SZ_MODEL_RAIDER2_HAND_LEFT_PATH		"models/actors/raider2/hand_left.br"
#define	SZ_MODEL_RAIDER2_HAND_RIGHT_PATH	"models/actors/raider2/hand_right.br"
#define	SZ_MODEL_RAIDER2_AXE_PATH			"models/actors/raider2/axe.br"
#define	SZ_MODEL_RAIDER2_HELMET_PATH		"models/actors/raider2/helmet.br"

#define	SZ_RAIDER2_BODY_TEXTURE1_PATH		"textures/actors/raider2/body1.bmp"
#define	SZ_RAIDER2_HEAD_TEXTURE1_PATH		"textures/actors/raider2/head1.bmp"
#define	SZ_RAIDER2_HAND_TEXTURE1_PATH		"textures/actors/raider2/hand1.bmp"
#define	SZ_RAIDER2_AXE_TEXTURE1_PATH		"textures/actors/raider2/axe1.bmp"
#define	SZ_RAIDER2_AXE_TEXTURE3_PATH		"textures/actors/raider2/axe3.bmp"
#define	SZ_RAIDER2_HELMET_TEXTURE1_PATH		"textures/actors/raider2/helmet1.bmp"

// knight model constants

#define	SZ_MODEL_KNIGHT_BODY_PATH			"models/actors/knight/body.br"
#define	SZ_MODEL_KNIGHT_HEAD_PATH			"models/actors/knight/head.br"
#define	SZ_MODEL_KNIGHT_HAND_LEFT_PATH		"models/actors/knight/hand_left.br"
#define	SZ_MODEL_KNIGHT_HAND_RIGHT_PATH		"models/actors/knight/hand_right.br"
#define	SZ_MODEL_KNIGHT_SWORD_PATH			"models/actors/knight/sword.br"
#define	SZ_MODEL_KNIGHT_HELMET_PATH			"models/actors/knight/helmet.br"
#define	SZ_MODEL_KNIGHT_SHIELD_PATH			"models/actors/knight/shield.br"

#define	SZ_KNIGHT_BODY_TEXTURE1_PATH		"textures/actors/knight/body1.bmp"
#define	SZ_KNIGHT_BODY_TEXTURE2_PATH		"textures/actors/knight/body2.bmp"
#define	SZ_KNIGHT_HEAD_TEXTURE1_PATH		"textures/actors/knight/head1.bmp"
#define	SZ_KNIGHT_HEAD_TEXTURE2_PATH		"textures/actors/knight/head2.bmp"
#define	SZ_KNIGHT_HAND_TEXTURE1_PATH		"textures/actors/knight/hand1.bmp"
#define	SZ_KNIGHT_HAND_TEXTURE2_PATH		"textures/actors/knight/hand2.bmp"
#define	SZ_KNIGHT_SWORD_TEXTURE1_PATH		"textures/actors/knight/sword1.bmp"
#define	SZ_KNIGHT_SWORD_TEXTURE2_PATH		"textures/actors/knight/sword2.bmp"
#define	SZ_KNIGHT_HELMET_TEXTURE1_PATH		"textures/actors/knight/helmet1.bmp"
#define	SZ_KNIGHT_HELMET_TEXTURE2_PATH		"textures/actors/knight/helmet2.bmp"
#define	SZ_KNIGHT_SHIELD_TEXTURE1_PATH		"textures/actors/knight/shield1.bmp"
#define	SZ_KNIGHT_SHIELD_TEXTURE2_PATH		"textures/actors/knight/shield2.bmp"

#define	SZ_SHADOW_TEXTURE_PATH				"textures/actors/shadow.bmp"
#define	SZ_EXPLOSION_TEXTURE_PATH			"textures/actors/explosion.bmp"

#define	SZ_BOTTLE_BIG_TEXTURE_PATH			"textures/hud/bottle_big.bmp"
#define	SZ_BOTTLE_LITTLE_TEXTURE_PATH		"textures/hud/bottle_little.bmp"
#define	SZ_LIFE_TEXTURE_PATH				"textures/hud/life.bmp"

#define	MAX_HEALTH_HERO						150
#define	DAMAGE_HERO							14

#define	JOYSTICK_DEADZONE					7500

// texture constants
enum
{
	HERO_BODY_TEXTURE1 = 0,
	HERO_BODY_TEXTURE2,
	HERO_HEAD_TEXTURE1,
	HERO_HEAD_TEXTURE2,
	HERO_HAND_TEXTURE1,
	HERO_HAND_TEXTURE2,
	HERO_SWORD_TEXTURE,
	HERO_POTION_TEXTURE,
	RAIDER1_BODY_TEXTURE1,
	RAIDER1_BODY_TEXTURE2,
	RAIDER1_BODY_TEXTURE3,
	RAIDER1_HEAD_TEXTURE1,
	RAIDER1_HEAD_TEXTURE2,
	RAIDER1_HEAD_TEXTURE3,
	RAIDER1_HAND_TEXTURE1,
	RAIDER1_HAND_TEXTURE2,
	RAIDER1_HAND_TEXTURE3,
	RAIDER1_CLUB_TEXTURE1,
	RAIDER1_CLUB_TEXTURE2,
	RAIDER1_CLUB_TEXTURE3,
	RAIDER2_BODY_TEXTURE1,
	RAIDER2_HEAD_TEXTURE1,
	RAIDER2_HAND_TEXTURE1,
	RAIDER2_AXE_TEXTURE1,
	RAIDER2_AXE_TEXTURE3,
	RAIDER2_HELMET_TEXTURE1,
	KNIGHT_BODY_TEXTURE1,
	KNIGHT_BODY_TEXTURE2,
	KNIGHT_HEAD_TEXTURE1,
	KNIGHT_HEAD_TEXTURE2,
	KNIGHT_HAND_TEXTURE1,
	KNIGHT_HAND_TEXTURE2,
	KNIGHT_SWORD_TEXTURE1,
	KNIGHT_SWORD_TEXTURE2,
	KNIGHT_HELMET_TEXTURE1,
	KNIGHT_HELMET_TEXTURE2,
	KNIGHT_SHIELD_TEXTURE1,
	KNIGHT_SHIELD_TEXTURE2,
	SHADOW_TEXTURE,
	EXPLOSION_TEXTURE,
	BOTTLE_BIG_TEXTURE,
	BOTTLE_LITTLE_TEXTURE,
	LIFE_TEXTURE,
	FONT_TEXTURE,
	TEXTURES_NUM
};

enum
{
	FALL_SOUND = 0,
	FOOT_SPLASH_SOUND,
	HERO_ATTACK1_SOUND,
	HERO_ATTACK2_SOUND,
	HIT1_SOUND,
	HIT2_SOUND,
	HIT3_SOUND,
	HIT4_SOUND,
	JUMP_SOUND,
	KNIGHT_ATTACK_SOUND,
	MAGIC_SOUND,
	SOUNDS_NUM
};

#endif

