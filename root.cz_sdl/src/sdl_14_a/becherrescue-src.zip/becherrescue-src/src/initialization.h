#ifndef INITIALIZATION_H
#define INITIALIZATION_H

// initialize all parts of my application
void Initialize(int argc, char *argv[]);

#endif

