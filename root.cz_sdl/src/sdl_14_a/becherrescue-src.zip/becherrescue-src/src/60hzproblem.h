#ifndef _60HZPROBLEM_H
#define _60HZPROBLEM_H

// call this function in Windows XP/2000 to set better monitor frequency instead of 60 Hz
void Solve60HzProblem(const int MaxFrequency);

#endif

