#ifndef TEXTS_H
#define TEXTS_H

enum
{
	T_ERROR = 0,					// the first line in the file with texts
	T_COULDNT_INITIALIZE_SDL,
	T_COULDNT_SET_VIDEO_MODE,
	T_COULDNT_LOAD_MODEL,
	T_COULDNT_SAVE_SETTINGS,
	T_COULDNT_LOAD_TEXTURE,
	T_COULDNT_LOAD_MAP,
	T_F1_START_GAME,
	T_F2_ONE_PLAYER,
	T_F2_TWO_PLAYERS,
	T_F3_DIFFICULTY_EASY,
	T_F3_DIFFICULTY_NORMAL,
	T_F3_DIFFICULTY_HARD,
	T_F4_JOYSTICK_NOT_ASSIGNED,
	T_F4_JOYSTICK_ASSIGNED_TO_P1,
	T_F4_JOYSTICK_ASSIGNED_TO_P2,
	T_F5_VIEW_SCORES,
	T_F6_HELP,
	T_F7_CREDITS,
	T_ESC_EXIT,
	T_QUIT_MESSAGE,
	T_PAUSED,
	T_CREDITS_LEFT,
	T_STAGE,
	T_COULDNT_INITIALIZE_SOUND_SUBSYSTEM,
	T_COULDNT_LOAD_SOUND,
	T_COULDNT_LOAD_MUSIC,
	T_GAME_OVER,
	T_PROLOGUE,
	T_EPILOGUE,
	T_HELP,
	T_CREDITS,
	T_SCORETAB_TITLE,
	TEXTS_NUM						// number of texts
};

extern char *Texts[TEXTS_NUM];		// the array of texts
extern bool TextsAreLoaded;			// are all texts loaded into memory?

// load texts from a file
bool LoadTexts(const char *FileName);

// release all texts from the memory
void ReleaseTexts();

#endif

