#ifndef SCENE_H
#define SCENE_H

#include "actor.h"
#include "consts.h"

#define PLAYER1		0
#define PLAYER2		1
#define ENEMY0		2

extern ACTOR Actors[MAX_ACTORS];			// all actors
extern float LightIntensity;

// get the height at the specified point
float GetSceneHeight(const ACTOR *Actor, const float X, const float Y);

// get the highest height in the specified rectangle
float GetSceneRectHeight(const ACTOR *Actor, const float X, const float Y, const float Radius);

// hit actors in a specified box (true if someone was hit)
bool HitActorsInBox(ACTOR *Actor, const float X, const float Y, const float Z, const float Radius, const int Damage);

// update all actors
void UpdateAllActors();

// set the intensity of all lights
void SetLightIntensity(const float Intensity);

// render the scene
void RenderScene();

// call this every frame
void UpdateFPS();

// render FPS
void RenderFPS();

#endif

