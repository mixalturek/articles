#include "keys.h"

int Keys[KEYS_NUM];
Uint32 KeysPressTime[KEYS_NUM];
Uint32 KeysPressTimePrev[KEYS_NUM];

void KeyEvent(const SDLKey Key, const bool Down)
{
	int key;

	switch (Key)
	{
		// player 1 keys
		case SDLK_KP2:				// primary key
		case SDLK_SEMICOLON:		// secondary key
		case SDLK_DOWN:
			key = PLAYER1_DOWN_KEY;
			break;
		case SDLK_KP3:
		case SDLK_QUOTE:
			key = PLAYER1_RDOWN_KEY;
			break;
		case SDLK_KP6:
		case SDLK_LEFTBRACKET:
		case SDLK_RIGHT:
			key = PLAYER1_RIGHT_KEY;
			break;
		case SDLK_KP9:
		case SDLK_MINUS:
			key = PLAYER1_RUP_KEY;
			break;
		case SDLK_KP8:
		case SDLK_0:
		case SDLK_UP:
			key = PLAYER1_UP_KEY;
			break;
		case SDLK_KP7:
		case SDLK_9:
			key = PLAYER1_LUP_KEY;
			break;
		case SDLK_KP4:
		case SDLK_o:
		case SDLK_LEFT:
			key = PLAYER1_LEFT_KEY;
			break;
		case SDLK_KP1:
		case SDLK_l:
			key = PLAYER1_LDOWN_KEY;
			break;
		case SDLK_KP5:
		case SDLK_p:
		case SDLK_PERIOD:
			key = PLAYER1_FIRE_KEY;
			break;
		case SDLK_KP0:
		case SDLK_COMMA:
			key = PLAYER1_JUMP_KEY;
			break;
		case SDLK_KP_ENTER:
		case SDLK_RETURN:
			key = PLAYER1_MAGIC_KEY;
			break;
		// player 2 keys
		case SDLK_x:
			key = PLAYER2_DOWN_KEY;
			break;
		case SDLK_c:
			key = PLAYER2_RDOWN_KEY;
			break;
		case SDLK_d:
			key = PLAYER2_RIGHT_KEY;
			break;
		case SDLK_e:
			key = PLAYER2_RUP_KEY;
			break;
		case SDLK_w:
			key = PLAYER2_UP_KEY;
			break;
		case SDLK_q:
			key = PLAYER2_LUP_KEY;
			break;
		case SDLK_a:
			key = PLAYER2_LEFT_KEY;
			break;
		case SDLK_z:
			key = PLAYER2_LDOWN_KEY;
			break;
		case SDLK_s:
		case SDLK_LSHIFT:			// secondary key
			key = PLAYER2_FIRE_KEY;
			break;
		case SDLK_TAB:
			key = PLAYER2_JUMP_KEY;
			break;
		case SDLK_LCTRL:
			key = PLAYER2_MAGIC_KEY;
			break;
		default:					// unknown key
			return;
	}

	if (Down)
	{
		if (!Keys[key])			// the key is pressed for the first time
		{
			Keys[key] = 1;		// the first press
			KeysPressTimePrev[key] = KeysPressTime[key];
			KeysPressTime[key] = SDL_GetTicks();
		}
	}
	else
		Keys[key] = 0;
}
