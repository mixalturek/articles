#include <stdio.h>				// file operations
#include <stdlib.h>				// string->int/float conversions (strtol, strtod)
#include <conio.h>				// for 'Press any key' waiting (getch)
#include <string.h>				// string utilities
#include "ModelConvertor_private.h"		// contains program version info

#define FRAME_DURATION			0.0625f;		// 16 fps

typedef unsigned short WORD;	// 16bit unsigned integer (0..65535)

struct tvert					// contains coordinates in a texture
{
	float x, y;
};

struct face			// contains indices of vertices which a face (polygon) consists from
{
	WORD A, B, C;
};

void PressAnyKeyToClose(void)
{
	printf("\nPress any key to close");
	getch();		// wait for key pressing
}

char *ReadWord(FILE *file, char *output)
{
	int c;

	// skip over spaces, tabs etc.
	do
		c = getc(file);
	while (c == '\t' || c == ' ' || c == '\r' || c == '\n');

	if (c == EOF)
	{
		*output = '\0';
		return output;
	}

	// read the word
	char *curr = output;
	*curr++ = c;
	c = getc(file);
	while (c != '\t' && c != ' ' && c != '\r' && c != '\n' && c != EOF)
	{
		*curr++ = c;
		c = getc(file);
	}
	*curr = '\0';
	return output;
}

void SkipWord(FILE *file)
{
	int c;

	// skip over spaces, tabs etc.
	do
		c = getc(file);
	while (c == '\t' || c == ' ' || c == '\r' || c == '\n');

	if (c == EOF)
		return;

	// skip the word
	c = getc(file);
	while (c != '\t' && c != ' ' && c != '\r' && c != '\n' && c != EOF)
		c = getc(file);
}

void FatalError(const char *text)
{
	printf("\nERROR: %s\n", text);
	PressAnyKeyToClose();
}

int main(int argc, char *argv[])
{
	printf(COMPANY_NAME" "FILE_DESCRIPTION" "VER_STRING"\n"
		LEGAL_COPYRIGHT"\n"
		"For internal use only.\n\n"
		"Converts animated 3D models from ASCII Scene Export files (*.ASE) to Zimtech\nbinary format.\n\n"
		"USE: modelconv.exe \"Your model.ASE\" OR modelconv.exe \"Your model-something.ASE\"\n");

	if (!argv[1])		// no parameters
	{
		PressAnyKeyToClose();
		return 0;
	}

	char buf[256];

	FILE *srcfile = fopen(argv[1], "r");		// open the file
	if (!srcfile)		// error check
	{
		printf("\n%s", argv[1]);
		FatalError("Cannot open the selected .ASE file.");
		return 0;
	}

	bool empty_src = false;

	if (strcmp(ReadWord(srcfile, buf), "*3DSMAX_ASCIIEXPORT"))
		if (*buf)
		{
			fclose(srcfile);
			FatalError("This is not an ASCII Scene Export file.");
			return 0;
		}
		else
			empty_src = true;

	// remove '"' from the beginning and the end of the file name and copy it to buf
	if (*argv[1] == '"')
	{
		strcpy(buf, argv[1] + 1);
		buf[strlen(buf) - 1] = 0;
	}
	else
		strcpy(buf, argv[1]);

	// find the beginning of the file extension
	char *c = buf + strlen(buf) - 1;
	while (*c != '-' && c != buf)		// find last '-'
		c--;
	if (c == buf)			// it is at the beginning of the file name
		c = buf + strlen(buf) - 4;		// go before file extension

	strcpy(c, ".br");		// an extension for Becher Rescue game

	int i, numframes = 1, numverts, numfaces;
	bool animated;			// is the model animated?
	bool appending;			// is the model animation appended at the end of an already existing file?

	FILE *dstfile = fopen(buf, "r+b");		// open the file for read-write
	if (appending = dstfile)
	{
		if (fread(buf, sizeof(char), 16, dstfile) < 16)		// check file type
		{
			fclose(dstfile);
			fclose(srcfile);
			printf("\n%s", buf);
			FatalError("This is not Zimtech 3D Model.");
			return false;
		}
		buf[16] = 0;							// breakpoint
		if (strcmp(buf, "Zimtech 3D Model"))
		{
			fclose(dstfile);
			fclose(srcfile);
			printf("\n%s", buf);
			FatalError("This is not Zimtech 3D Model.");
			return false;
		}

		fread(&i, sizeof(i), 1, dstfile);		// check file version
		if (i != 1)			// major version
		{
			fclose(dstfile);
			fclose(srcfile);
			printf("\n%s", buf);
			FatalError("Wrong version.");
			return false;
		}
		fread(&i, sizeof(i), 1, dstfile);
		if (i)				// minor version
		{
			fclose(dstfile);
			fclose(srcfile);
			printf("\n%s", buf);
			FatalError("Wrong version.");
			return false;
		}

		fread(&i, sizeof(i), 1, dstfile);		// check flags
		if (i)				// flags
		{
			fclose(dstfile);
			fclose(srcfile);
			printf("\n%s", buf);
			FatalError("Wrong version.");
			return false;
		}

		// load number of vertexes
		if (!fread(&numverts, sizeof(numverts), 1, dstfile))
		{
			fclose(dstfile);
			fclose(srcfile);
			printf("\n%s", buf);
			FatalError("The file is corrupted.");
			return false;
		}

		// load number of faces
		if (!fread(&numfaces, sizeof(numfaces), 1, dstfile))
		{
			fclose(dstfile);
			fclose(srcfile);
			printf("\n%s", buf);
			FatalError("The file is corrupted.");
			return false;
		}

		fseek(dstfile, numfaces * 30, SEEK_CUR);	// jump over model->faces

		// load number of animations
		if (!fread(&i, sizeof(i), 1, dstfile))
		{
			fclose(dstfile);
			fclose(srcfile);
			printf("\n%s", buf);
			FatalError("The file is corrupted.");
			return false;
		}

		i++;
		fseek(dstfile, -sizeof(i), SEEK_CUR);		// go back
		fwrite(&i, sizeof(i), 1, dstfile);			// rewrite the number

		fseek(dstfile, 0, SEEK_END);				// go to the end of file

		if (empty_src)
		{
			// write the duration of each frame in this animation
			{
				float framesduration = FRAME_DURATION;
				fwrite(&framesduration, sizeof(framesduration), 1, dstfile);
			}

			// write number of frames (= 0)
			numframes = 0;
			fwrite(&numframes, sizeof(numframes), 1, dstfile);

			fclose(srcfile);
			fclose(dstfile);

			printf("\nThe file %s is converted successfully.\n", argv[1]);
//			PressAnyKeyToClose();		<-- if there is no error don't wait for key pressing

			return 0;
		}
	}
	else
	{
		if (empty_src)
		{
			fclose(srcfile);
			printf("\n%s", buf);
			FatalError("Cannot add an empty animation to a non-existent file.");
			return 0;
		}

		dstfile = fopen(buf, "wb");			// open the file for writing
		if (!dstfile)		// error check
		{
			fclose(srcfile);
			printf("\n%s", buf);
			FatalError("Cannot open (create) the output file for writing.");
			return 0;
		}

		fputs("Zimtech 3D Model", dstfile);

		// write file version
		i = 1;						// major version
		fwrite(&i, sizeof(i), 1, dstfile);
		i = 0;						// minor version
		fwrite(&i, sizeof(i), 1, dstfile);

		i = 0;						// flags
		fwrite(&i, sizeof(i), 1, dstfile);
	}

	// find *GEOMOBJECT
	do
		ReadWord(srcfile, buf);
	while (strcmp(buf, "*GEOMOBJECT") && *buf);
	if (!*buf)
	{
		fclose(srcfile);
		fclose(dstfile);
		FatalError("*GEOMOBJECT not found. Nothing to convert.");
		return 0;
	}

	// find *MESH or *MESH_ANIMATION
	do
		ReadWord(srcfile, buf);
	while (strcmp(buf, "*MESH") && strcmp(buf, "*MESH_ANIMATION") && *buf);
	if (!*buf)
	{
		fclose(srcfile);
		fclose(dstfile);
		FatalError("*MESH or *MESH_ANIMATION not found. Check off Mesh Definition or AnimatedMesh in Output Options in the ASCII Export dialog.");
		return 0;
	}

	if (!strcmp(buf, "*MESH_ANIMATION"))		// found *MESH_ANIMATION?
	{
		animated = true;

		// find *MESH
		do
			ReadWord(srcfile, buf);
		while (strcmp(buf, "*MESH") && *buf);
		if (!*buf)
		{
			fclose(srcfile);
			fclose(dstfile);
			FatalError("*MESH not found after *MESH_ANIMATION. The source file is corrupted.");
			return 0;
		}
	}
	else
		animated = false;

	if (!appending)
	{
		// get number of vertices
		do
			ReadWord(srcfile, buf);
		while (strcmp(buf, "*MESH_NUMVERTEX") && *buf);
		if (!*buf)
		{
			fclose(srcfile);
			fclose(dstfile);
			FatalError("*MESH_NUMVERTEX not found. The source file is corrupted.");
			return 0;
		}
		numverts = strtol(ReadWord(srcfile, buf), NULL, 0);

		// get number of faces
		do
			ReadWord(srcfile, buf);
		while (strcmp(buf, "*MESH_NUMFACES") && *buf);
		if (!*buf)
		{
			fclose(srcfile);
			fclose(dstfile);
			FatalError("*MESH_NUMFACES not found. The source file is corrupted.");
			return 0;
		}
		numfaces = strtol(ReadWord(srcfile, buf), NULL, 0);

		fwrite(&numverts, sizeof(numverts), 1, dstfile);	// write number of vertices in each frame of the animation
		fwrite(&numfaces, sizeof(numfaces), 1, dstfile);	// write number of faces in each frame

		face *faces = new face[numfaces];

		// find *MESH_FACE_LIST
		do
			ReadWord(srcfile, buf);
		while (strcmp(buf, "*MESH_FACE_LIST") && *buf);
		if (!*buf)
		{
			delete[] faces;
			fclose(srcfile);
			fclose(dstfile);
			FatalError("*MESH_FACE_LIST not found. The source file is corrupted.");
			return 0;
		}

		// load faces
		for (i = 0; i < numfaces; i++)
		{
			do
				ReadWord(srcfile, buf);
			while (strcmp(buf, "*MESH_FACE") && *buf);
			if (!*buf)
			{
				delete[] faces;
				fclose(srcfile);
				fclose(dstfile);
				FatalError("*MESH_FACE not found. The source file is corrupted.");
				return 0;
			}
			SkipWord(srcfile);
			SkipWord(srcfile);
			faces[i].A = strtol(ReadWord(srcfile, buf), NULL, 0);
			SkipWord(srcfile);
			faces[i].B = strtol(ReadWord(srcfile, buf), NULL, 0);
			SkipWord(srcfile);
			faces[i].C = strtol(ReadWord(srcfile, buf), NULL, 0);
		}

		// get number of texture vertices (coordinates in a texture)
		do
			ReadWord(srcfile, buf);
		while (strcmp(buf, "*MESH_NUMTVERTEX") && *buf);
		if (!*buf)
		{
			delete[] faces;
			fclose(srcfile);
			fclose(dstfile);
			FatalError("*MESH_NUMTVERTEX not found. The model must contain a texture and it must\n"
				"be checked off Mapping Coordinates in Mesh Options in the ASCII Export dialog.");
			return 0;
		}
		int numtvertex = strtol(ReadWord(srcfile, buf), NULL, 0);
		if (!numtvertex)
		{
			delete[] faces;
			fclose(srcfile);
			fclose(dstfile);
			FatalError("*MESH_NUMTVERTEX is 0. The model must contain a texture.");
			return 0;
		}

		tvert *tverts = new tvert[numtvertex];		// (tvert *)malloc(sizeof(tvert) * numtvertex);

		// find *MESH_TVERTLIST
		do
			ReadWord(srcfile, buf);
		while (strcmp(buf, "*MESH_TVERTLIST") && *buf);
		if (!*buf)
		{
			delete[] tverts;	// free(tverts);
			delete[] faces;
			fclose(srcfile);
			fclose(dstfile);
			FatalError("*MESH_TVERTLIST not found. The source file is corrupted.");
			return 0;
		}

		// load texture vertices
		for (i = 0; i < numtvertex; i++)
		{
			do
				ReadWord(srcfile, buf);
			while (strcmp(buf, "*MESH_TVERT") && *buf);
			if (!*buf)
			{
				delete[] tverts;
				delete[] faces;
				fclose(srcfile);
				fclose(dstfile);
				FatalError("*MESH_TVERT not found. The source file is corrupted.");
				return 0;
			}
			SkipWord(srcfile);
			tverts[i].x = strtod(ReadWord(srcfile, buf), NULL);
			tverts[i].y = -strtod(ReadWord(srcfile, buf), NULL);
		}

		// check whether *MESH_NUMFACES equal to *MESH_NUMTVFACES
		do
			ReadWord(srcfile, buf);
		while (strcmp(buf, "*MESH_NUMTVFACES") && *buf);
		if (!*buf)
		{
			delete[] tverts;
			delete[] faces;
			fclose(srcfile);
			fclose(dstfile);
			FatalError("*MESH_NUMTVFACES not found. The source file is corrupted.");
			return 0;
		}
		if (numfaces != strtol(ReadWord(srcfile, buf), NULL, 0))	// numfaces != numtvfaces?
		{
			delete[] tverts;
			delete[] faces;
			fclose(srcfile);
			fclose(dstfile);
			FatalError("*MESH_NUMFACES doesn't equal to *MESH_NUMTVFACES. The source file is\ncorrupted.");
			return 0;
		}

		// find *MESH_TFACELIST
		do
			ReadWord(srcfile, buf);
		while (strcmp(buf, "*MESH_TFACELIST") && *buf);
		if (!*buf)
		{
			delete[] tverts;
			delete[] faces;
			fclose(srcfile);
			fclose(dstfile);
			FatalError("*MESH_TFACELIST not found. The source file is corrupted.");
			return 0;
		}

		// write the faces to the destination file
		for (i = 0; i < numfaces; i++)
		{
			do
				ReadWord(srcfile, buf);
			while (strcmp(buf, "*MESH_TFACE") && *buf);
			if (!*buf)
			{
				delete[] tverts;
				delete[] faces;
				fclose(srcfile);
				fclose(dstfile);
				FatalError("*MESH_TFACE not found. The source file is corrupted.");
				return 0;
			}
			SkipWord(srcfile);
			fwrite(&faces[i].A, sizeof(WORD), 1, dstfile);
			fwrite(&tverts[strtol(ReadWord(srcfile, buf), NULL, 0)], sizeof(tvert), 1, dstfile);
			fwrite(&faces[i].B, sizeof(WORD), 1, dstfile);
			fwrite(&tverts[strtol(ReadWord(srcfile, buf), NULL, 0)], sizeof(tvert), 1, dstfile);
			fwrite(&faces[i].C, sizeof(WORD), 1, dstfile);
			fwrite(&tverts[strtol(ReadWord(srcfile, buf), NULL, 0)], sizeof(tvert), 1, dstfile);
		}

		delete[] tverts;			// not needed yet
		delete[] faces;

		i = 1;						// number of animations
		fwrite(&i, sizeof(i), 1, dstfile);		// write number of animations
	}

	// check whether it is animated
	if (!animated)
	{
		do
			ReadWord(srcfile, buf);
		while (*buf && strcmp(buf, "*MESH_ANIMATION") && strcmp(buf, "*GEOMOBJECT"));
		if (!strcmp(buf, "*MESH_ANIMATION"))
		{
			animated = true;
			numframes = 0;
		}
		else
			if (!strcmp(buf, "*GEOMOBJECT"))
			{
				fclose(srcfile);
				fclose(dstfile);
				FatalError("The second occurrence of *GEOMOBJECT found. The source file can contain\nONE object only.");
				return 0;
			}
	}

	// count frames of the animation
	if (animated)
	{
		do
		{
			ReadWord(srcfile, buf);
			if (!strcmp(buf, "*MESH"))
				numframes++;
			else
				if (!strcmp(buf, "*GEOMOBJECT"))
				{
					fclose(srcfile);
					fclose(dstfile);
					FatalError("The second occurrence of *GEOMOBJECT found. The source file can contain\nONE object only.");
					return 0;
				}
		}
		while (*buf);
	}

	// write the duration of each frame in this animation
	{
		float framesduration = FRAME_DURATION;
		fwrite(&framesduration, sizeof(framesduration), 1, dstfile);
	}

	fwrite(&numframes, sizeof(numframes), 1, dstfile);

	// return to the first *MESH
	fseek(srcfile, 20, SEEK_SET);	// return to the beginning of the source file (miss "*3DSMAX_ASCIIEXPORT")
	do
		ReadWord(srcfile, buf);
	while (strcmp(buf, "*GEOMOBJECT"));
	if (animated)
		do
			ReadWord(srcfile, buf);
		while (strcmp(buf, "*MESH_ANIMATION"));

	// read data (vertices and normals) from srcfile and write it to dstfile
	i = numframes;
	do
	{
		// find *MESH
		do
			ReadWord(srcfile, buf);
		while (strcmp(buf, "*MESH"));

		// find *MESH_VERTEX_LIST
		do
			ReadWord(srcfile, buf);
		while (strcmp(buf, "*MESH_VERTEX_LIST") && *buf);
		if (!*buf)
		{
			fclose(srcfile);
			fclose(dstfile);
			FatalError("*MESH_VERTEX_LIST not found. The source file is corrupted.");
			return 0;
		}

		int j;

		// read and write vertices
		for (j = 0; j < numverts; j++)
		{
			do
				ReadWord(srcfile, buf);
			while (strcmp(buf, "*MESH_VERTEX") && *buf);
			if (!*buf)
			{
				fclose(srcfile);
				fclose(dstfile);
				FatalError("*MESH_VERTEX not found. The source file is corrupted.");
				return 0;
			}
			SkipWord(srcfile);
			float f = strtod(ReadWord(srcfile, buf), NULL) / 100;	// the model is designed in centimeters but I use meters in my engine
			fwrite(&f, sizeof(f), 1, dstfile);
			f = -strtod(ReadWord(srcfile, buf), NULL) / 100;		// ASCII Scene Export has inversed y-axis
			fwrite(&f, sizeof(f), 1, dstfile);
			f = strtod(ReadWord(srcfile, buf), NULL) / 100;
			fwrite(&f, sizeof(f), 1, dstfile);
		}

		// find *MESH_NORMALS
		do
			ReadWord(srcfile, buf);
		while (strcmp(buf, "*MESH_NORMALS") && *buf);
		if (!*buf)
		{
			fclose(srcfile);
			fclose(dstfile);
			FatalError("*MESH_NORMALS not found. Check off Mesh Normals in Mesh Options in the\nASCII Export dialog.");
			return 0;
		}

		// read and write normals
		for (j = 0; j < numfaces; j++)
			for (int k = 0; k < 3; k++)
			{
				do
					ReadWord(srcfile, buf);
				while (strcmp(buf, "*MESH_VERTEXNORMAL") && *buf);
				if (!*buf)
				{
					fclose(srcfile);
					fclose(dstfile);
					FatalError("*MESH_VERTEXNORMAL not found. The source file is corrupted.");
					return 0;
				}
				SkipWord(srcfile);
				char c = strtod(ReadWord(srcfile, buf), NULL) * 120;	// it will be between -120 and 120
				fwrite(&c, sizeof(c), 1, dstfile);
				c = -strtod(ReadWord(srcfile, buf), NULL) * 120;		// ASCII Scene Export has inversed y-axis
				fwrite(&c, sizeof(c), 1, dstfile);
				c = strtod(ReadWord(srcfile, buf), NULL) * 120;
				fwrite(&c, sizeof(c), 1, dstfile);
			}
	}
	while (--i);

	fclose(srcfile);
	fclose(dstfile);

	printf("\nThe file %s is converted successfully.\n", argv[1]);
//	PressAnyKeyToClose();		<-- if there is no error don't wait for key pressing

	return 0;
}
