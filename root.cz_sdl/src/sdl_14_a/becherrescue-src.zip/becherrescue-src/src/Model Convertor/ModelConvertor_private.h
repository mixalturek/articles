// THIS FILE WILL BE OVERWRITTEN BY DEV-C++!
// DO NOT EDIT!

#ifndef MODELCONVERTOR_PRIVATE_H
#define MODELCONVERTOR_PRIVATE_H

// VERSION DEFINITIONS
#define VER_STRING	"1.2.3.100"
#define VER_MAJOR	1
#define VER_MINOR	2
#define VER_RELEASE	3
#define VER_BUILD	100
#define COMPANY_NAME	"Zimtech"
#define FILE_VERSION	"1.2"
#define FILE_DESCRIPTION	"Model Convertor"
#define INTERNAL_NAME	"Model Convertor"
#define LEGAL_COPYRIGHT	"Copyright (c) Zimtech 2002-2003"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"modelconv.exe"
#define PRODUCT_NAME	"Model Convertor"
#define PRODUCT_VERSION	"1.2"

#endif //MODELCONVERTOR_PRIVATE_H
