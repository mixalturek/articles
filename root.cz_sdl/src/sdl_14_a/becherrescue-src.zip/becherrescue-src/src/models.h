#ifndef MODELS_H
#define MODELS_H

#include <GL/gl.h>

struct FaceVertex				// information about a face vertex
{
	unsigned short I;			// index to a vertex in the vertex table
	float U, V;					// texture coordinates
};

struct Face						// face = polygon = triangle here
{
	FaceVertex A, B, C;			// face consists form three vertices
};

struct Vertex					// x, y and z-coordinate of a vertex
{
	float X, Y, Z;
};

struct FaceNormals				// directions of normals from three vertices of a face
{
	Vertex A, B, C;				// three normals from three vertices of a face
};

struct Frame					// a frame of an animation
{
	Vertex *Vertices;			// table of vertex positions
	FaceNormals *FcNormals;		// normals for each face
};

struct Animation    			// this contains information about one of animations
{
	float FrameDuration;		// the duration of each frame of the animation
	int NumFrames;				// number of frames of an animation
	Frame *Frames;				// pointer to the first frame
};

struct Model							// this contains information about a 3D model
{
	int NumVertices, NumFaces, NumAnimations;	// number of vertices/faces/animations in this animation
	Face *Faces;						// array of faces (information about vertex indexes and texture coordinates is same for all frames)
	Animation *Animations;				// array of animations
};

// load a model from a specified file
bool LoadModel(const char *PathName, Model *model);

// release all memory allocated for the model data
void ReleaseModel(Model *model);

// render a specified animation of a specified model with a specified texture with a 'past' past time from the beginning
void RenderModelAnimation(const Model model, const GLuint Texture, const int Animation, const float Past);

// render a specified frame of a specified animation of a specified model with a specified texture
void RenderModelFrame(const Model model, const GLuint Texture, const int Animation, const int Frame);

// set the time to the range of a length of a specified animation of a specified model
void NormalizeModelTime(float *Time, const Model model, const int Animation);

#endif

