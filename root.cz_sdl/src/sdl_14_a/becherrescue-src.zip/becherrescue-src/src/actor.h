#ifndef ACTOR_H
#define ACTOR_H

#include "models.h"

enum
{
	ACTION_STAY = 0,
	ACTION_WALK,
	ACTION_RUN,
	ACTION_FALL,
	ACTION_RISE,
	ACTION_ATTACK_AFTER_RUN,
	ACTION_ATTACK1,
	ACTION_ATTACK2,
	ACTION_BLOCK,
	ACTION_JUMP,
	ACTION_ATTACK3,
	ACTION_ATTACK_IN_AIR,
	ACTION_DRINK,
	ACTION_DRINK_EXPLOSION,
	MAX_ACTIONS
};

enum
{
	DIRECTION_SOUTH = 0,
	DIRECTION_SE,
	DIRECTION_EAST,
	DIRECTION_NE,
	DIRECTION_NORTH,
	DIRECTION_NW,
	DIRECTION_WEST,
	DIRECTION_SW
};

enum
{
	CLASS_HERO = 0,
	CLASS_RAIDER1,
	CLASS_RAIDER2,
	CLASS_KNIGHT
};

// this contains information about actor
struct ACTOR
{
	bool Used;				// contains this structure relevant data?
	int Class;				// see CLASS_*
	int Action;				// his action (see constants ACTION_* above)
	int PrevAction;			// his previous action (see constants ACTION_* above)
	float Duration;			// the length of his action (in seconds)
	int Direction;			// the direction of his action (see DIRECTION_* above)
	Vertex Position;		// the position of the actor
	float PrevAltitude;
	int Health;				// the health (100 is max)
	int Damage;				// the damage he causes
	float JumpPower;		// the power of his jump
	float Radius;			// the radius of his body
	float Height;			// the height of his body
	float WalkSpeed;		// the walking speed
	float RunSpeed;			// the running speed
	float FallSpeed;		// the falling speed
	float LyingTime;		// the lying time
	float FlyingTime;		// the flying time
	float BlockingTime;		// the blocking time
	float HitRadius;
	float HitShift;
	float HitHeight;
	Model *BodyModel;
	Model *HeadModel;
	Model *HandLeftModel;
	Model *HandRightModel;
	Model *WeaponModel;
	Model *HelmetModel;
	Model *ShieldModel;
	Model *PotionModel;
	GLuint *BodyTexture;
	GLuint *HeadTexture;
	GLuint *HandTexture;
	GLuint *WeaponTexture;
	GLuint *HelmetTexture;
	GLuint *ShieldTexture;
	GLuint *PotionTexture;
	ACTOR *Target;			// used for enemies
	bool Immortal;
	float Immortal_Duration;
	int Credits;
	int Bottles;
	int TotalDamage;
};

// update your actor data
void UpdateActor(ACTOR *Actor);

// do damage to an actor
void HitActor(ACTOR *Actor, ACTOR *Attacker, const int Damage);

// render the actor
void RenderActor(ACTOR *Actor);

#endif

