#include "music.h"
#ifdef USE_SDL_MIXER
	#include <SDL/SDL_mixer.h>
	#include "errors.h"
	#include "texts.h"
	#include "settings.h"

	static Mix_Music *Music = NULL;
#endif

bool PlayMusic(const char *FileName, const float Volume)
{
#ifdef USE_SDL_MIXER
	if (!EnableMusic)
		return true;

	FreeMusic();

	if (!(Music = Mix_LoadMUS(FileName)))
	{
		FatalError(Texts[T_COULDNT_LOAD_MUSIC], FileName, Mix_GetError());
		return false;
	}

	Mix_VolumeMusic(int(Volume * SDL_MIX_MAXVOLUME));

	Mix_PlayMusic(Music, -1);
#endif

	return true;
}

void FreeMusic()
{
#ifdef USE_SDL_MIXER
	if (Music)
	{
		Mix_FreeMusic(Music);
		Music = NULL;		// so we know we freed it...
	}
#endif
}
