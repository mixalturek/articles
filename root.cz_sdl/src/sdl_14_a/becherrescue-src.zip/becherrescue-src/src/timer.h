#ifndef TIMER_H
#define TIMER_H

// initialize the timer
void InitTimer();

// reset the timer
void ResetTimer();

// get the delay between two calls (in seconds)
void GetDelay(float *Delay);

#endif

