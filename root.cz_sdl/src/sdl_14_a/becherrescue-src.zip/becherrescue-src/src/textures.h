#ifndef TEXTURES_H
#define TEXTURES_H

#include <GL/gl.h>

// load a texture from a file
bool LoadTexture(const char *PathName, GLuint *TextureID, const bool bTransparent = false);

// release the texture from the video/system memory
void ReleaseTexture(const GLuint *TextureID);

#endif

