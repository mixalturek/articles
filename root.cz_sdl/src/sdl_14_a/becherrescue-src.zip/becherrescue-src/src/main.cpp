#include <SDL/SDL.h>
#include <stdlib.h>					// for exit()
#include "initialization.h"
#include "global.h"
#ifdef WIN32
	#include "60hzproblem.h"
#endif
#include "timer.h"
#include "keys.h"
#include "settings.h"
#include <string.h>					// for memcpy()
#include "game.h"
#include "scene.h"

// make a screenshot
void ScreenShot()
{
	SDL_Surface *image;
	if ((image = SDL_CreateRGBSurface(SDL_SWSURFACE, ScreenWidth, ScreenHeight, 24, 0x0000FF, 0x00FF00, 0xFF0000, 0)))
	{
		glReadPixels(0, 0, ScreenWidth, ScreenHeight, GL_RGB, GL_UNSIGNED_BYTE, image->pixels);

		// swap lines in vertical direction
		int linesize = ScreenWidth * 3;
		void *templine = malloc(linesize);
		Uint8 *pixels = (Uint8 *)image->pixels;
		for (int i = 0; i < ScreenHeight >> 1; i++)
		{
			memcpy(templine, pixels + i * linesize, linesize);
			memcpy(pixels + i * linesize, pixels + (ScreenHeight - i - 1) * linesize, linesize);
			memcpy(pixels + (ScreenHeight - i - 1) * linesize, templine, linesize);
		}
		free(templine);

		char buf[1024];
		sprintf(buf, "screenshot%04d.bmp", LastPicture++);
		SDL_SaveBMP(image, buf);
		SDL_FreeSurface(image);
	};
};

int main(int argc, char *argv[])
{
	Initialize(argc, argv);

	// the cycle for processing events and rendering frames
	SDL_Event event;
	while (true)
		if (SDL_PollEvent(&event))			// check for events
			switch (event.type)
			{
				case SDL_KEYDOWN:
					if (event.key.keysym.sym == SDLK_F4 && event.key.keysym.mod & KMOD_ALT)
						exit(0);				// exit on Alt+F4
					else
						if (event.key.keysym.sym == SDLK_F9)
							SDL_WM_IconifyWindow();		// minimize on F9
						else
							if (event.key.keysym.sym == SDLK_F12)
								ScreenShot();
							else
								if (event.key.keysym.sym == SDLK_F11)
									ShowFPS = !ShowFPS;
								else
									if (AppState == APP_MENU || event.key.keysym.sym == SDLK_ESCAPE || event.key.keysym.sym == SDLK_SPACE)
										Game_KeyPress(event.key.keysym.sym);		// a key is pressed
									else
										KeyEvent(event.key.keysym.sym, true);		// a key is pressed
					break;
				case SDL_KEYUP:
					KeyEvent(event.key.keysym.sym, false);		// a key is released
					break;
				case SDL_JOYAXISMOTION:							// handle joystick motion
					{
						SDLKey left_key, right_key, up_key, down_key;

						if (AssignJoystick == 1)				// joystick is assigned to player 1
						{
							left_key = SDLK_KP4;
							right_key = SDLK_KP6;
							up_key = SDLK_KP8;
							down_key = SDLK_KP2;
						}
						else
							if (AssignJoystick == 2)			// joystick is assigned to player 2
							{
								left_key = SDLK_a;
								right_key = SDLK_d;
								up_key = SDLK_w;
								down_key = SDLK_x;
							}
							else
								break;							// joystick is not assigned

						if (event.jaxis.which)					// we handle joystick 0 only
							break;

						int value = event.jaxis.value;
						if (value > -JOYSTICK_DEADZONE && value < JOYSTICK_DEADZONE)	// process dead-zone
							value = 0;

						if (!event.jaxis.axis)					// left-right movement/axis
							if (value > 0)
								KeyEvent(right_key, true);
							else
								if (value < 0)
									KeyEvent(left_key, true);
								else	// value == 0
								{
									KeyEvent(right_key, false);
									KeyEvent(left_key, false);
								}
				        else
				        	if (event.jaxis.axis == 1)			// up-down movement/axis
								if (value > 0)
									KeyEvent(down_key, true);
								else
									if (value < 0)
										KeyEvent(up_key, true);
									else	// value == 0
									{
										KeyEvent(down_key, false);
										KeyEvent(up_key, false);
									}
					}
					break;
				case SDL_JOYBUTTONDOWN:							// handle joystick button presses
					{
						SDLKey fire_key, jump_key, magic_key;

						if (AssignJoystick == 1)				// joystick is assigned to player 1
						{
							fire_key = SDLK_KP5;
							jump_key = SDLK_KP0;
							magic_key = SDLK_KP_ENTER;
						}
						else
							if (AssignJoystick == 2)			// joystick is assigned to player 2
							{
								fire_key = SDLK_s;
								jump_key = SDLK_TAB;
								magic_key = SDLK_LCTRL;
							}
							else
								break;							// joystick is not assigned

						if (event.jbutton.which)				// we handle joystick 0 only
							break;

						if (event.jbutton.state == SDL_PRESSED)
							switch (event.jbutton.button)
							{
								case 0:
									KeyEvent(fire_key, false);
									KeyEvent(fire_key, true);
									break;
								case 1:
									KeyEvent(jump_key, false);
									KeyEvent(jump_key, true);
									break;
								case 2:
									KeyEvent(magic_key, false);
									KeyEvent(magic_key, true);
									break;
							}
					}
					break;
				case SDL_QUIT:				// the Close button was clicked
					exit(0);
			#ifdef WIN32
				case SDL_ACTIVEEVENT:
					if (event.active.gain && event.active.state == SDL_APPMOUSEFOCUS)	// the application is restored
						if (Is60HzProblem)  					// ^-- "event.active.state == SDL_APPACTIVE" didn't work
							Solve60HzProblem(DesktopFrequency);
					break;
			#endif
				default:
					break;
			}
		else
		{
			GetDelay(&Delay);				// get time (in seconds) between current and previous frame
			UpdateFPS();
			if (Delay > MAX_DELAY)
				Delay = MAX_DELAY;

			UpdateGame();

			// mark keys as 'repeatedly pressed'
			for (int i = 0; i < KEYS_NUM; i++)
				if (Keys[i] == 1)
					Keys[i] = 2;
		}
}
