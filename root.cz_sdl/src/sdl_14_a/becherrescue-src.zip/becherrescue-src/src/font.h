#ifndef FONT_H
#define FONT_H

#define CHAR_WIDTH						12.0f
#define CHAR_HEIGHT						23.0f

// load font data
void InitFont();

// release font data
void ReleaseFont();

// render text
void RenderText(const float X, const float Y, const char *Text, const float R = 1.0f, const float G = 1.0f, const float B = 1.0f, const float A = 1.0f);

#endif

