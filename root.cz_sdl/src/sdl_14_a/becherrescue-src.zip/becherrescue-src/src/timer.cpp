#include "timer.h"
#include <SDL/SDL.h>

static Uint32 LastTicks;		// the number of ticks at the last call of GetDelay()

void InitTimer()
{
	// nothing, prepared for a high-resolution timer :)
}

void ResetTimer()
{
	LastTicks = SDL_GetTicks();
}

void GetDelay(float *Delay)
{
	Uint32 now = SDL_GetTicks();
	*Delay = (now - LastTicks) / 1000.0f;
	LastTicks = now;
}

