The "src" directory contains the sources of my game Becher Rescue. The
sources are published under the GNU/GPL license (see LICENSE.txt).

Ladislav "Ladis" Zima, Zimtech team
ladislav.zima(at)gmail(dot)com
http://zimtech.ceskehry.cz
